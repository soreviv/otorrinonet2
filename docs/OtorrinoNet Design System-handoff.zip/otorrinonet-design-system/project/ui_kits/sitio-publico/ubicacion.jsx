/* Página de Ubicación — cómo llegar al consultorio */

const TrainIc = (p) => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" {...p}>
    <rect x="4" y="3" width="16" height="16" rx="3"/>
    <path d="M4 11h16M12 3v8M8 19l-2 2M16 19l2 2M8 15h.01M16 15h.01"/>
  </svg>
);
const BusIc = (p) => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" {...p}>
    <path d="M8 6v6M15 6v6M2 12h19.6M18 18h2M4 18H2M18 18a2 2 0 1 1-4 0M8 18a2 2 0 1 1-4 0"/>
    <path d="M1 18V6a5 5 0 0 1 5-5h12a5 5 0 0 1 5 5v12"/>
  </svg>
);
const CarIc = (p) => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" {...p}>
    <path d="M5 17H3v-7l2-5h14l2 5v7h-2M5 17a2 2 0 1 0 4 0 2 2 0 0 0-4 0M15 17a2 2 0 1 0 4 0 2 2 0 0 0-4 0"/>
    <path d="M5 10h14"/>
  </svg>
);

const howToArrive = [
  {
    Icon: TrainIc,
    label: 'Metro',
    detail: 'Línea 6 — Estación Lindavista, 5 min caminando hacia el norte por Av. Montevideo.',
  },
  {
    Icon: BusIc,
    label: 'Metrobús',
    detail: 'Línea 6 — Parada Lindavista Sur, 7 min caminando. Baja en dirección a Chosica.',
  },
  {
    Icon: CarIc,
    label: 'Auto',
    detail: 'Acceso por Av. Montevideo o Insurgentes Norte. Estacionamiento en calle disponible en Chosica y calles aledañas.',
  },
];

function UbicacionPage({ onNav }) {
  const c = window.OTORRINO_DATA.contact;

  return (
    <>
      {/* ── Header ── */}
      <section style={{ background: 'var(--surface-card)', borderBottom: '1px solid var(--border-subtle)', padding: '56px 0' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px' }}>
          <Eyebrow>Cómo llegar</Eyebrow>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 40, fontWeight: 700,
            color: 'var(--text-strong)', margin: '12px 0 0', lineHeight: 1.08 }}>
            Ubicación
          </h1>
        </div>
      </section>

      {/* ── Body ── */}
      <section style={{ padding: '64px 0', background: 'var(--surface-page)' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px',
          display: 'grid', gridTemplateColumns: '360px 1fr', gap: 48, alignItems: 'start' }}>

          {/* ─ Info lateral ─ */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>

            {/* Dirección */}
            <div>
              <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 18, fontWeight: 700,
                color: 'var(--text-strong)', margin: '0 0 14px' }}>Dirección</h2>
              <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                <MapPin size={18} style={{ color: 'var(--brand-primary)', flex: 'none', marginTop: 2 }} />
                <p style={{ margin: 0, fontSize: 15, color: 'var(--text-body)', lineHeight: 1.6 }}>
                  {c.address}<br />{c.city}
                </p>
              </div>
            </div>

            {/* Horario */}
            <div>
              <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 18, fontWeight: 700,
                color: 'var(--text-strong)', margin: '0 0 14px' }}>Horario</h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
                {c.schedule.map((s, i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between', gap: 16,
                    fontSize: 14, color: 'var(--text-body)', padding: '10px 0',
                    borderBottom: i < c.schedule.length - 1 ? '1px solid var(--border-subtle)' : 'none' }}>
                    <span>{s.days}</span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12.5, fontWeight: 600,
                      color: s.hours === 'Cerrado' ? 'var(--text-muted)' : 'var(--text-strong)' }}>
                      {s.hours}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Cómo llegar */}
            <div>
              <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 18, fontWeight: 700,
                color: 'var(--text-strong)', margin: '0 0 14px' }}>Cómo llegar</h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {howToArrive.map(({ Icon, label, detail }, i) => (
                  <div key={i} style={{ display: 'flex', gap: 14, padding: '14px 16px',
                    background: 'var(--surface-card)', borderRadius: 'var(--radius-lg)',
                    border: '1px solid var(--border-subtle)' }}>
                    <span style={{ width: 36, height: 36, borderRadius: 'var(--radius-md)',
                      background: 'var(--color-sky-50)', display: 'flex', alignItems: 'center',
                      justifyContent: 'center', flex: 'none', color: 'var(--brand-primary)' }}>
                      <Icon />
                    </span>
                    <div>
                      <p style={{ margin: '0 0 3px', fontWeight: 600, fontSize: 13.5,
                        color: 'var(--text-strong)' }}>{label}</p>
                      <p style={{ margin: 0, fontSize: 13, color: 'var(--text-body)', lineHeight: 1.5 }}>
                        {detail}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <Button icon={Calendar} onClick={() => onNav('agendar')}>Agendar Cita</Button>
          </div>

          {/* ─ Mapa ─ */}
          <div style={{ borderRadius: 'var(--radius-2xl)', overflow: 'hidden',
            boxShadow: 'var(--shadow-lg)', border: '1px solid var(--border-subtle)',
            height: 520, background: 'var(--surface-sunken)' }}>
            <iframe
              title="Consultorio Dr. Viveros — Chosica 730 Lindavista CDMX"
              src="https://maps.google.com/maps?q=Chosica+730+Lindavista+Gustavo+A+Madero+CDMX&output=embed&z=16"
              width="100%" height="100%"
              style={{ border: 'none', display: 'block' }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade">
            </iframe>
          </div>
        </div>
      </section>
    </>
  );
}

Object.assign(window, { UbicacionPage, TrainIc, BusIc, CarIc });
