/* Public homepage sections for Dr. Viveros — Header, Hero, Services, Reviews,
   Tienda band, bottom CTA, Footer. */

function PublicHeader({ onNav, page }) {
  const links = [['inicio','Inicio'],['perfil','Perfil'],['servicios','Servicios'],['tienda','Tienda'],['ubicacion','Ubicación'],['contacto','Contacto']];
  return (
    <nav style={{ position: 'sticky', top: 0, zIndex: 50, background: 'rgba(255,255,255,.95)',
      backdropFilter: 'blur(8px)', borderBottom: '1px solid var(--border-subtle)' }}>
      <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px',
        height: 'var(--header-h)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <a onClick={() => onNav('inicio')} style={{ cursor: 'pointer', display: 'flex', alignItems: 'center' }}>
          <img src="../../assets/logo-otorrinonet-transparent.svg" alt="Dr. Alejandro Viveros Domínguez" style={{ height: 46, width: 'auto' }} />
        </a>
        <div style={{ display: 'flex', alignItems: 'center', gap: 28 }} className="nav-links">
          {links.map(([id, label]) => {
            const active = page === id;
            return <a key={id} onClick={() => onNav(id)} style={{ cursor: 'pointer', fontSize: 14, fontWeight: 500,
              color: active ? 'var(--brand-primary)' : 'var(--text-body)', transition: 'color .12s' }}>{label}</a>;
          })}
          <Button size="sm" icon={Calendar} onClick={() => onNav('agendar')}>Agendar Cita</Button>
        </div>
      </div>
    </nav>
  );
}

function Hero({ onNav }) {
  const d = window.OTORRINO_DATA.doctor, r = window.OTORRINO_DATA.rating;
  return (
    <section style={{ position: 'relative', overflow: 'hidden', background: 'var(--surface-card)' }}>
      <div className="hero-diag" style={{ position: 'absolute', top: 0, right: 0, height: '100%', width: '55%',
        background: 'linear-gradient(to bottom left, var(--color-sky-600), var(--color-sky-700))',
        clipPath: 'polygon(18% 0%, 100% 0%, 100% 100%, 0% 100%)' }} />
      <div style={{ position: 'relative', maxWidth: 'var(--container-max)', margin: '0 auto', padding: '72px 24px',
        display: 'grid', gridTemplateColumns: '1.1fr 0.9fr', gap: 56, alignItems: 'center' }} className="hero-grid">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'var(--color-sky-50)',
            color: 'var(--color-sky-700)', fontSize: 12, fontWeight: 700, padding: '6px 12px', borderRadius: 'var(--radius-full)',
            width: 'fit-content', border: '1px solid var(--color-sky-100)' }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--color-sky-500)', animation: 'ds-pulse 1.6s ease-in-out infinite' }} />
            {d.yearsOfExperience}+ años de experiencia
          </span>
          <div>
            <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 46, fontWeight: 700, color: 'var(--text-strong)',
              lineHeight: 1.08, letterSpacing: '-.02em', margin: 0 }}>{d.fullName}</h1>
            <p style={{ fontSize: 18, color: 'var(--brand-primary)', fontWeight: 600, marginTop: 8 }}>{d.title}</p>
          </div>
          <p style={{ color: 'var(--text-body)', lineHeight: 1.65, fontSize: 15, maxWidth: 420, margin: 0 }}>{d.tagline}</p>
          <div style={{ display: 'flex', gap: 12, marginTop: 4 }}>
            <Button icon={Calendar} onClick={() => onNav('agendar')}>Agendar Cita</Button>
            <Button variant="secondary" iconR={ChevronR} onClick={() => onNav('perfil')}>Ver perfil completo</Button>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, paddingTop: 4 }}>
            {d.certifications.map((c, i) => <span key={i} style={{ fontSize: 11, background: 'var(--surface-sunken)',
              color: 'var(--text-body)', padding: '5px 10px', borderRadius: 'var(--radius-full)', fontWeight: 500 }}>{c}</span>)}
          </div>
        </div>
        <div style={{ position: 'relative', display: 'flex', justifyContent: 'flex-end' }}>
          <div style={{ position: 'relative', width: 300, height: 380 }}>
            <div style={{ position: 'absolute', inset: 0, borderRadius: 'var(--radius-2xl)', overflow: 'hidden',
              boxShadow: 'var(--shadow-2xl)' }}>
              <img src={d.photo} alt={d.fullName} style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center top' }} />
            </div>
            <div style={{ position: 'absolute', bottom: -16, left: -20, background: 'var(--surface-card)',
              borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-xl)', padding: 12, display: 'flex', alignItems: 'center', gap: 10,
              border: '1px solid var(--border-subtle)' }}>
              <span style={{ width: 36, height: 36, borderRadius: 'var(--radius-lg)', background: 'var(--color-amber-50)',
                display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Star size={16} fill="var(--color-amber-400)" /></span>
              <div style={{ lineHeight: 1.2 }}>
                <p style={{ margin: 0, fontSize: 14, fontWeight: 700, color: 'var(--text-strong)' }}>{r.average} / 5</p>
                <p style={{ margin: 0, fontSize: 10, color: 'var(--text-muted)' }}>{r.total} reseñas · Google</p>
              </div>
            </div>
            <div style={{ position: 'absolute', top: -12, right: -16, background: 'var(--surface-card)',
              borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-xl)', padding: '10px 14px', border: '1px solid var(--border-subtle)' }}>
              <p style={{ margin: 0, fontSize: 10, fontWeight: 700, color: 'var(--brand-primary)', textTransform: 'uppercase', letterSpacing: '.08em' }}>Cédula Prof.</p>
              <p style={{ margin: 0, fontSize: 13, fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--text-strong)' }}>{d.licenseNumber}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function ServiceTile({ name, icon, onClick }) {
  const [h, setH] = React.useState(false);
  const Icon = SERVICE_ICONS[icon] || Stethoscope;
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', gap: 12,
        padding: 20, background: 'var(--surface-card)', borderRadius: 'var(--radius-xl)', cursor: 'default',
        border: `1px solid ${h ? 'var(--color-sky-200)' : 'var(--border-subtle)'}`,
        boxShadow: h ? 'var(--shadow-lg)' : 'none', transition: 'all .3s var(--ease-standard)' }}>
      <span style={{ width: 48, height: 48, borderRadius: 'var(--radius-lg)', display: 'flex', alignItems: 'center',
        justifyContent: 'center', background: h ? 'var(--color-sky-100)' : 'var(--color-sky-50)', color: 'var(--brand-primary)', transition: 'background .3s' }}>
        <Icon size={20} />
      </span>
      <span style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text-strong)', lineHeight: 1.25 }}>{name}</span>
    </div>
  );
}

function Services({ onNav }) {
  const s = window.OTORRINO_DATA.services;
  return (
    <section style={{ padding: '80px 0', background: 'var(--surface-page)' }}>
      <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24, marginBottom: 44 }}>
          <div>
            <Eyebrow>Especialidades</Eyebrow>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 34, fontWeight: 700, color: 'var(--text-strong)', margin: '12px 0 0' }}>Nuestros Servicios</h2>
            <p style={{ color: 'var(--text-muted)', marginTop: 12, maxWidth: 420, fontSize: 14, lineHeight: 1.6 }}>Atención integral en otorrinolaringología con tecnología de vanguardia para todas las edades.</p>
          </div>
          <a onClick={() => onNav('servicios')} style={{ cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6,
            color: 'var(--brand-primary)', fontWeight: 600, fontSize: 14, whiteSpace: 'nowrap' }}>Ver todos los servicios <ArrowUR size={16} /></a>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 16 }} className="svc-grid">
          {s.map(x => <ServiceTile key={x.id} name={x.name} icon={x.icon} onClick={() => onNav('servicios')} />)}
        </div>
      </div>
    </section>
  );
}

function Reviews() {
  const rv = window.OTORRINO_DATA.reviews, sum = window.OTORRINO_DATA.rating;
  return (
    <section style={{ padding: '80px 0', background: 'var(--surface-card)' }}>
      <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24, marginBottom: 44 }}>
          <div>
            <Eyebrow>Reseñas verificadas</Eyebrow>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 34, fontWeight: 700, color: 'var(--text-strong)', margin: '12px 0 0', lineHeight: 1.1 }}>Lo que dicen<br/>nuestros pacientes</h2>
          </div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 12, background: 'var(--surface-card)',
            border: '1px solid var(--border-default)', borderRadius: 'var(--radius-xl)', padding: '12px 20px', boxShadow: 'var(--shadow-sm)' }}>
            <div><div style={{ display: 'flex', alignItems: 'baseline', gap: 3 }}><span style={{ fontSize: 26, fontWeight: 700, color: 'var(--text-strong)', fontFamily: 'var(--font-heading)' }}>{sum.average}</span><span style={{ fontSize: 12, color: 'var(--text-muted)' }}>/5</span></div>
              <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{sum.total} reseñas</span></div>
            <div style={{ width: 1, height: 32, background: 'var(--border-default)' }} />
            <div><StarRow size={13} /><div style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '.06em', marginTop: 4 }}>Google</div></div>
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }} className="rev-grid">
          {rv.map((r, i) => (
            <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 16, padding: 24, background: 'var(--surface-card)',
              border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                <Avatar name={r.name} solid />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ margin: 0, fontSize: 14, fontWeight: 600, color: 'var(--text-strong)' }}>{r.name}</p>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}><StarRow rating={r.rating} /><span style={{ fontSize: 10, color: 'var(--text-muted)' }}>Google</span></div>
                </div>
              </div>
              <p style={{ margin: 0, fontSize: 14, color: 'var(--text-body)', lineHeight: 1.65 }}>{r.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TiendaBand({ onNav }) {
  return (
    <section style={{ padding: '72px 0', background: 'var(--surface-page)' }}>
      <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px' }}>
        <div style={{ background: 'var(--surface-card)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-2xl)',
          padding: 40, display: 'flex', alignItems: 'center', gap: 40, boxShadow: 'var(--shadow-sm)' }} className="tienda-band">
          <span style={{ width: 64, height: 64, background: 'var(--color-sky-50)', borderRadius: 'var(--radius-xl)', flex: 'none',
            display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--brand-primary)' }}><Shop size={30} /></span>
          <div style={{ flex: 1 }}>
            <Eyebrow>Tienda en línea</Eyebrow>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 26, fontWeight: 700, color: 'var(--text-strong)', margin: '8px 0 8px' }}>Productos recomendados por el Dr. Viveros</h2>
            <p style={{ margin: 0, color: 'var(--text-body)', lineHeight: 1.6, maxWidth: 560, fontSize: 14.5 }}>Dispositivos médicos, suplementos y paquetes de consulta seleccionados por el especialista. Entrega en consultorio o envío a domicilio.</p>
          </div>
          <Button iconR={ArrowUR} onClick={() => onNav('tienda')}>Ver productos</Button>
        </div>
      </div>
    </section>
  );
}

function BottomCTA({ onNav }) {
  return (
    <section style={{ position: 'relative', overflow: 'hidden', background: 'var(--color-sky-600)', padding: '72px 0' }}>
      <div style={{ position: 'absolute', inset: 0, opacity: .2, backgroundImage: 'radial-gradient(circle, rgba(255,255,255,.5) 1px, transparent 1px)', backgroundSize: '28px 28px' }} />
      <div style={{ position: 'relative', maxWidth: 620, margin: '0 auto', textAlign: 'center', padding: '0 24px' }}>
        <Eyebrow light>Agenda tu consulta</Eyebrow>
        <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 36, fontWeight: 700, color: '#fff', margin: '16px 0 16px', lineHeight: 1.1 }}>¿Listo para sentirte<br/>mejor?</h2>
        <p style={{ color: 'var(--color-sky-100)', fontSize: 15, lineHeight: 1.65, marginBottom: 28 }}>Primera consulta disponible esta semana. Atención especializada en el corazón de la Ciudad de México.</p>
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
          <Button variant="onPrimary" icon={Calendar} onClick={() => onNav('agendar')}>Agendar Cita Ahora</Button>
          <Button variant="outlineLight" icon={Phone}>Llamar al consultorio</Button>
        </div>
      </div>
    </section>
  );
}

function PublicFooter() {
  const c = window.OTORRINO_DATA.contact;
  return (
    <footer style={{ background: 'var(--color-slate-900)', color: 'var(--color-slate-400)', padding: '48px 0 32px' }}>
      <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px',
        display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr', gap: 40 }} className="footer-grid">
        <div>
          <img src="../../assets/logo-otorrinonet-white.svg" alt="Logo" style={{ height: 56, width: 'auto', opacity: .95 }} />
          <p style={{ fontSize: 13, lineHeight: 1.65, marginTop: 16, maxWidth: 320 }}>Otorrinolaringología y Cirugía de Cabeza y Cuello. Atención humana, ética y de alta calidad en CDMX.</p>
        </div>
        <div>
          <p style={{ color: '#fff', fontWeight: 600, fontSize: 13, marginBottom: 12 }}>Consultorio</p>
          <p style={{ display: 'flex', gap: 8, fontSize: 13, lineHeight: 1.5, marginBottom: 10 }}><MapPin size={16} style={{ flex: 'none', marginTop: 1, color: 'var(--color-sky-400)' }} /><span>{c.address}<br/>{c.city}</span></p>
        </div>
        <div>
          <p style={{ color: '#fff', fontWeight: 600, fontSize: 13, marginBottom: 12 }}>Horario</p>
          {c.schedule.map((s, i) => <p key={i} style={{ fontSize: 13, marginBottom: 8, display: 'flex', justifyContent: 'space-between', gap: 12 }}><span>{s.days}</span><span style={{ color: '#fff', fontFamily: 'var(--font-mono)', fontSize: 12 }}>{s.hours}</span></p>)}
        </div>
      </div>
      <div style={{ maxWidth: 'var(--container-max)', margin: '32px auto 0', padding: '20px 24px 0', borderTop: '1px solid var(--color-slate-800)', fontSize: 12 }}>
        © 2026 Dr. Alejandro Viveros Domínguez · Cédula Prof. 6277305 · Hecho con OtorrinoNet
      </div>
    </footer>
  );
}

function HomePage({ onNav }) {
  return <><Hero onNav={onNav} /><Services onNav={onNav} /><Reviews /><TiendaBand onNav={onNav} /><BottomCTA onNav={onNav} /></>;
}

Object.assign(window, { PublicHeader, PublicFooter, HomePage });
