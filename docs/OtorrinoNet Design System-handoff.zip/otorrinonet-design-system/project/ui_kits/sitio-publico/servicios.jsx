/* Página de Servicios detallados */

const SERVICES_DETAIL = [
  {
    id: 'consulta',
    name: 'Consulta ORL General',
    icon: 'stethoscope',
    description: 'Evaluación integral de oídos, nariz y garganta. Diagnóstico de infecciones, alergias, problemas de audición y vías respiratorias superiores en pacientes de todas las edades.',
    includes: ['Historia clínica completa', 'Exploración física ORL', 'Diagnóstico y plan de tratamiento', 'Seguimiento post-consulta'],
  },
  {
    id: 'audiologia',
    name: 'Audiología',
    icon: 'ear',
    description: 'Evaluación completa de la función auditiva mediante estudios especializados. Diagnóstico y manejo de hipoacusia, tinnitus, otitis y otros padecimientos del oído.',
    includes: ['Audiometría tonal y vocal', 'Timpanometría', 'Potenciales evocados auditivos', 'Orientación en auxiliares auditivos'],
  },
  {
    id: 'vacunacion',
    name: 'Vacunación',
    icon: 'syringe',
    description: 'Aplicación de vacunas preventivas para adultos y niños con esquemas personalizados según historial médico y factores de riesgo individual.',
    includes: ['Influenza estacional', 'Neumococo', 'VPH y otras vacunas', 'Esquemas de refuerzo'],
  },
  {
    id: 'rinitis',
    name: 'Rinitis Alérgica e Inmunoterapia',
    icon: 'allergen',
    description: 'Diagnóstico y tratamiento de alergias respiratorias con inmunoterapia sublingual o subcutánea para reducir la sensibilidad a los alérgenos y mejorar la calidad de vida.',
    includes: ['Identificación de alérgenos', 'Pruebas cutáneas', 'Inmunoterapia personalizada', 'Seguimiento y ajuste de dosis'],
  },
  {
    id: 'cirugia',
    name: 'Cirugía ORL',
    icon: 'surgery',
    description: 'Procedimientos quirúrgicos de mínima invasión para nariz, garganta y oídos. Técnicas modernas que reducen el tiempo de recuperación y las molestias postoperatorias.',
    includes: ['Septoplastia y turbinoplastia', 'Amigdalectomía y adenoidectomía', 'Cirugía endoscópica nasosinusal', 'Timpanoplastia'],
  },
  {
    id: 'vertigo',
    name: 'Vértigo y Equilibrio',
    icon: 'balance',
    description: 'Evaluación y tratamiento del vértigo posicional benigno, enfermedad de Ménière y otros trastornos del sistema vestibular que afectan el equilibrio y la calidad de vida.',
    includes: ['Videonistagmografía', 'Maniobras de reposición canalicular', 'Rehabilitación vestibular', 'Tratamiento farmacológico'],
  },
];

function ServiceCard({ service }) {
  const [open, setOpen] = React.useState(false);
  const Icon = SERVICE_ICONS[service.icon] || Stethoscope;

  return (
    <div style={{ background: 'var(--surface-card)', borderRadius: 'var(--radius-2xl)',
      border: '1px solid var(--border-subtle)', overflow: 'hidden', boxShadow: 'var(--shadow-sm)',
      display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '32px 32px 24px', flex: 1 }}>
        <div style={{ width: 52, height: 52, borderRadius: 'var(--radius-xl)', background: 'var(--color-sky-50)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--brand-primary)', marginBottom: 20 }}>
          <Icon size={22} />
        </div>
        <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: 20, fontWeight: 700,
          color: 'var(--text-strong)', margin: '0 0 12px', lineHeight: 1.2 }}>
          {service.name}
        </h3>
        <p style={{ color: 'var(--text-body)', fontSize: 14, lineHeight: 1.7, margin: 0 }}>
          {service.description}
        </p>
      </div>

      <div style={{ padding: '0 32px 28px' }}>
        <button
          onClick={() => setOpen(!open)}
          style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none',
            cursor: 'pointer', color: 'var(--brand-primary)', fontFamily: 'var(--font-sans)',
            fontSize: 13.5, fontWeight: 600, padding: 0 }}>
          <span>{open ? 'Ocultar' : 'Ver'} qué incluye</span>
          <ChevronR size={14} style={{ transform: open ? 'rotate(90deg)' : 'none', transition: 'transform .2s' }} />
        </button>

        {open && (
          <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 10,
            padding: '16px', background: 'var(--surface-sunken)', borderRadius: 'var(--radius-lg)' }}>
            {service.includes.map((item, i) => (
              <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                <span style={{ width: 20, height: 20, borderRadius: '50%', background: 'var(--color-sky-100)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none',
                  color: 'var(--brand-primary)' }}>
                  <Check size={11} />
                </span>
                <span style={{ fontSize: 13.5, color: 'var(--text-body)' }}>{item}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ServiciosPage({ onNav }) {
  return (
    <>
      {/* ── Header ── */}
      <section style={{ background: 'linear-gradient(135deg, var(--color-sky-700) 0%, var(--color-sky-600) 100%)',
        padding: '72px 0 80px' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px', textAlign: 'center' }}>
          <Eyebrow light>Especialidades</Eyebrow>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 42, fontWeight: 700, color: '#fff',
            margin: '16px 0 20px', lineHeight: 1.08 }}>
            Nuestros Servicios
          </h1>
          <p style={{ color: 'var(--color-sky-100)', fontSize: 16, lineHeight: 1.65, maxWidth: 500,
            margin: '0 auto 32px' }}>
            Atención integral en otorrinolaringología con tecnología de vanguardia para todas las edades.
          </p>
          <Button variant="onPrimary" icon={Calendar} onClick={() => onNav('agendar')}>
            Agendar Cita
          </Button>
        </div>
      </section>

      {/* ── Grid ── */}
      <section style={{ padding: '80px 0', background: 'var(--surface-page)' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 24 }}>
            {SERVICES_DETAIL.map(s => <ServiceCard key={s.id} service={s} />)}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section style={{ padding: '72px 0', background: 'var(--surface-card)', borderTop: '1px solid var(--border-subtle)' }}>
        <div style={{ maxWidth: 560, margin: '0 auto', padding: '0 24px', textAlign: 'center' }}>
          <Eyebrow>¿Tienes dudas?</Eyebrow>
          <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 30, fontWeight: 700,
            color: 'var(--text-strong)', margin: '12px 0 16px' }}>
            Agenda tu consulta
          </h2>
          <p style={{ color: 'var(--text-body)', fontSize: 15, lineHeight: 1.65, marginBottom: 28 }}>
            Primera consulta disponible esta semana. Llama o agenda en línea.
          </p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Button icon={Calendar} onClick={() => onNav('agendar')}>Agendar en línea</Button>
            <Button variant="secondary" icon={Phone} onClick={() => onNav('contacto')}>Ver contacto</Button>
          </div>
        </div>
      </section>
    </>
  );
}

Object.assign(window, { ServiciosPage, SERVICES_DETAIL, ServiceCard });
