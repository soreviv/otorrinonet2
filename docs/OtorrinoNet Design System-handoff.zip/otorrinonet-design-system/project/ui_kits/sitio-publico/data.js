/* Real content for the Dr. Viveros public site — lifted from the product's
   sitio-publico-data.ts so the kit reads like the live site. */
window.OTORRINO_DATA = {
  doctor: {
    fullName: 'Dr. Alejandro Viveros Domínguez',
    title: 'Médico Otorrinolaringólogo',
    licenseNumber: '6277305',
    yearsOfExperience: 10,
    photo: '../../assets/dr-viveros-perfil.jpg',
    tagline: 'Especialista en Otorrinolaringología y Cirugía de Cabeza y Cuello. Atención humana, ética y de alta calidad con las técnicas más modernas y menos invasivas.',
    certifications: [
      'Sociedad Mexicana de Otorrinolaringología y CCC',
      'Médico adscrito al IMSS desde 2016',
    ],
  },
  services: [
    { id: 'consulta', name: 'Consulta ORL General', icon: 'stethoscope' },
    { id: 'audiologia', name: 'Audiología', icon: 'ear' },
    { id: 'vacunacion', name: 'Vacunación', icon: 'syringe' },
    { id: 'rinitis', name: 'Rinitis Alérgica e Inmunoterapia', icon: 'allergen' },
    { id: 'cirugia', name: 'Cirugía ORL', icon: 'surgery' },
    { id: 'vertigo', name: 'Vértigo y Equilibrio', icon: 'balance' },
  ],
  reviews: [
    { name: 'Mónica Bautista', rating: 5, text: 'Urgentemente necesitaba un otorrino y lo encontré por Google Maps. Lo recomiendo ampliamente. Muy amable, considerado, me explicó la causa de mi dolencia y nada abusivo en pedir estudios. Calidad humana de doctor.' },
    { name: 'Yazmín García', rating: 5, text: 'Ha sido una experiencia increíble, servicio y atención de primera. Gracias a la atención oportuna varios de mis padecimientos han desaparecido. Agradezco su profesionalismo y calidad humana.' },
    { name: 'Karen Sandoval', rating: 5, text: 'Un excelente doctor. Atendió a mi mamá con mucho profesionalismo, muy amable y explicó todo detalladamente. Le agradezco mucho su atención. Lo recomiendo totalmente.' },
    { name: 'Alejandra Vázquez', rating: 5, text: 'Extraordinaria intervención, muy valiosa la visión sistémica del Doctor Alejandro Viveros, gran atención. Altamente recomendable.' },
    { name: 'Consuelo Domínguez', rating: 5, text: 'Muy buen doctor. Llevé a mi hijo y el diagnóstico muy acertado; el doctor muy paciente y muy amable.' },
    { name: 'Mijo León', rating: 5, text: 'Excelente doctor, muy buena atención, súper profesional. Estoy muy agradecido por sus atenciones como médico. Muy recomendable.' },
  ],
  rating: { average: 5.0, total: 6 },
  contact: {
    address: 'Chosica 730, Col. Lindavista',
    city: 'Gustavo A. Madero, CDMX · 07300',
    schedule: [
      { days: 'Lunes a Miércoles', hours: '16:00 – 20:00' },
      { days: 'Jueves y Viernes', hours: '10:00 – 14:00' },
      { days: 'Sábado y Domingo', hours: 'Cerrado' },
    ],
  },
};
