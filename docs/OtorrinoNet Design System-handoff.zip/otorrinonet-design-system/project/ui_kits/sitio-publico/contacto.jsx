/* Página de Contacto */

function Field({ label, value, onChange, placeholder, type = 'text', required }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <div>
      <label style={{ display: 'block', fontSize: 13, fontWeight: 600,
        color: 'var(--text-strong)', marginBottom: 6 }}>{label}</label>
      <input
        type={type} value={value} onChange={e => onChange(e.target.value)}
        placeholder={placeholder} required={required}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        style={{ width: '100%', padding: '10px 14px', borderRadius: 'var(--radius-lg)',
          border: `1px solid ${focus ? 'var(--brand-primary)' : 'var(--border-default)'}`,
          fontFamily: 'var(--font-sans)', fontSize: 14, color: 'var(--text-body)',
          background: 'var(--surface-input)', boxSizing: 'border-box', outline: 'none',
          transition: 'border-color .15s' }} />
    </div>
  );
}

function ContactoPage({ onNav }) {
  const c = window.OTORRINO_DATA.contact;
  const [form, setForm] = React.useState({ name: '', email: '', phone: '', message: '' });
  const [sent, setSent] = React.useState(false);
  const [focusTa, setFocusTa] = React.useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <>
      {/* ── Header ── */}
      <section style={{ background: 'var(--surface-card)', borderBottom: '1px solid var(--border-subtle)', padding: '56px 0' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px' }}>
          <Eyebrow>Escríbenos</Eyebrow>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 40, fontWeight: 700,
            color: 'var(--text-strong)', margin: '12px 0 0', lineHeight: 1.08 }}>
            Contacto
          </h1>
        </div>
      </section>

      {/* ── Body ── */}
      <section style={{ padding: '64px 0', background: 'var(--surface-page)' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px',
          display: 'grid', gridTemplateColumns: '1fr 1.3fr', gap: 64 }}>

          {/* ─ Info ─ */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 36 }}>
            <div>
              <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 22, fontWeight: 700,
                color: 'var(--text-strong)', margin: '0 0 24px' }}>
                Información del consultorio
              </h2>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
                {/* Dirección */}
                <div style={{ display: 'flex', gap: 14 }}>
                  <span style={{ width: 40, height: 40, borderRadius: 'var(--radius-lg)',
                    background: 'var(--color-sky-50)', display: 'flex', alignItems: 'center',
                    justifyContent: 'center', flex: 'none', color: 'var(--brand-primary)' }}>
                    <MapPin size={18} />
                  </span>
                  <div>
                    <p style={{ margin: '0 0 3px', fontWeight: 600, fontSize: 14, color: 'var(--text-strong)' }}>Dirección</p>
                    <p style={{ margin: 0, fontSize: 14, color: 'var(--text-body)', lineHeight: 1.55 }}>
                      {c.address}<br />{c.city}
                    </p>
                  </div>
                </div>

                {/* Horario */}
                <div style={{ display: 'flex', gap: 14 }}>
                  <span style={{ width: 40, height: 40, borderRadius: 'var(--radius-lg)',
                    background: 'var(--color-sky-50)', display: 'flex', alignItems: 'center',
                    justifyContent: 'center', flex: 'none', color: 'var(--brand-primary)' }}>
                    <Clock size={18} />
                  </span>
                  <div style={{ flex: 1 }}>
                    <p style={{ margin: '0 0 10px', fontWeight: 600, fontSize: 14, color: 'var(--text-strong)' }}>
                      Horario de atención
                    </p>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
                      {c.schedule.map((s, i) => (
                        <div key={i} style={{ display: 'flex', justifyContent: 'space-between', gap: 16,
                          fontSize: 13.5, color: 'var(--text-body)' }}>
                          <span>{s.days}</span>
                          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12.5, fontWeight: 600,
                            color: s.hours === 'Cerrado' ? 'var(--text-muted)' : 'var(--text-strong)' }}>
                            {s.hours}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Cita rápida */}
            <div style={{ padding: '20px 24px', background: 'var(--color-sky-50)', borderRadius: 'var(--radius-xl)',
              border: '1px solid var(--color-sky-100)' }}>
              <p style={{ margin: '0 0 14px', fontSize: 14, fontWeight: 600, color: 'var(--color-sky-700)' }}>
                ¿Prefieres agendar directamente?
              </p>
              <Button icon={Calendar} onClick={() => onNav('agendar')}>Agendar Cita en línea</Button>
            </div>

            {/* Ubicación */}
            <button onClick={() => onNav('ubicacion')}
              style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'none', border: 'none',
                cursor: 'pointer', color: 'var(--brand-primary)', fontFamily: 'var(--font-sans)',
                fontSize: 13.5, fontWeight: 600, padding: 0, width: 'fit-content' }}>
              <MapPin size={15} />
              Ver cómo llegar al consultorio
              <ArrowUR size={14} />
            </button>
          </div>

          {/* ─ Formulario ─ */}
          <div style={{ background: 'var(--surface-card)', borderRadius: 'var(--radius-2xl)',
            padding: 40, border: '1px solid var(--border-subtle)', boxShadow: 'var(--shadow-sm)' }}>

            {sent ? (
              <div style={{ textAlign: 'center', padding: '40px 20px' }}>
                <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'var(--color-sky-50)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px',
                  color: 'var(--brand-primary)' }}>
                  <Check size={24} />
                </div>
                <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: 22, fontWeight: 700,
                  color: 'var(--text-strong)', margin: '0 0 12px' }}>Mensaje enviado</h3>
                <p style={{ color: 'var(--text-body)', fontSize: 14.5, lineHeight: 1.65, margin: '0 0 24px' }}>
                  Nos pondremos en contacto contigo a la brevedad posible.
                </p>
                <Button variant="secondary" onClick={() => { setForm({ name:'', email:'', phone:'', message:'' }); setSent(false); }}>
                  Enviar otro mensaje
                </Button>
              </div>
            ) : (
              <>
                <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 22, fontWeight: 700,
                  color: 'var(--text-strong)', margin: '0 0 28px' }}>
                  Envíanos un mensaje
                </h2>
                <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                    <Field label="Nombre completo" value={form.name}
                      onChange={v => setForm(f => ({ ...f, name: v }))} placeholder="Tu nombre" required />
                    <Field label="Teléfono" value={form.phone}
                      onChange={v => setForm(f => ({ ...f, phone: v }))} placeholder="55 1234 5678" />
                  </div>
                  <Field label="Correo electrónico" value={form.email}
                    onChange={v => setForm(f => ({ ...f, email: v }))}
                    placeholder="correo@ejemplo.com" type="email" required />
                  <div>
                    <label style={{ display: 'block', fontSize: 13, fontWeight: 600,
                      color: 'var(--text-strong)', marginBottom: 6 }}>Mensaje</label>
                    <textarea
                      value={form.message}
                      onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                      onFocus={() => setFocusTa(true)} onBlur={() => setFocusTa(false)}
                      placeholder="Cuéntanos en qué podemos ayudarte..." required
                      style={{ width: '100%', minHeight: 110, padding: '10px 14px',
                        borderRadius: 'var(--radius-lg)',
                        border: `1px solid ${focusTa ? 'var(--brand-primary)' : 'var(--border-default)'}`,
                        fontFamily: 'var(--font-sans)', fontSize: 14, color: 'var(--text-body)',
                        background: 'var(--surface-input)', resize: 'vertical', boxSizing: 'border-box',
                        outline: 'none', transition: 'border-color .15s' }} />
                  </div>
                  <Button>Enviar mensaje</Button>
                </form>
              </>
            )}
          </div>
        </div>
      </section>
    </>
  );
}

Object.assign(window, { ContactoPage, Field });
