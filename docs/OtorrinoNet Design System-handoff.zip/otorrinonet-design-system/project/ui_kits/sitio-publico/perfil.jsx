/* Página de Perfil completo — Dr. Alejandro Viveros Domínguez */

const education = [
  {
    year: '2008 – 2014',
    degree: 'Médico Cirujano',
    institution: 'Universidad Nacional Autónoma de México',
    detail: 'Facultad de Medicina, UNAM',
  },
  {
    year: '2015 – 2019',
    degree: 'Especialidad en Otorrinolaringología y CCC',
    institution: 'Hospital de Especialidades CMN Siglo XXI — IMSS',
    detail: 'Residencia médica certificada',
  },
  {
    year: '2019 – actual',
    degree: 'Médico Adscrito en ORL',
    institution: 'Instituto Mexicano del Seguro Social',
    detail: 'Atención institucional y consulta privada',
  },
];

const certRows = [
  'Sociedad Mexicana de Otorrinolaringología y Cirugía de Cabeza y Cuello',
  'Consejo Mexicano de Otorrinolaringología y CCC',
  'Médico adscrito al IMSS desde 2016',
  'Cédula profesional 6277305 — SEP',
];

const stats = [
  { value: '10+', label: 'Años de experiencia' },
  { value: '5.0★', label: 'Calificación Google' },
  { value: 'IMSS', label: 'Médico adscrito' },
  { value: 'UNAM', label: 'Formación médica' },
];

function PerfilPage({ onNav }) {
  const d = window.OTORRINO_DATA.doctor;

  return (
    <>
      {/* ── Hero ── */}
      <section style={{ background: 'var(--surface-card)', borderBottom: '1px solid var(--border-subtle)', padding: '72px 0' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px',
          display: 'grid', gridTemplateColumns: '1fr 320px', gap: 64, alignItems: 'start' }}>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <Eyebrow>Médico Especialista</Eyebrow>
            <div>
              <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 42, fontWeight: 700,
                color: 'var(--text-strong)', lineHeight: 1.08, letterSpacing: '-.02em', margin: 0 }}>
                {d.fullName}
              </h1>
              <p style={{ fontSize: 17, color: 'var(--brand-primary)', fontWeight: 600, margin: '10px 0 0' }}>
                {d.title}
              </p>
            </div>
            <p style={{ color: 'var(--text-body)', lineHeight: 1.7, fontSize: 15.5, maxWidth: 560, margin: 0 }}>
              Con más de {d.yearsOfExperience} años de trayectoria, el Dr. Viveros combina el rigor académico
              de su formación en la UNAM y el IMSS con un trato humano y personalizado. Atiende a pacientes
              de todas las edades con las técnicas más modernas y menos invasivas disponibles en México.
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {d.certifications.map((c, i) => (
                <span key={i} style={{ fontSize: 11, background: 'var(--surface-sunken)',
                  color: 'var(--text-body)', padding: '5px 11px', borderRadius: 'var(--radius-full)', fontWeight: 500 }}>
                  {c}
                </span>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 12, marginTop: 4 }}>
              <Button icon={Calendar} onClick={() => onNav('agendar')}>Agendar Cita</Button>
              <Button variant="secondary" icon={Phone} onClick={() => onNav('contacto')}>Contactar</Button>
            </div>
          </div>

          <div style={{ position: 'relative' }}>
            <div style={{ borderRadius: 'var(--radius-2xl)', overflow: 'hidden', boxShadow: 'var(--shadow-2xl)' }}>
              <img src={d.photo} alt={d.fullName}
                style={{ width: '100%', aspectRatio: '3/4', objectFit: 'cover', objectPosition: 'center top', display: 'block' }} />
            </div>
            <div style={{ position: 'absolute', bottom: -16, right: -16, background: 'var(--surface-card)',
              borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-xl)', padding: '12px 16px',
              border: '1px solid var(--border-subtle)' }}>
              <p style={{ margin: 0, fontSize: 10, fontWeight: 700, color: 'var(--brand-primary)',
                textTransform: 'uppercase', letterSpacing: '.08em' }}>Cédula Prof.</p>
              <p style={{ margin: 0, fontSize: 14, fontWeight: 700, fontFamily: 'var(--font-mono)',
                color: 'var(--text-strong)' }}>{d.licenseNumber}</p>
            </div>
          </div>
        </div>
      </section>

      {/* ── Stats band ── */}
      <section style={{ background: 'var(--color-sky-600)', padding: '44px 0' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px',
          display: 'grid', gridTemplateColumns: 'repeat(4,1fr)' }}>
          {stats.map((s, i) => (
            <div key={i} style={{ textAlign: 'center', padding: '12px 20px',
              borderRight: i < stats.length - 1 ? '1px solid rgba(255,255,255,.2)' : 'none' }}>
              <div style={{ fontFamily: 'var(--font-heading)', fontSize: 34, fontWeight: 700, color: '#fff', lineHeight: 1 }}>
                {s.value}
              </div>
              <div style={{ fontSize: 12, color: 'var(--color-sky-100)', marginTop: 6, fontWeight: 500 }}>
                {s.label}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Formación + Certificaciones ── */}
      <section style={{ padding: '80px 0', background: 'var(--surface-page)' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px',
          display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 72 }}>

          {/* Timeline */}
          <div>
            <Eyebrow>Trayectoria</Eyebrow>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 700,
              color: 'var(--text-strong)', margin: '12px 0 36px' }}>Formación Académica</h2>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              {education.map((e, i) => (
                <div key={i} style={{ display: 'flex', gap: 20, paddingBottom: i < education.length - 1 ? 36 : 0 }}>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <div style={{ width: 10, height: 10, borderRadius: '50%', background: 'var(--brand-primary)',
                      flex: 'none', marginTop: 5 }} />
                    {i < education.length - 1 && (
                      <div style={{ width: 2, flex: 1, background: 'var(--border-default)', marginTop: 6 }} />
                    )}
                  </div>
                  <div>
                    <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--brand-primary)',
                      fontFamily: 'var(--font-mono)' }}>{e.year}</span>
                    <p style={{ margin: '4px 0 2px', fontSize: 15, fontWeight: 600, color: 'var(--text-strong)' }}>
                      {e.degree}
                    </p>
                    <p style={{ margin: 0, fontSize: 13.5, color: 'var(--text-body)' }}>{e.institution}</p>
                    <p style={{ margin: '2px 0 0', fontSize: 12, color: 'var(--text-muted)' }}>{e.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Certifications */}
          <div>
            <Eyebrow>Membresías</Eyebrow>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 700,
              color: 'var(--text-strong)', margin: '12px 0 36px' }}>Certificaciones y Sociedades</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {certRows.map((m, i) => (
                <div key={i} style={{ display: 'flex', gap: 14, alignItems: 'flex-start',
                  padding: '16px 20px', background: 'var(--surface-card)', borderRadius: 'var(--radius-lg)',
                  border: '1px solid var(--border-subtle)' }}>
                  <span style={{ width: 24, height: 24, borderRadius: 'var(--radius-md)',
                    background: 'var(--color-sky-50)', display: 'flex', alignItems: 'center',
                    justifyContent: 'center', flex: 'none', color: 'var(--brand-primary)' }}>
                    <Check size={13} />
                  </span>
                  <span style={{ fontSize: 14, color: 'var(--text-body)', lineHeight: 1.5 }}>{m}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section style={{ padding: '72px 0', background: 'var(--surface-card)', borderTop: '1px solid var(--border-subtle)' }}>
        <div style={{ maxWidth: 560, margin: '0 auto', padding: '0 24px', textAlign: 'center' }}>
          <Eyebrow>Primera consulta disponible esta semana</Eyebrow>
          <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 30, fontWeight: 700,
            color: 'var(--text-strong)', margin: '12px 0 16px' }}>¿Listo para una consulta?</h2>
          <p style={{ color: 'var(--text-body)', fontSize: 15, lineHeight: 1.65, marginBottom: 28 }}>
            Agenda en línea o contáctanos para más información.
          </p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Button icon={Calendar} onClick={() => onNav('agendar')}>Agendar en línea</Button>
            <Button variant="secondary" iconR={ArrowUR} onClick={() => onNav('servicios')}>Ver servicios</Button>
          </div>
        </div>
      </section>
    </>
  );
}

Object.assign(window, { PerfilPage });
