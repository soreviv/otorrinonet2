/* Lucide-style icons + brand UI primitives for the Dr. Viveros public site.
   Self-contained (no external bundle); styled with the design-system tokens
   linked via styles.css. */

const Ic = ({ children, size = 20, sw = 1.75, ...p }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
       strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" {...p}>{children}</svg>
);
const Calendar   = (p) => <Ic {...p}><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></Ic>;
const ChevronR   = (p) => <Ic {...p}><path d="m9 18 6-6-6-6"/></Ic>;
const ArrowUR    = (p) => <Ic {...p}><path d="M7 17 17 7M7 7h10v10"/></Ic>;
const Star       = ({ size = 14, fill = 'none', ...p }) => <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={fill==='none'?'currentColor':'none'} strokeWidth="1.5" {...p}><path d="M12 2l2.9 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l7.1-1.01L12 2z"/></svg>;
const MapPin     = (p) => <Ic {...p}><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></Ic>;
const Clock      = (p) => <Ic {...p}><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></Ic>;
const Phone      = (p) => <Ic {...p}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z"/></Ic>;
const Shop       = (p) => <Ic {...p}><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18M16 10a4 4 0 0 1-8 0"/></Ic>;
const Menu       = (p) => <Ic {...p}><path d="M4 12h16M4 6h16M4 18h16"/></Ic>;
const Check      = (p) => <Ic {...p}><path d="M20 6 9 17l-5-5"/></Ic>;
const Stethoscope= (p) => <Ic {...p}><path d="M4 3v5a5 5 0 0 0 10 0V3"/><path d="M4 3H2m12 0h-2M9 18a4 4 0 0 0 8 0v-2"/><circle cx="20" cy="10" r="2"/></Ic>;
const Ear        = (p) => <Ic {...p}><path d="M6 8.5a6.5 6.5 0 1 1 13 0c0 2.5-1.5 3.5-2.5 4.5s-1.5 2-1.5 3.5a3 3 0 0 1-6 0"/><path d="M9 8.5a3 3 0 0 1 5 2"/></Ic>;
const Syringe    = (p) => <Ic {...p}><path d="m18 2 4 4M17 7 8.5 15.5M5 11l8 8M9 7l8 8M7 14l-4 4-1 1m6-3-3 3"/></Ic>;
const Flower     = (p) => <Ic {...p}><circle cx="12" cy="12" r="3"/><path d="M12 9V2M12 22v-7M15 12h7M2 12h7M19 5l-5 5M5 19l5-5M19 19l-5-5M5 5l5 5"/></Ic>;
const Scissors   = (p) => <Ic {...p}><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4 8.12 15.88M14.47 14.48 20 20M8.12 8.12 12 12"/></Ic>;
const Activity   = (p) => <Ic {...p}><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></Ic>;

const SERVICE_ICONS = { stethoscope: Stethoscope, ear: Ear, syringe: Syringe, allergen: Flower, surgery: Scissors, balance: Activity };

/* ── Primitives ─────────────────────────────────────────────────────────── */
function Eyebrow({ children, light }) {
  return <p style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.12em',
    color: light ? 'var(--color-sky-200)' : 'var(--brand-primary)', margin: 0 }}>{children}</p>;
}

function Button({ children, variant = 'primary', size = 'md', icon: Icon, iconR: IconR, onClick, href, light }) {
  const [h, setH] = React.useState(false), [a, setA] = React.useState(false);
  const sizes = { sm: '8px 14px', md: '12px 22px', lg: '15px 26px' };
  const base = {
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
    fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: size === 'lg' ? 15 : 14,
    borderRadius: 'var(--radius-lg)', padding: sizes[size], cursor: 'pointer',
    border: '1px solid transparent', textDecoration: 'none', whiteSpace: 'nowrap',
    transform: a ? 'scale(.98)' : 'none', transition: 'all .15s var(--ease-standard)',
  };
  const styles = {
    primary: { ...base, background: h ? 'var(--brand-primary-hover)' : 'var(--brand-primary)', color: '#fff',
      boxShadow: h ? 'var(--shadow-primary)' : 'none' },
    secondary: { ...base, background: h ? 'var(--brand-accent-soft)' : 'var(--surface-card)',
      color: h ? 'var(--brand-primary-hover)' : 'var(--text-body)',
      borderColor: h ? 'var(--color-sky-300)' : 'var(--border-default)' },
    onPrimary: { ...base, background: h ? 'var(--color-sky-50)' : '#fff', color: 'var(--color-sky-700)',
      boxShadow: h ? 'var(--shadow-xl)' : 'none' },
    outlineLight: { ...base, background: h ? 'rgba(3,105,161,.5)' : 'transparent', color: '#fff',
      borderColor: 'rgba(56,189,248,.6)', borderWidth: 2 },
  };
  const El = href ? 'a' : 'button';
  return (
    <El href={href} onClick={onClick} style={styles[variant]}
      onMouseEnter={() => setH(true)} onMouseLeave={() => { setH(false); setA(false); }}
      onMouseDown={() => setA(true)} onMouseUp={() => setA(false)}>
      {Icon && <Icon size={size === 'lg' ? 18 : 16} />}{children}{IconR && <IconR size={16} />}
    </El>
  );
}

function StarRow({ rating = 5, size = 14 }) {
  return <span style={{ display: 'inline-flex', gap: 2 }}>
    {[0,1,2,3,4].map(i => <Star key={i} size={size} fill={i < rating ? 'var(--color-amber-400)' : 'var(--color-slate-200)'} />)}
  </span>;
}

function Avatar({ name = '', solid, size = 40 }) {
  const init = name.trim().split(/\s+/).slice(0,2).map(n=>n[0]||'').join('').toUpperCase();
  return <span style={{ width: size, height: size, flex: 'none', borderRadius: '50%',
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    fontFamily: 'var(--font-heading)', fontWeight: 700, fontSize: size * 0.32,
    background: solid ? 'var(--brand-primary)' : 'var(--color-sky-100)',
    color: solid ? '#fff' : 'var(--color-sky-700)' }}>{init}</span>;
}

Object.assign(window, { Ic, Calendar, ChevronR, ArrowUR, Star, MapPin, Clock, Phone, Shop, Menu, Check,
  Stethoscope, Ear, Syringe, Flower, Scissors, Activity, SERVICE_ICONS,
  Eyebrow, Button, StarRow, Avatar });
