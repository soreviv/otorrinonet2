/* Agendar — 3-step appointment booking (servicio → fecha/hora → datos → listo). */

function Stepper({ step }) {
  const steps = ['Servicio', 'Fecha y hora', 'Tus datos'];
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 32 }}>
      {steps.map((s, i) => {
        const done = i < step, active = i === step;
        return (
          <React.Fragment key={s}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 28, height: 28, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 13, fontWeight: 700, fontFamily: 'var(--font-mono)',
                background: done ? 'var(--brand-primary)' : active ? 'var(--color-sky-50)' : 'var(--surface-sunken)',
                color: done ? '#fff' : active ? 'var(--brand-primary)' : 'var(--text-muted)',
                border: active ? '1.5px solid var(--brand-primary)' : '1.5px solid transparent' }}>
                {done ? <Check size={15} /> : i + 1}</span>
              <span style={{ fontSize: 13, fontWeight: active ? 600 : 500, color: active || done ? 'var(--text-strong)' : 'var(--text-muted)' }} className="step-label">{s}</span>
            </div>
            {i < steps.length - 1 && <span style={{ flex: 1, height: 1.5, background: done ? 'var(--brand-primary)' : 'var(--border-default)', minWidth: 16 }} />}
          </React.Fragment>
        );
      })}
    </div>
  );
}

function Field({ label, value, onChange, placeholder, type = 'text', required }) {
  const [f, setF] = React.useState(false);
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-strong)' }}>{label}{required && <span style={{ color: 'var(--color-rose-600)' }}> *</span>}</span>
      <input type={type} value={value} placeholder={placeholder} onChange={e => onChange(e.target.value)}
        onFocus={() => setF(true)} onBlur={() => setF(false)}
        style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: 'var(--text-strong)', background: 'var(--surface-card)',
          border: `1px solid ${f ? 'var(--border-focus)' : 'var(--border-default)'}`, borderRadius: 'var(--radius-lg)',
          padding: '11px 14px', outline: 'none', boxShadow: f ? '0 0 0 3px rgb(14 165 233 / .18)' : 'none', transition: 'all .15s' }} />
    </label>
  );
}

function AgendarPage({ onNav }) {
  const [step, setStep] = React.useState(0);
  const [svc, setSvc] = React.useState(null);
  const [date, setDate] = React.useState(null);
  const [time, setTime] = React.useState(null);
  const [form, setForm] = React.useState({ name: '', phone: '', email: '', reason: '' });
  const services = window.OTORRINO_DATA.services;

  const days = [
    { d: 'Lun', n: '9', m: 'jun' }, { d: 'Mar', n: '10', m: 'jun' }, { d: 'Mié', n: '11', m: 'jun' },
    { d: 'Jue', n: '12', m: 'jun' }, { d: 'Vie', n: '13', m: 'jun' },
  ];
  const times = ['10:00', '10:30', '11:00', '16:00', '16:30', '17:00', '17:30', '18:00'];

  const card = { background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-2xl)',
    padding: 32, boxShadow: 'var(--shadow-sm)' };

  return (
    <div style={{ background: 'var(--surface-page)', minHeight: '70vh', padding: '48px 24px' }}>
      <div style={{ maxWidth: 640, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <Eyebrow>Cita en línea</Eyebrow>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 32, fontWeight: 700, color: 'var(--text-strong)', margin: '10px 0 0' }}>Agenda tu consulta</h1>
        </div>

        {step < 3 && <Stepper step={step} />}

        {step === 0 && (
          <div style={card}>
            <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: 17, margin: '0 0 16px', color: 'var(--text-strong)' }}>¿Qué servicio necesitas?</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              {services.map(s => {
                const Icon = SERVICE_ICONS[s.icon] || Stethoscope, sel = svc === s.id;
                return (
                  <button key={s.id} onClick={() => setSvc(s.id)} style={{ display: 'flex', alignItems: 'center', gap: 12, textAlign: 'left',
                    padding: 14, borderRadius: 'var(--radius-lg)', cursor: 'pointer',
                    background: sel ? 'var(--color-sky-50)' : 'var(--surface-card)',
                    border: `1.5px solid ${sel ? 'var(--brand-primary)' : 'var(--border-default)'}`, transition: 'all .15s' }}>
                    <span style={{ width: 38, height: 38, borderRadius: 'var(--radius-md)', flex: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
                      background: sel ? 'var(--brand-primary)' : 'var(--color-sky-50)', color: sel ? '#fff' : 'var(--brand-primary)' }}><Icon size={18} /></span>
                    <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-strong)' }}>{s.name}</span>
                  </button>
                );
              })}
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 24 }}>
              <Button onClick={() => svc && setStep(1)} iconR={ChevronR}>Continuar</Button>
            </div>
          </div>
        )}

        {step === 1 && (
          <div style={card}>
            <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: 17, margin: '0 0 16px', color: 'var(--text-strong)' }}>Elige fecha y hora</h3>
            <p style={{ fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', color: 'var(--text-muted)', margin: '0 0 10px' }}>Junio 2026</p>
            <div style={{ display: 'flex', gap: 10, marginBottom: 24 }}>
              {days.map(dy => {
                const sel = date === dy.n;
                return <button key={dy.n} onClick={() => setDate(dy.n)} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
                  padding: '12px 0', borderRadius: 'var(--radius-lg)', cursor: 'pointer',
                  background: sel ? 'var(--brand-primary)' : 'var(--surface-card)', border: `1.5px solid ${sel ? 'var(--brand-primary)' : 'var(--border-default)'}`, transition: 'all .15s' }}>
                  <span style={{ fontSize: 11, fontWeight: 600, color: sel ? 'rgba(255,255,255,.8)' : 'var(--text-muted)' }}>{dy.d}</span>
                  <span style={{ fontSize: 18, fontWeight: 700, fontFamily: 'var(--font-heading)', color: sel ? '#fff' : 'var(--text-strong)' }}>{dy.n}</span>
                </button>;
              })}
            </div>
            <p style={{ fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', color: 'var(--text-muted)', margin: '0 0 10px' }}>Horarios disponibles</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
              {times.map(t => {
                const sel = time === t;
                return <button key={t} onClick={() => setTime(t)} style={{ padding: '10px 0', borderRadius: 'var(--radius-lg)', cursor: 'pointer',
                  fontSize: 13, fontWeight: 600, fontFamily: 'var(--font-mono)',
                  background: sel ? 'var(--color-sky-50)' : 'var(--surface-card)', color: sel ? 'var(--brand-primary)' : 'var(--text-body)',
                  border: `1.5px solid ${sel ? 'var(--brand-primary)' : 'var(--border-default)'}`, transition: 'all .15s' }}>{t}</button>;
              })}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 24 }}>
              <Button variant="secondary" onClick={() => setStep(0)}>Atrás</Button>
              <Button onClick={() => date && time && setStep(2)} iconR={ChevronR}>Continuar</Button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div style={card}>
            <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: 17, margin: '0 0 16px', color: 'var(--text-strong)' }}>Tus datos de contacto</h3>
            <div style={{ display: 'grid', gap: 14 }}>
              <Field label="Nombre completo" required value={form.name} onChange={v => setForm({ ...form, name: v })} placeholder="Tu nombre" />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                <Field label="Teléfono" required type="tel" value={form.phone} onChange={v => setForm({ ...form, phone: v })} placeholder="55 1234 5678" />
                <Field label="Correo" type="email" value={form.email} onChange={v => setForm({ ...form, email: v })} placeholder="tu@correo.com" />
              </div>
              <Field label="Motivo de consulta" value={form.reason} onChange={v => setForm({ ...form, reason: v })} placeholder="Describe brevemente tu padecimiento" />
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 24 }}>
              <Button variant="secondary" onClick={() => setStep(1)}>Atrás</Button>
              <Button onClick={() => form.name && form.phone && setStep(3)} icon={Check}>Confirmar cita</Button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div style={{ ...card, textAlign: 'center', padding: 44 }}>
            <span style={{ width: 64, height: 64, borderRadius: '50%', background: 'var(--color-emerald-50)', display: 'inline-flex',
              alignItems: 'center', justifyContent: 'center', color: 'var(--color-emerald-500)', marginBottom: 20 }}><Check size={32} /></span>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 700, color: 'var(--text-strong)', margin: '0 0 8px' }}>¡Cita solicitada!</h2>
            <p style={{ color: 'var(--text-body)', fontSize: 14, lineHeight: 1.6, maxWidth: 380, margin: '0 auto 24px' }}>
              Recibimos tu solicitud para el <b style={{ color: 'var(--text-strong)' }}>{date} de junio a las {time} hrs</b>. Te enviaremos la confirmación por correo y WhatsApp.
            </p>
            <div style={{ background: 'var(--surface-page)', borderRadius: 'var(--radius-xl)', padding: 20, textAlign: 'left', maxWidth: 380, margin: '0 auto 24px' }}>
              {[['Paciente', form.name || '—'], ['Servicio', (services.find(s => s.id === svc) || {}).name || '—'], ['Fecha', `${date} jun · ${time} hrs`]].map(([k, v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '7px 0', fontSize: 13 }}>
                  <span style={{ color: 'var(--text-muted)' }}>{k}</span><span style={{ fontWeight: 600, color: 'var(--text-strong)' }}>{v}</span>
                </div>
              ))}
            </div>
            <Button onClick={() => onNav('inicio')}>Volver al inicio</Button>
          </div>
        )}
      </div>
    </div>
  );
}

window.AgendarPage = AgendarPage;
