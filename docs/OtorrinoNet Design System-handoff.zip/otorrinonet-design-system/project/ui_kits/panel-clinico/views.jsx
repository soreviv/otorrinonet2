/* StaffShell + Agenda + Expedientes + Dashboard views. */

const NAV = [
  { id: 'dashboard', label: 'Dashboard', icon: 'Steth2' },
  { id: 'agenda', label: 'Agenda de Citas', icon: 'CalDays' },
  { id: 'ehr', label: 'Expediente Clínico', icon: 'Clip' },
  { id: 'recetas', label: 'Recetas', icon: 'Scroll' },
  { id: 'notas', label: 'Notas de Evolución', icon: 'Clip' },
  { id: 'tienda', label: 'Pedidos de Tienda', icon: 'Bag' },
  { id: 'productos', label: 'Productos', icon: 'Box' },
  { id: 'admin', label: 'Administración', icon: 'Shield' },
  { id: 'config', label: 'Configuración', icon: 'Gear' },
];
const ICONS = { Steth2, CalDays, Clip, Scroll, Bag, Box, Shield, Gear };

function StaffShell({ view, onView, children }) {
  const u = window.STAFF_DATA.user;
  const init = u.name.split(' ').slice(0, 2).map(n => n[0]).join('').toUpperCase();
  return (
    <div style={{ minHeight: '100vh', display: 'flex', background: 'var(--surface-page)' }}>
      <aside style={{ width: 'var(--sidebar-w)', flex: 'none', display: 'flex', flexDirection: 'column',
        background: 'var(--surface-card)', borderRight: '1px solid var(--border-default)' }} className="staff-aside">
        <div style={{ height: 'var(--header-h)', display: 'flex', alignItems: 'center', gap: 10, padding: '0 16px',
          borderBottom: '1px solid var(--border-default)' }}>
          <span style={{ width: 32, height: 32, borderRadius: 'var(--radius-md)', background: 'var(--brand-primary)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none' }}><Steth2 size={17} sw={1.9} style={{ color: '#fff' }} /></span>
          <div style={{ lineHeight: 1.15, minWidth: 0 }}>
            <div style={{ fontSize: 14, fontWeight: 600, fontFamily: 'var(--font-heading)', color: 'var(--text-strong)' }}>Dr. Viveros · ORL</div>
            <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--brand-primary)', textTransform: 'uppercase', letterSpacing: '.08em' }}>Panel Clínico</div>
          </div>
        </div>
        <nav style={{ flex: 1, padding: '12px 8px', overflowY: 'auto' }}>
          <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: 2 }}>
            {NAV.map(item => {
              const Icon = ICONS[item.icon], active = view === item.id;
              return (
                <li key={item.id}>
                  <button onClick={() => onView(item.id)} className={'nav-item' + (active ? ' active' : '')}>
                    <Icon size={17} sw={active ? 2 : 1.75} style={{ flex: 'none' }} />
                    <span style={{ fontSize: 13.5, fontWeight: active ? 600 : 500 }}>{item.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>
        <div style={{ borderTop: '1px solid var(--border-default)', padding: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <SAvatar name={u.name} size={36} />
            <div style={{ flex: 1, minWidth: 0, lineHeight: 1.2 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-strong)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{u.name}</div>
              <span style={{ display: 'inline-block', fontSize: 10, fontWeight: 600, padding: '1px 7px', borderRadius: 'var(--radius-full)',
                background: 'var(--color-sky-100)', color: 'var(--color-sky-700)', marginTop: 3 }}>{u.role}</span>
            </div>
          </div>
          <button style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 8, marginTop: 10, padding: '7px 8px',
            borderRadius: 'var(--radius-md)', cursor: 'pointer', background: 'transparent', border: 0,
            color: 'var(--text-muted)', fontSize: 12, fontFamily: 'var(--font-sans)' }}
            onMouseEnter={e => { e.currentTarget.style.background = 'var(--color-rose-50)'; e.currentTarget.style.color = 'var(--color-rose-600)'; }}
            onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--text-muted)'; }}>
            <LogOut size={14} />Cerrar sesión
          </button>
        </div>
      </aside>
      <main style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>{children}</main>
    </div>
  );
}

/* ── Agenda ─────────────────────────────────────────────────────────────── */
function Agenda() {
  const apts = window.STAFF_DATA.appointments;
  const [selId, setSelId] = React.useState(apts[0].id);
  const [q, setQ] = React.useState('');
  const filtered = apts.filter(a => !q || a.name.toLowerCase().includes(q.toLowerCase()) || a.phone.includes(q));
  const groups = {};
  filtered.forEach(a => { (groups[a.day] = groups[a.day] || []).push(a); });
  const sel = apts.find(a => a.id === selId);
  const pending = apts.filter(a => a.status === 'pendiente').length;

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <aside style={{ width: 440, flex: 'none', display: 'flex', flexDirection: 'column', background: 'var(--surface-card)', borderRight: '1px solid var(--border-default)' }} className="agenda-list">
        <div style={{ padding: '24px 24px 16px', borderBottom: '1px solid var(--border-subtle)' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
            <div>
              <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 20, fontWeight: 700, color: 'var(--text-strong)', margin: 0 }}>Agenda de Citas</h1>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}>
                <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>4 citas hoy</span>
                {pending > 0 && <SBadge variant="warning" dot sm>{pending} pendientes</SBadge>}
              </div>
            </div>
            <SButton icon={SPlus} size="sm">Nueva</SButton>
          </div>
          <div style={{ position: 'relative', marginTop: 16 }}>
            <SSearch size={16} style={{ position: 'absolute', left: 12, top: 11, color: 'var(--text-muted)' }} />
            <input value={q} onChange={e => setQ(e.target.value)} placeholder="Buscar paciente o teléfono…"
              style={{ width: '100%', boxSizing: 'border-box', padding: '10px 14px 10px 36px', fontSize: 13, fontFamily: 'var(--font-sans)',
                background: 'var(--surface-sunken)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-lg)', outline: 'none', color: 'var(--text-strong)' }} />
          </div>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0' }}>
          {Object.entries(groups).map(([day, list]) => (
            <div key={day}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '8px 24px' }}>
                <span style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.1em',
                  color: day.startsWith('Hoy') ? 'var(--brand-primary)' : 'var(--text-muted)' }}>{day}</span>
                <span style={{ flex: 1, height: 1, background: 'var(--border-subtle)' }} />
                <span style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>{list.length}</span>
              </div>
              {list.map(a => {
                const cfg = STATUS[a.status], on = a.id === selId;
                return (
                  <button key={a.id} onClick={() => setSelId(a.id)} className={'agenda-row' + (on ? ' active' : '')}>
                    {on && <span style={{ position: 'absolute', left: 0, top: 8, bottom: 8, width: 3, borderRadius: '0 3px 3px 0', background: 'var(--color-sky-500)' }} />}
                    <SAvatar name={a.name} size={36} variant={on ? 'solid' : 'neutral'} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                        <span style={{ fontSize: 13.5, fontWeight: 600, color: on ? 'var(--color-sky-900)' : 'var(--text-strong)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.name}</span>
                        <span style={{ fontSize: 12, fontFamily: 'var(--font-mono)', color: 'var(--text-muted)', flex: 'none' }}>{a.time}</span>
                      </div>
                      <div style={{ fontSize: 12, color: 'var(--text-body)', marginTop: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.service}</div>
                      <div style={{ marginTop: 8 }}><SBadge variant={cfg.variant} dot sm>{cfg.label}</SBadge></div>
                    </div>
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </aside>
      <section style={{ flex: 1, minWidth: 0, overflowY: 'auto', background: 'var(--surface-card)' }} className="agenda-detail">
        {sel && <AptDetail apt={sel} />}
      </section>
    </div>
  );
}

function AptDetail({ apt }) {
  const cfg = STATUS[apt.status];
  const Row = ({ icon: Icon, accent, label, value, mono }) => (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <span style={{ width: 32, height: 32, borderRadius: 'var(--radius-md)', flex: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: accent ? 'var(--color-sky-50)' : 'var(--surface-sunken)', color: accent ? 'var(--brand-primary)' : 'var(--text-muted)' }}><Icon size={15} sw={1.6} /></span>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.06em', color: 'var(--text-muted)' }}>{label}</div>
        <div style={{ fontSize: 13.5, fontWeight: 500, color: 'var(--text-strong)', fontFamily: mono ? 'var(--font-mono)' : 'inherit' }}>{value}</div>
      </div>
    </div>
  );
  const card = { background: 'var(--surface-page)', borderRadius: 'var(--radius-xl)', padding: 16, display: 'flex', flexDirection: 'column', gap: 14 };
  return (
    <div>
      <div style={{ background: 'var(--brand-primary)', padding: '24px 32px', display: 'flex', alignItems: 'center', gap: 16 }}>
        <SAvatar name={apt.name} size={56} variant="onPrimary" />
        <div>
          <h2 style={{ color: '#fff', fontSize: 21, fontWeight: 600, fontFamily: 'var(--font-heading)', margin: 0 }}>{apt.name}</h2>
          <div style={{ marginTop: 6 }}><SBadge variant={cfg.variant} dot>{cfg.label}</SBadge></div>
        </div>
      </div>
      <div style={{ padding: '24px 32px', maxWidth: 520, display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div style={card}>
          <Row icon={CalDays} accent label="Fecha" value={apt.day} />
          <div style={{ height: 1, background: 'var(--border-default)' }} />
          <Row icon={SClock} accent label="Hora" value={`${apt.time} hrs`} mono />
          <div style={{ height: 1, background: 'var(--border-default)' }} />
          <Row icon={SUser} accent label="Servicio" value={apt.service} />
        </div>
        <div style={card}>
          <Row icon={SPhone} label="Teléfono" value={apt.phone} mono />
          <div style={{ height: 1, background: 'var(--border-default)' }} />
          <Row icon={SMail} label="Correo" value={apt.email} />
        </div>
        <div style={{ background: 'var(--surface-page)', borderRadius: 'var(--radius-xl)', padding: 16 }}>
          <div style={{ fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.06em', color: 'var(--text-muted)', marginBottom: 8 }}>Motivo de consulta</div>
          <p style={{ margin: 0, fontSize: 13.5, color: 'var(--text-body)', lineHeight: 1.6 }}>{apt.reason}</p>
        </div>
        {apt.status === 'pendiente' ? (
          <div style={{ display: 'flex', gap: 10 }}>
            <div style={{ flex: 1 }}><SButton icon={SCheck}>Confirmar</SButton></div>
            <div style={{ flex: 1 }}><SButton variant="danger" icon={SX}>Rechazar</SButton></div>
          </div>
        ) : apt.status === 'cancelada' ? (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, padding: 14, borderRadius: 'var(--radius-lg)',
            background: 'var(--color-rose-50)', color: 'var(--color-rose-600)', fontSize: 13, fontWeight: 500 }}><SX size={15} />Esta cita fue cancelada</div>
        ) : (
          <div style={{ display: 'flex', gap: 10 }}>
            <SButton variant="secondary" icon={Refresh}>Reprogramar</SButton>
            <SButton variant="danger" icon={SX}>Cancelar</SButton>
          </div>
        )}
      </div>
    </div>
  );
}

/* ── Expedientes ────────────────────────────────────────────────────────── */
function Expedientes() {
  const pts = window.STAFF_DATA.patients;
  const [q, setQ] = React.useState('');
  const list = pts.filter(p => !q || p.name.toLowerCase().includes(q.toLowerCase()) || p.exp.toLowerCase().includes(q.toLowerCase()));
  return (
    <div style={{ overflowY: 'auto', height: '100vh' }}>
      <div style={{ maxWidth: 760, margin: '0 auto', padding: '32px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16, marginBottom: 20 }}>
          <div>
            <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 700, color: 'var(--text-strong)', margin: 0 }}>Expedientes</h1>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}>
              <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{pts.length} pacientes registrados</span>
              <SBadge variant="info" dot sm>Médico</SBadge>
            </div>
          </div>
          <SButton icon={SPlus}>Nuevo paciente</SButton>
        </div>
        <div style={{ position: 'relative', marginBottom: 16 }}>
          <SSearch size={16} style={{ position: 'absolute', left: 14, top: 13, color: 'var(--text-muted)' }} />
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Buscar por nombre o número de expediente…"
            style={{ width: '100%', boxSizing: 'border-box', padding: '12px 16px 12px 40px', fontSize: 14, fontFamily: 'var(--font-sans)',
              background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-xl)', outline: 'none',
              boxShadow: 'var(--shadow-sm)', color: 'var(--text-strong)' }} />
        </div>
        <div style={{ background: 'var(--surface-card)', borderRadius: 'var(--radius-xl)', border: '1px solid var(--border-default)', boxShadow: 'var(--shadow-sm)', overflow: 'hidden' }}>
          {list.map((p, i) => (
            <button key={p.exp} className="exp-row" style={{ borderBottom: i < list.length - 1 ? '1px solid var(--border-subtle)' : 0 }}>
              <SAvatar name={p.name} size={40} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                  <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-strong)' }}>{p.name}</span>
                  <span style={{ fontSize: 12, fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>{p.exp}</span>
                </div>
                <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 2 }}>{p.age} años · {p.sex}</div>
              </div>
              <span style={{ fontSize: 12, color: 'var(--text-muted)' }} className="exp-updated">{p.updated}</span>
              <SChevR size={16} style={{ color: 'var(--border-strong)' }} />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ── Dashboard ──────────────────────────────────────────────────────────── */
function Dashboard() {
  const d = window.STAFF_DATA.dashboard;
  const max = Math.max(...d.week.map(w => w.v));
  return (
    <div style={{ overflowY: 'auto', height: '100vh' }}>
      <div style={{ maxWidth: 980, margin: '0 auto', padding: '32px 24px' }}>
        <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 700, color: 'var(--text-strong)', margin: '0 0 4px' }}>Buenos días, Dr. Viveros</h1>
        <p style={{ fontSize: 14, color: 'var(--text-muted)', margin: '0 0 24px' }}>Lunes 9 de junio · 4 citas programadas para hoy</p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }} className="dash-stats">
          {d.stats.map(s => {
            const t = TONES[s.tone];
            return (
              <div key={s.label} style={{ background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-xl)', padding: 20, boxShadow: 'var(--shadow-sm)' }}>
                <div style={{ fontSize: 12, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.05em', color: 'var(--text-muted)' }}>{s.label}</div>
                <div style={{ fontSize: 30, fontWeight: 700, fontFamily: 'var(--font-heading)', color: 'var(--text-strong)', margin: '6px 0 8px' }}>{s.value}</div>
                <SBadge variant={s.tone} sm>{s.delta}</SBadge>
              </div>
            );
          })}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 16 }} className="dash-row">
          <div style={{ background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-xl)', padding: 24, boxShadow: 'var(--shadow-sm)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: 16, fontWeight: 700, color: 'var(--text-strong)', margin: 0 }}>Citas por día</h3>
              <SBadge variant="neutral" sm>Esta semana</SBadge>
            </div>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 16, height: 160 }}>
              {d.week.map(w => (
                <div key={w.d} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, height: '100%', justifyContent: 'flex-end' }}>
                  <span style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>{w.v}</span>
                  <div style={{ width: '100%', maxWidth: 40, height: `${Math.max(4, (w.v / max) * 130)}px`, borderRadius: '6px 6px 0 0',
                    background: w.v === max ? 'var(--brand-primary)' : 'var(--color-sky-200)' }} />
                  <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{w.d}</span>
                </div>
              ))}
            </div>
          </div>
          <div style={{ background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-xl)', padding: 24, boxShadow: 'var(--shadow-sm)' }}>
            <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: 16, fontWeight: 700, color: 'var(--text-strong)', margin: '0 0 16px' }}>Próximas citas</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {window.STAFF_DATA.appointments.slice(0, 4).map(a => (
                <div key={a.id} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <SAvatar name={a.name} size={34} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-strong)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.name}</div>
                    <div style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>{a.service}</div>
                  </div>
                  <span style={{ fontSize: 12, fontFamily: 'var(--font-mono)', color: 'var(--text-body)' }}>{a.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Placeholder({ label }) {
  return <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, color: 'var(--text-muted)' }}>
    <Box size={40} sw={1.2} /><p style={{ fontSize: 14 }}>{label} — vista no incluida en este UI kit</p></div>;
}

Object.assign(window, { StaffShell, Agenda, Expedientes, Dashboard, Placeholder });
