/* Recetas — improved prescription flow: list → official document → new form.
   Cleaner letterhead, ℞ medication entries, refined electronic-signature block. */

const RxAL    = (p) => <SIc {...p}><path d="M19 12H5M12 19l-7-7 7-7"/></SIc>;
const RxPrint = (p) => <SIc {...p}><path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8" rx="1"/></SIc>;
const RxPen   = (p) => <SIc {...p}><path d="M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></SIc>;
const RxLock  = (p) => <SIc {...p}><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></SIc>;
const RxTrash = (p) => <SIc {...p}><path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2m2 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></SIc>;
const RxPin   = (p) => <SIc {...p}><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></SIc>;
const RxPhone = (p) => <SIc {...p}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z"/></SIc>;

function fmtDate(d) {
  return new Date(d + 'T00:00:00').toLocaleDateString('es-MX', { day: '2-digit', month: 'long', year: 'numeric' });
}
function fmtStamp(iso) {
  return new Date(iso).toLocaleString('es-MX', { day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

/* ── Official prescription document ─────────────────────────────────────── */
function Receta({ rx, onBack, onSign }) {
  const D = window.STAFF_DATA.doctor, C = window.STAFF_DATA.clinic;
  const [signing, setSigning] = React.useState(false);
  const signed = rx.status === 'firmada';
  const vitals = [
    rx.patientAge != null && ['Edad', rx.patientAge + ' años'],
    rx.patientSex && ['Sexo', rx.patientSex],
    rx.patientWeight != null && ['Peso', rx.patientWeight + ' kg'],
  ].filter(Boolean);

  const lbl = { fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.1em', color: 'var(--text-muted)' };

  return (
    <div style={{ height: '100vh', overflowY: 'auto', background: 'var(--surface-page)' }}>
      {/* sticky toolbar */}
      <div style={{ position: 'sticky', top: 0, zIndex: 10, background: 'rgba(255,255,255,.92)', backdropFilter: 'blur(8px)',
        borderBottom: '1px solid var(--border-subtle)' }}>
        <div style={{ maxWidth: 680, margin: '0 auto', padding: '12px 20px', display: 'flex', alignItems: 'center', gap: 12 }}>
          <button onClick={onBack} className="rx-icon-btn"><RxAL size={17} /></button>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 700, fontFamily: 'var(--font-heading)', color: 'var(--text-strong)' }}>Receta médica</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{rx.patientName}</div>
          </div>
          <SBadge variant={signed ? 'success' : 'warning'} dot>{signed ? 'Firmada' : 'Borrador'}</SBadge>
          {signed && <SButton variant="secondary" size="sm" icon={RxPrint} onClick={() => window.open('receta-pdf.html', '_blank')}>Imprimir</SButton>}
        </div>
      </div>

      <div style={{ maxWidth: 680, margin: '0 auto', padding: '28px 20px 48px' }}>
        {/* The document */}
        <div style={{ background: 'var(--surface-card)', borderRadius: 'var(--radius-2xl)', boxShadow: 'var(--shadow-lg)',
          border: '1px solid var(--border-subtle)', overflow: 'hidden' }}>

          {/* Letterhead */}
          <div style={{ padding: '26px 32px 22px', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 20,
            borderBottom: '2px solid var(--color-sky-600)' }}>
            <div style={{ display: 'flex', gap: 14, alignItems: 'center', minWidth: 0 }}>
              <img src="../../assets/logo-otorrinonet-transparent.svg" alt="" style={{ height: 52, width: 'auto', flex: 'none' }} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontFamily: 'var(--font-heading)', fontSize: 16, fontWeight: 700, color: 'var(--text-strong)', lineHeight: 1.2 }}>{D.name}</div>
                <div style={{ fontSize: 12, color: 'var(--brand-primary)', fontWeight: 600, marginTop: 2 }}>{D.university}</div>
                <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-body)', background: 'var(--surface-sunken)', padding: '2px 8px', borderRadius: 'var(--radius-sm)' }}>{D.license}</span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--color-sky-700)', background: 'var(--color-sky-50)', padding: '2px 8px', borderRadius: 'var(--radius-sm)' }}>{D.specialtyLicense}</span>
                </div>
              </div>
            </div>
            <div style={{ fontFamily: 'var(--font-heading)', fontSize: 40, fontWeight: 700, color: 'var(--color-sky-200)', lineHeight: 1, flex: 'none' }}>℞</div>
          </div>

          {/* Clinic strip */}
          <div style={{ padding: '10px 32px', display: 'flex', gap: 18, flexWrap: 'wrap', background: 'var(--surface-page)', borderBottom: '1px solid var(--border-subtle)' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11.5, color: 'var(--text-body)' }}><RxPin size={13} style={{ color: 'var(--text-muted)' }} />{C.address}</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11.5, color: 'var(--text-body)' }}><RxPhone size={13} style={{ color: 'var(--text-muted)' }} />{C.phone}</span>
            {C.cofepris && <span style={{ fontSize: 11.5, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>AF: {C.cofepris}</span>}
          </div>

          {/* Patient + date */}
          <div style={{ padding: '20px 32px', borderBottom: '1px solid var(--border-subtle)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 20, flexWrap: 'wrap' }}>
              <div>
                <div style={lbl}>Paciente</div>
                <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-strong)', marginTop: 4 }}>{rx.patientName}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={lbl}>Fecha de expedición</div>
                <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-strong)', marginTop: 4 }}>{fmtDate(rx.date)}</div>
              </div>
            </div>
            {(vitals.length > 0 || rx.patientAllergies) && (
              <div style={{ display: 'flex', gap: 28, flexWrap: 'wrap', marginTop: 16 }}>
                {vitals.map(([k, v]) => (
                  <div key={k}><div style={lbl}>{k}</div><div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-body)', marginTop: 3 }}>{v}</div></div>
                ))}
                {rx.patientAllergies && rx.patientAllergies.length > 0 && (
                  <div><div style={lbl}>Alergias</div>
                    <div style={{ marginTop: 4 }}><SBadge variant="danger" dot sm>{rx.patientAllergies.join(', ')}</SBadge></div></div>
                )}
              </div>
            )}
          </div>

          {/* Diagnosis */}
          {rx.diagnosis && (
            <div style={{ padding: '16px 32px', borderBottom: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--color-amber-400)', flex: 'none' }} />
              <div><span style={{ ...lbl, marginRight: 10 }}>Diagnóstico</span><span style={{ fontSize: 14, color: 'var(--text-strong)', fontWeight: 500 }}>{rx.diagnosis}</span></div>
            </div>
          )}

          {/* Medications */}
          <div>
            {rx.medications.map((m, i) => (
              <div key={i} style={{ padding: '20px 32px', borderBottom: i < rx.medications.length - 1 ? '1px solid var(--border-subtle)' : 0,
                display: 'flex', gap: 16 }}>
                <span style={{ width: 26, height: 26, borderRadius: '50%', flex: 'none', background: 'var(--color-sky-50)', color: 'var(--brand-primary)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, fontFamily: 'var(--font-mono)', marginTop: 2 }}>{i + 1}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, flexWrap: 'wrap' }}>
                    <span style={{ fontSize: 15.5, fontWeight: 700, fontFamily: 'var(--font-heading)', color: 'var(--text-strong)' }}>{m.name}</span>
                    {m.brandName && <span style={{ fontSize: 12.5, fontStyle: 'italic', color: 'var(--text-muted)' }}>({m.brandName})</span>}
                  </div>
                  {m.presentation && <div style={{ fontSize: 12.5, color: 'var(--text-body)', marginTop: 2 }}>{m.presentation}</div>}
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 12 }}>
                    {[['Dosis', m.dose], ['Frecuencia', m.frequency], ['Duración', m.duration || '—'], m.route && ['Vía', m.route]].filter(Boolean).map(([k, v]) => (
                      <div key={k} style={{ background: 'var(--surface-page)', borderRadius: 'var(--radius-md)', padding: '6px 12px' }}>
                        <div style={{ fontSize: 9, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', color: 'var(--text-muted)' }}>{k}</div>
                        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-strong)', marginTop: 1 }}>{v}</div>
                      </div>
                    ))}
                  </div>
                  {m.instructions && <div style={{ fontSize: 12.5, color: 'var(--text-body)', fontStyle: 'italic', marginTop: 10, paddingLeft: 12, borderLeft: '2px solid var(--border-default)' }}>{m.instructions}</div>}
                </div>
              </div>
            ))}
          </div>

          {/* Signature footer */}
          <div style={{ padding: '24px 32px 28px', background: 'var(--surface-page)' }}>
            {signed ? (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
                <div style={{ width: 220, borderBottom: '1.5px solid var(--text-strong)', paddingBottom: 6, textAlign: 'center' }}>
                  <span style={{ fontFamily: 'var(--font-heading)', fontSize: 22, color: 'var(--brand-primary)', fontStyle: 'italic' }}>A. Viveros</span>
                </div>
                <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-strong)' }}>{D.name}</div>
                <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11, color: 'var(--state-success-fg)', background: 'var(--state-success-bg)', padding: '5px 12px', borderRadius: 'var(--radius-full)', fontWeight: 600 }}>
                  <RxLock size={12} />Firma electrónica · SHA-256
                </div>
                <div style={{ fontSize: 10.5, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', textAlign: 'center', marginTop: 2 }}>
                  Sellada: {fmtStamp(rx.signedAt)}<br/>UTC {rx.signatureTimestamp}
                </div>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
                <div style={{ width: '100%', maxWidth: 320, border: '2px dashed var(--border-default)', borderRadius: 'var(--radius-xl)', padding: '18px', textAlign: 'center',
                  color: 'var(--text-muted)', fontSize: 12 }}>
                  <RxPen size={20} style={{ color: 'var(--color-amber-400)' }} />
                  <div style={{ marginTop: 6 }}>Pendiente de firma. Al firmar se genera un sello SHA-256 con timestamp (NOM-004) y la receta queda inmutable.</div>
                </div>
                <div style={{ width: '100%', maxWidth: 320 }}>
                  <SButton icon={RxLock} onClick={() => { setSigning(true); setTimeout(() => { setSigning(false); onSign(rx.id); }, 700); }}>
                    {signing ? 'Firmando…' : 'Firmar receta'}
                  </SButton>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── New prescription form ──────────────────────────────────────────────── */
const EMPTY_MED = { name: '', brandName: '', presentation: '', dose: '', frequency: '', duration: '', route: '', instructions: '' };

function RxField({ label, value, onChange, placeholder, req }) {
  const [f, setF] = React.useState(false);
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 5, flex: 1, minWidth: 0 }}>
      <span style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', color: 'var(--text-muted)' }}>{label}{req && <span style={{ color: 'var(--color-rose-600)' }}> *</span>}</span>
      <input value={value} placeholder={placeholder} onChange={e => onChange(e.target.value)} onFocus={() => setF(true)} onBlur={() => setF(false)}
        style={{ width: '100%', boxSizing: 'border-box', fontFamily: 'var(--font-sans)', fontSize: 13, color: 'var(--text-strong)', background: 'var(--surface-card)',
          border: `1px solid ${f ? 'var(--border-focus)' : 'var(--border-default)'}`, borderRadius: 'var(--radius-lg)', padding: '9px 12px', outline: 'none',
          boxShadow: f ? '0 0 0 3px rgb(14 165 233 / .18)' : 'none', transition: 'all .15s' }} />
    </label>
  );
}

function RecetaForm({ onCancel, onSave }) {
  const [diagnosis, setDiagnosis] = React.useState('');
  const [meds, setMeds] = React.useState([{ ...EMPTY_MED }]);
  const set = (i, k, v) => setMeds(p => p.map((m, idx) => idx === i ? { ...m, [k]: v } : m));
  const card = { background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-2xl)', padding: 22 };

  return (
    <div style={{ height: '100vh', overflowY: 'auto', background: 'var(--surface-page)' }}>
      <div style={{ position: 'sticky', top: 0, zIndex: 10, background: 'rgba(255,255,255,.92)', backdropFilter: 'blur(8px)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div style={{ maxWidth: 680, margin: '0 auto', padding: '12px 20px', display: 'flex', alignItems: 'center', gap: 12 }}>
          <button onClick={onCancel} className="rx-icon-btn"><RxAL size={17} /></button>
          <div style={{ fontSize: 14, fontWeight: 700, fontFamily: 'var(--font-heading)', color: 'var(--text-strong)' }}>Nueva receta médica</div>
        </div>
      </div>
      <div style={{ maxWidth: 680, margin: '0 auto', padding: '24px 20px 48px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div style={card}>
          <RxField label="Diagnóstico / indicación" value={diagnosis} onChange={setDiagnosis} placeholder="Ej. Rinosinusitis aguda bacteriana" />
        </div>
        {meds.map((m, i) => (
          <div key={i} style={card}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
              <span style={{ width: 24, height: 24, borderRadius: '50%', background: 'var(--color-sky-50)', color: 'var(--brand-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, fontFamily: 'var(--font-mono)' }}>{i + 1}</span>
              {meds.length > 1 && <button onClick={() => setMeds(p => p.filter((_, idx) => idx !== i))} className="rx-icon-btn rx-icon-btn--danger"><RxTrash size={15} /></button>}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div style={{ display: 'flex', gap: 12 }}>
                <RxField label="Nombre genérico" req value={m.name} onChange={v => set(i, 'name', v)} placeholder="Amoxicilina" />
                <RxField label="Nombre comercial" value={m.brandName} onChange={v => set(i, 'brandName', v)} placeholder="Amoxil" />
              </div>
              <RxField label="Presentación" value={m.presentation} onChange={v => set(i, 'presentation', v)} placeholder="Cápsulas 500 mg" />
              <div style={{ display: 'flex', gap: 12 }}>
                <RxField label="Dosis" req value={m.dose} onChange={v => set(i, 'dose', v)} placeholder="500 mg" />
                <RxField label="Frecuencia" req value={m.frequency} onChange={v => set(i, 'frequency', v)} placeholder="c/8 h" />
                <RxField label="Duración" value={m.duration} onChange={v => set(i, 'duration', v)} placeholder="7 días" />
                <RxField label="Vía" value={m.route} onChange={v => set(i, 'route', v)} placeholder="Oral" />
              </div>
              <RxField label="Indicaciones adicionales" value={m.instructions} onChange={v => set(i, 'instructions', v)} placeholder="Tomar con alimentos" />
            </div>
          </div>
        ))}
        <button onClick={() => setMeds(p => [...p, { ...EMPTY_MED }])} className="rx-add"><SPlus size={16} sw={2.4} />Agregar medicamento</button>
        <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
          <SButton variant="secondary" onClick={onCancel}>Cancelar</SButton>
          <SButton icon={RxPen} onClick={() => { const valid = meds.filter(m => m.name && m.dose && m.frequency); if (valid.length) onSave(valid, diagnosis); }}>Crear receta</SButton>
        </div>
      </div>
    </div>
  );
}

/* ── Recetas list (entry) ───────────────────────────────────────────────── */
function Recetas() {
  const [list, setList] = React.useState(window.STAFF_DATA.prescriptions);
  const [mode, setMode] = React.useState('list');   // list | detail | new
  const [sel, setSel] = React.useState(null);
  const [q, setQ] = React.useState('');

  const sign = (id) => setList(p => p.map(r => r.id === id ? { ...r, status: 'firmada', signedAt: new Date().toISOString(), signatureTimestamp: new Date().toISOString() } : r));
  const create = (meds, diagnosis) => {
    const rx = { id: 'rx' + Date.now(), status: 'borrador', patientName: 'Nuevo paciente', date: new Date().toISOString().slice(0, 10),
      patientAge: null, patientSex: '', diagnosis, medications: meds };
    setList(p => [rx, ...p]); setSel(rx); setMode('detail');
  };

  if (mode === 'detail' && sel) return <Receta rx={list.find(r => r.id === sel.id) || sel} onBack={() => setMode('list')} onSign={sign} />;
  if (mode === 'new') return <RecetaForm onCancel={() => setMode('list')} onSave={create} />;

  const filtered = list.filter(r => !q || r.patientName.toLowerCase().includes(q.toLowerCase()) || (r.diagnosis || '').toLowerCase().includes(q.toLowerCase()));

  return (
    <div style={{ height: '100vh', overflowY: 'auto' }}>
      <div style={{ maxWidth: 760, margin: '0 auto', padding: '32px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16, marginBottom: 8 }}>
          <div>
            <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 700, color: 'var(--text-strong)', margin: 0 }}>Recetas</h1>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: '4px 0 0' }}>{list.length} recetas · {list.filter(r => r.status === 'firmada').length} firmadas</p>
          </div>
          <SButton icon={SPlus} onClick={() => setMode('new')}>Nueva receta</SButton>
        </div>
        <div style={{ position: 'relative', margin: '16px 0' }}>
          <SSearch size={16} style={{ position: 'absolute', left: 14, top: 13, color: 'var(--text-muted)' }} />
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Buscar por paciente o diagnóstico…"
            style={{ width: '100%', boxSizing: 'border-box', padding: '12px 16px 12px 40px', fontSize: 14, fontFamily: 'var(--font-sans)', background: 'var(--surface-card)',
              border: '1px solid var(--border-default)', borderRadius: 'var(--radius-xl)', outline: 'none', boxShadow: 'var(--shadow-sm)', color: 'var(--text-strong)' }} />
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {filtered.map(r => (
            <button key={r.id} onClick={() => { setSel(r); setMode('detail'); }} className="rx-card">
              <span style={{ width: 44, height: 44, borderRadius: 'var(--radius-lg)', flex: 'none', background: 'var(--color-sky-50)', color: 'var(--brand-primary)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-heading)', fontSize: 22, fontWeight: 700 }}>℞</span>
              <div style={{ flex: 1, minWidth: 0, textAlign: 'left' }}>
                <div style={{ fontSize: 14.5, fontWeight: 600, color: 'var(--text-strong)' }}>{r.patientName}</div>
                <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {r.diagnosis || 'Sin diagnóstico'} · {r.medications.length} medicamento{r.medications.length !== 1 ? 's' : ''}
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6, flex: 'none' }}>
                <SBadge variant={r.status === 'firmada' ? 'success' : 'warning'} dot sm>{r.status === 'firmada' ? 'Firmada' : 'Borrador'}</SBadge>
                <span style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{fmtDate(r.date)}</span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

window.Recetas = Recetas;
