/* Sample clinical data for the staff panel (fictional patients). */
window.STAFF_DATA = {
  user: { name: 'Dr. Alejandro Viveros', role: 'Médico' },
  appointments: [
    { id: 'a1', name: 'Yazmín García', time: '10:00', service: 'Consulta ORL General', status: 'confirmada', day: 'Hoy · 9 jun', phone: '55 1432 8890', email: 'yazmin.g@correo.com', reason: 'Congestión nasal persistente y dolor de oído derecho desde hace dos semanas.' },
    { id: 'a2', name: 'Consuelo Domínguez', time: '10:30', service: 'Audiología', status: 'pendiente', day: 'Hoy · 9 jun', phone: '55 2901 7745', email: 'consuelo.d@correo.com', reason: 'Evaluación de audición; refiere disminución auditiva del oído izquierdo.' },
    { id: 'a3', name: 'Mijo León', time: '11:00', service: 'Rinitis Alérgica', status: 'confirmada', day: 'Hoy · 9 jun', phone: '55 6677 1203', email: 'mijo.leon@correo.com', reason: 'Seguimiento de inmunoterapia, tercera dosis.' },
    { id: 'a4', name: 'Karen Sandoval', time: '16:00', service: 'Cirugía ORL', status: 'pendiente', day: 'Hoy · 9 jun', phone: '55 8123 0098', email: 'karen.s@correo.com', reason: 'Valoración prequirúrgica para septoplastia.' },
    { id: 'a5', name: 'Alejandra Vázquez', time: '10:00', service: 'Vértigo y Equilibrio', status: 'confirmada', day: 'Mañana · 10 jun', phone: '55 3456 7788', email: 'ale.v@correo.com', reason: 'Episodios de vértigo posicional al levantarse.' },
    { id: 'a6', name: 'Roberto Méndez', time: '11:30', service: 'Consulta ORL General', status: 'cancelada', day: 'Mañana · 10 jun', phone: '55 9988 2210', email: 'rmendez@correo.com', reason: 'Dolor de garganta recurrente.' },
  ],
  patients: [
    { name: 'Yazmín García Soto', exp: 'EXP-0428', age: 34, sex: 'Femenino', updated: 'Hoy' },
    { name: 'Consuelo Domínguez Ruiz', exp: 'EXP-0427', age: 61, sex: 'Femenino', updated: 'Hoy' },
    { name: 'Mijo León Aguilar', exp: 'EXP-0425', age: 28, sex: 'Masculino', updated: 'Ayer' },
    { name: 'Karen Sandoval Pérez', exp: 'EXP-0419', age: 45, sex: 'Femenino', updated: 'Hace 3 días' },
    { name: 'Alejandra Vázquez Mora', exp: 'EXP-0411', age: 52, sex: 'Femenino', updated: 'Hace 1 sem.' },
    { name: 'Roberto Méndez Lara', exp: 'EXP-0402', age: 39, sex: 'Masculino', updated: 'Hace 2 sem.' },
  ],
  clinic: {
    name: 'Consultorio Dr. Alejandro Viveros Domínguez — ORL',
    address: 'Chosica 730, Col. Lindavista, GAM, CDMX 07300',
    phone: 'Tel. 55 5586 0000',
    cofepris: '193300C0234',
  },
  doctor: {
    name: 'Dr. Alejandro Viveros Domínguez',
    university: 'Otorrinolaringología — UNAM · CMN La Raza',
    license: 'Céd. Prof. 6277305',
    specialtyLicense: 'Céd. Esp. 10148701',
  },
  prescriptions: [
    {
      id: 'rx1', status: 'firmada', patientName: 'Yazmín García Soto', date: '2026-06-09',
      patientAge: 34, patientSex: 'Femenino', patientWeight: 62, patientAllergies: ['Penicilina'],
      diagnosis: 'Rinosinusitis aguda bacteriana',
      signedAt: '2026-06-09T17:24:00', signatureTimestamp: '2026-06-09T23:24:00Z',
      medications: [
        { name: 'Amoxicilina/Clavulanato', brandName: 'Augmentin', presentation: 'Tabletas 875/125 mg', dose: '875 mg', frequency: 'c/12 h', duration: '10 días', route: 'Oral', instructions: 'Tomar con alimentos.' },
        { name: 'Mometasona', brandName: 'Nasonex', presentation: 'Spray nasal 50 mcg', dose: '2 disparos por fosa', frequency: 'c/24 h', duration: '4 semanas', route: 'Nasal', instructions: 'Agitar antes de usar; sonarse la nariz previamente.' },
        { name: 'Paracetamol', brandName: '', presentation: 'Tabletas 500 mg', dose: '500 mg', frequency: 'c/8 h por dolor', duration: '5 días', route: 'Oral', instructions: '' },
      ],
    },
    {
      id: 'rx2', status: 'borrador', patientName: 'Mijo León Aguilar', date: '2026-06-09',
      patientAge: 28, patientSex: 'Masculino', diagnosis: 'Rinitis alérgica perenne',
      medications: [
        { name: 'Loratadina', brandName: 'Clarityne', presentation: 'Tabletas 10 mg', dose: '10 mg', frequency: 'c/24 h', duration: '30 días', route: 'Oral', instructions: 'Preferentemente por la mañana.' },
      ],
    },
    {
      id: 'rx3', status: 'firmada', patientName: 'Consuelo Domínguez Ruiz', date: '2026-06-05',
      patientAge: 61, patientSex: 'Femenino', diagnosis: 'Otitis externa difusa',
      signedAt: '2026-06-05T11:10:00', signatureTimestamp: '2026-06-05T17:10:00Z',
      medications: [
        { name: 'Ciprofloxacino/Hidrocortisona', brandName: 'Cipro HC', presentation: 'Gotas óticas', dose: '3 gotas oído afectado', frequency: 'c/12 h', duration: '7 días', route: 'Ótica', instructions: 'Mantener la cabeza inclinada 2 min tras la aplicación.' },
      ],
    },
  ],
  dashboard: {
    stats: [
      { label: 'Citas hoy', value: '4', delta: '+2', tone: 'info' },
      { label: 'Pendientes', value: '2', delta: 'por confirmar', tone: 'warning' },
      { label: 'Pacientes', value: '128', delta: '+6 este mes', tone: 'success' },
      { label: 'Ventas tienda', value: '$8,450', delta: '+12%', tone: 'info' },
    ],
    week: [
      { d: 'Lun', v: 6 }, { d: 'Mar', v: 8 }, { d: 'Mié', v: 5 },
      { d: 'Jue', v: 9 }, { d: 'Vie', v: 7 }, { d: 'Sáb', v: 2 }, { d: 'Dom', v: 0 },
    ],
  },
};
