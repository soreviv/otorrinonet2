/* Icons + primitives for the staff panel. Self-contained; tokens from styles.css. */
const SIc = ({ children, size = 18, sw = 1.75, ...p }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
       strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" {...p}>{children}</svg>
);
const CalDays  = (p) => <SIc {...p}><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01"/></SIc>;
const Clip     = (p) => <SIc {...p}><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2M9 12h6M9 16h6"/></SIc>;
const Scroll   = (p) => <SIc {...p}><path d="M8 21h12a2 2 0 0 0 2-2v-2H10v2a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v3h4"/><path d="M19 17V5a2 2 0 0 0-2-2H6M13 8h4M13 12h4"/></SIc>;
const Shield   = (p) => <SIc {...p}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/></SIc>;
const Gear     = (p) => <SIc {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"/></SIc>;
const Bag      = (p) => <SIc {...p}><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18M16 10a4 4 0 0 1-8 0"/></SIc>;
const Box      = (p) => <SIc {...p}><path d="M21 8 12 3 3 8v8l9 5 9-5Z"/><path d="m3 8 9 5 9-5M12 13v8"/></SIc>;
const SSearch  = (p) => <SIc {...p}><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></SIc>;
const SPlus    = (p) => <SIc {...p}><path d="M12 5v14M5 12h14"/></SIc>;
const SChevR   = (p) => <SIc {...p}><path d="m9 18 6-6-6-6"/></SIc>;
const SCheck   = (p) => <SIc {...p}><path d="M20 6 9 17l-5-5"/></SIc>;
const SX       = (p) => <SIc {...p}><path d="M18 6 6 18M6 6l12 12"/></SIc>;
const Refresh  = (p) => <SIc {...p}><path d="M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5M21 12a9 9 0 0 1-15 6.7L3 16M3 21v-5h5"/></SIc>;
const SPhone   = (p) => <SIc {...p}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z"/></SIc>;
const SMail    = (p) => <SIc {...p}><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 7 10 6 10-6"/></SIc>;
const SClock   = (p) => <SIc {...p}><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></SIc>;
const SUser    = (p) => <SIc {...p}><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></SIc>;
const Steth2   = (p) => <SIc {...p}><path d="M4 3v5a5 5 0 0 0 10 0V3"/><path d="M4 3H2m12 0h-2M9 18a4 4 0 0 0 8 0v-2"/><circle cx="20" cy="10" r="2"/></SIc>;
const LogOut   = (p) => <SIc {...p}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></SIc>;
const Menu2    = (p) => <SIc {...p}><path d="M4 12h16M4 6h16M4 18h16"/></SIc>;
const Bell     = (p) => <SIc {...p}><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.94 1.94 0 0 0 3.4 0"/></SIc>;

const STATUS = {
  pendiente:   { variant: 'warning', label: 'Pendiente' },
  confirmada:  { variant: 'info',    label: 'Confirmada' },
  reprogramada:{ variant: 'info',    label: 'Reprogramada' },
  completada:  { variant: 'success', label: 'Completada' },
  cancelada:   { variant: 'danger',  label: 'Cancelada' },
};
const TONES = {
  info:    { bg: 'var(--state-info-bg)',    fg: 'var(--state-info-fg)',    dot: 'var(--color-sky-500)' },
  warning: { bg: 'var(--state-warning-bg)', fg: 'var(--state-warning-fg)', dot: 'var(--color-amber-400)' },
  success: { bg: 'var(--state-success-bg)', fg: 'var(--state-success-fg)', dot: 'var(--color-emerald-500)' },
  danger:  { bg: 'var(--state-danger-bg)',  fg: 'var(--state-danger-fg)',  dot: 'var(--color-rose-400)' },
  neutral: { bg: 'var(--surface-sunken)',   fg: 'var(--text-body)',        dot: 'var(--color-slate-400)' },
};

function SBadge({ variant = 'neutral', dot, sm, children }) {
  const t = TONES[variant];
  return <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontFamily: 'var(--font-sans)',
    fontWeight: 600, fontSize: sm ? 11 : 12, padding: sm ? '2px 8px' : '4px 10px',
    borderRadius: sm ? 'var(--radius-sm)' : 'var(--radius-full)', background: t.bg, color: t.fg, whiteSpace: 'nowrap' }}>
    {dot && <span style={{ width: 6, height: 6, borderRadius: '50%', background: t.dot }} />}{children}</span>;
}

function SAvatar({ name = '', size = 40, variant = 'soft' }) {
  const init = name.trim().split(/\s+/).slice(0, 2).map(n => n[0] || '').join('').toUpperCase();
  const v = { solid: ['var(--brand-primary)', '#fff'], soft: ['var(--color-sky-100)', 'var(--color-sky-700)'],
    neutral: ['var(--surface-sunken)', 'var(--text-muted)'], onPrimary: ['rgba(255,255,255,.2)', '#fff'] }[variant];
  return <span style={{ width: size, height: size, flex: 'none', borderRadius: size >= 52 ? 'var(--radius-2xl)' : '50%',
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-heading)',
    fontWeight: 700, fontSize: size * 0.33, background: v[0], color: v[1] }}>{init}</span>;
}

function SButton({ children, variant = 'primary', size = 'md', icon: Icon, onClick }) {
  const [h, setH] = React.useState(false);
  const pad = size === 'sm' ? '7px 12px' : '9px 16px';
  const sty = {
    primary:   { background: h ? 'var(--brand-primary-hover)' : 'var(--brand-primary)', color: '#fff', border: '1px solid transparent', boxShadow: 'var(--shadow-sm)' },
    secondary: { background: h ? 'var(--surface-page)' : 'var(--surface-card)', color: 'var(--text-body)', border: '1px solid var(--border-default)' },
    danger:    { background: h ? 'var(--color-rose-50)' : 'var(--surface-card)', color: 'var(--color-rose-600)', border: '1px solid var(--color-rose-200, #fecdd3)' },
  }[variant];
  return <button onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
    style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontFamily: 'var(--font-sans)',
      fontWeight: 600, fontSize: 13, padding: pad, borderRadius: 'var(--radius-md)', cursor: 'pointer', whiteSpace: 'nowrap', transition: 'all .15s', ...sty }}>
    {Icon && <Icon size={15} sw={2.2} />}{children}</button>;
}

Object.assign(window, { SIc, CalDays, Clip, Scroll, Shield, Gear, Bag, Box, SSearch, SPlus, SChevR, SCheck, SX,
  Refresh, SPhone, SMail, SClock, SUser, Steth2, LogOut, Menu2, Bell, STATUS, TONES, SBadge, SAvatar, SButton });
