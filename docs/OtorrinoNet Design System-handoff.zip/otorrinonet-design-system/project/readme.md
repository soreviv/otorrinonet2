# OtorrinoNet — Design System

The brand & product design system for the private otorhinolaryngology (ENT)
practice of **Dr. Alejandro Viveros Domínguez** (Lindavista, Ciudad de México).
It captures the visual language of **OtorrinoNet**, the all-in-one platform that
runs the practice: a public marketing site, online appointment booking, a
medical store, and a NOM-compliant electronic health record (EHR) for staff.

Use it to generate on-brand interfaces, mockups, slides and prototypes — either
throwaway HTML artifacts or production-quality screens — that look and feel like
the real product.

> **Language:** the product is **Spanish (es-MX)**. All UI copy, labels and
> sample content are written in Mexican Spanish. Keep it that way.

---

## Sources

This system was reverse-engineered from the product's own codebase. If you have
access, explore the source to go deeper:

- **GitHub:** `soreviv/otorrinonet2` — Next.js 16 + React 19 + Tailwind CSS v4
  app (public site, booking, store, EHR). Design tokens were lifted from
  `app/src/app/globals.css`; components mirrored from `app/src/components/`;
  copy & data from `app/src/lib/sitio-publico-data.ts`.
- **Uploaded asset:** `uploads/logoale.jpg` — the registered logo mark.

Exploring the repo will let you build higher-fidelity designs against the real
product than this system alone provides.

---

## What's the product?

OtorrinoNet serves three audiences from one platform:

| Surface | Audience | What it does |
|---|---|---|
| **Sitio público** | Prospective patients | Doctor profile, services, Google reviews, location, store |
| **Agendar / Tienda** | Patients | 3-step online booking; medical product store with Stripe checkout |
| **Panel clínico (staff)** | Doctor, nurses, reception | Agenda, EHR (NOM-004), SOAP notes & prescriptions, store admin, dashboard |

The doctor: ORL & Head-and-Neck surgeon, UNAM-trained (CMN La Raza), 10+ years,
5.0★ on Google. Services: consulta ORL, audiología, vacunación, rinitis
alérgica e inmunoterapia, cirugía ORL, vértigo y equilibrio.

---

## CONTENT FUNDAMENTALS — how the brand writes

- **Language & voice:** Mexican Spanish, **formal-but-warm**. The clinical
  authority of a specialist with the reassurance of a family doctor. Signature
  line: *"Atención humana, ética y de alta calidad."*
- **Address form:** speaks **to the patient** ("Agenda tu consulta",
  "¿Listo para sentirte mejor?", "tus datos"). Uses **tú**, not usted — close
  but respectful. The practice refers to itself as "nuestro/a".
- **Casing:** Sentence case for body and most headings. **UPPERCASE micro-labels**
  with wide tracking are a signature eyebrow device above section titles
  ("ESPECIALIDADES", "RESEÑAS VERIFICADAS", "TIENDA EN LÍNEA").
- **Tone of CTAs:** action + reassurance — "Agendar Cita", "Agendar Cita Ahora",
  "Ver perfil completo", "Ver todos los servicios".
- **Numbers & credentials build trust:** cédula profesional, años de
  experiencia, rating "5.0 / 5 · 6 reseñas", NOM compliance. Shown plainly, in
  monospace, never inflated.
- **Clinical register in the staff app:** precise and procedural — "Motivo de
  consulta", "Expediente", "Notas SOAP", "Confirmar / Reprogramar / Cancelar".
  Patient-facing copy stays gentle; staff copy is terse and functional.
- **No emoji.** No exclamatory hype beyond the one friendly hero question. No
  slang. Accents and ñ always correct (Domínguez, audiología, cirugía).

---

## VISUAL FOUNDATIONS

- **Primary color — Sky.** The product is built on Tailwind's `sky` ramp;
  **sky-600 `#0284c7`** is the brand primary (buttons, links, active nav, hero
  diagonals, CTA bands). This is the digital UI color, distinct from the logo
  trio below.
- **Brand identity trio — the logo mark.** The ear/nose/throat glyph uses three
  hues: **oído (ear) olive-green `#b6c24f`**, **nariz (nose) teal-blue
  `#216e95`** (also the wordmark), **garganta (throat) orange `#f28522`**. Use
  these for the mark, illustration and the occasional brand accent — *not* as UI
  chrome (that's sky).
- **Neutrals — Slate.** `slate-50` page background, white cards, `slate-900`
  headings, `slate-600` body, `slate-400` muted, `slate-100/200` borders.
- **Semantic states:** sky = info/confirmed, amber = pending/ratings,
  emerald = completed/success, rose = cancelled/destructive. Always rendered as
  **soft pills** (tinted bg + saturated text + a small leading dot).
- **Type:** **DM Sans** for headings/display (bold, tight `-0.02em` tracking),
  **Inter** for body & UI (relaxed 1.65 leading), **IBM Plex Mono** for IDs,
  times, phone numbers and cédulas. All via Google Fonts.
- **Corner radii run generous:** `md (8px)` app chrome & inputs, `lg (12px)`
  buttons & form fields, `xl (16px)` content cards, `2xl (24px)` panels, hero
  image & feature blocks, `full` for pills and avatars.
- **Cards:** white, `border 1px slate-100/200`, `rounded-2xl`, soft `shadow-sm`
  at rest; lift to `shadow-lg` on hover. No heavy borders, no colored
  left-accent stripes (except the active-nav rail and selected-row rail, which
  are a 2–3px sky bar).
- **Shadows are soft and low-contrast** (clinical, trustworthy) — never harsh.
  Primary buttons gain a **tinted sky glow** (`shadow-primary`) on hover.
- **Backgrounds:** mostly flat white / slate-50. The hero uses a **diagonal
  clip-path panel** of a sky-600→sky-700 gradient; CTA bands are solid sky-600
  with a faint **dot-grid overlay** at ~20% opacity. No photographic
  backgrounds, no glassmorphism, no purple gradients.
- **Imagery:** warm, natural clinical portraits (white coat, soft daylight,
  blurred consultorio) in `rounded-2xl` frames with `object-fit: cover`. Product
  photos sit on white. Never cold stock or heavy filters.
- **Motion:** restrained and functional. 120–200ms color/opacity/shadow
  transitions; primary buttons press with `scale(0.98)`; the sidebar collapses
  over 200ms. One soft **pulse dot** on availability/"live" badges. No bounces,
  no decorative loops.
- **Hover states:** primary → darker sky + glow; secondary → sky-tinted bg +
  sky border; rows/nav → slate-50 fill. **Press:** darker still + 0.98 scale.
- **Focus:** 2px sky ring (`focus:ring-2 ring-sky-500`) on inputs and buttons.
- **Layout:** `max-w-6xl (1152px)` centered public site; sticky translucent
  header (`backdrop-blur`); staff app is a fixed 224px sidebar + fluid content.
  4px spacing grid throughout.

---

## ICONOGRAPHY

- **System:** [**Lucide**](https://lucide.dev) — the product uses `lucide-react`
  exclusively. Stroke icons, ~1.75 stroke width (2 when active), 16–20px in UI,
  rounded line caps/joins. This is the only icon system; match it.
- **In this design system:** the foundation cards, components and UI kits draw
  Lucide-equivalent SVG icons inline (same geometry & stroke) so the kits stay
  self-contained. When building production work, prefer real `lucide-react` /
  the Lucide CDN. Common glyphs in use: Calendar, Stethoscope, Ear, Syringe,
  Flower2, Scissors, Activity, Search, Plus, ChevronRight, Check, X, Phone,
  Mail, Clock, User, ShoppingBag, Shield, Settings, Star, Quote, MapPin.
- **No emoji. No unicode-character icons.** Icons sit in soft sky-50 chips
  (rounded-lg/xl) for emphasis, or inline at text color.
- **Logo:** vector mark of the ear/nose/throat glyph over the wordmark.
  Three files in `assets/`: `logo-otorrinonet.svg` (full color, white bg),
  `logo-otorrinonet-transparent.svg` (color, transparent — default), and
  `logo-otorrinonet-white.svg` (monochrome white, for dark/sky surfaces).
  `assets/logo-otorrinonet.png` is the raster fallback.

---

## Tokens

All design tokens live under `tokens/` and are aggregated by the root
**`styles.css`** (the single file consumers link). Token files:

- `tokens/colors.css` — sky/slate scales, semantics, brand trio, semantic aliases
- `tokens/typography.css` — families, type scale, weights, leading, tracking
- `tokens/spacing.css` — 4px spacing scale, layout sizes, radii
- `tokens/elevation.css` — shadow ramp, primary glow, focus ring
- `tokens/motion.css` — durations, easings, press scale
- `tokens/fonts.css` — Google Fonts import (DM Sans, Inter, IBM Plex Mono)

Reference semantic aliases (`--brand-primary`, `--surface-card`, `--text-body`,
`--state-warning-bg`…) in your work rather than raw scale values where possible.

---

## Index / manifest

```
styles.css                      → entry point (link this)
tokens/                         → colors, typography, spacing, elevation, motion, fonts
assets/                         → logo (svg×3), doctor portraits, product photos
guidelines/                     → 13 foundation specimen cards (Design System tab)
components/
  core/      Button · Badge · Avatar · Input · Card
  patterns/  ServiceCard · ReviewCard · AppointmentRow
  public/    PublicHeader · DoctorCard · RatingSummary · ContactCard · Breadcrumbs
ui_kits/
  sitio-publico/   public marketing site + 3-step booking (index.html)
  panel-clinico/   staff console: agenda, expedientes, recetas, dashboard (index.html)
                   receta-pdf.html  — carta imprimible / PDF (NOM-004, SHA-256)
  emails/          4 correos automáticos: confirmación, recordatorio, cancelación,
                   receta firmada (index.html — viewer interactivo)
SKILL.md                        → Agent Skill manifest (for Claude Code)
```

**Components** (13) are React, bundled automatically into `_ds_bundle.js` and
exposed on `window.OtorrinoNetDesignSystem_fb3257`. Each has a `.d.ts` props
contract and a `.prompt.md` usage note.

**UI kits** are self-contained, interactive HTML recreations of real product
surfaces — open `ui_kits/<name>/index.html` directly. They compose the same
visual language but inline their own lightweight components so they run offline.

---

## Caveats

- The component **cards** in the Design System tab load the generated
  `_ds_bundle.js`; the **UI kits** are intentionally self-contained (they do not
  depend on the bundle) so they preview and download cleanly.
- Fonts are pulled from **Google Fonts** (the exact families the product uses) —
  no local font binaries are shipped.
- The brand logo trio (green/blue/orange) and the digital UI primary (sky) are
  *both* part of the identity; don't collapse them into one. Sky drives the
  interface; the trio belongs to the mark.
