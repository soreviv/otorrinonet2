/* @ds-bundle: {"format":3,"namespace":"OtorrinoNetDesignSystem_fb3257","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"AppointmentRow","sourcePath":"components/patterns/AppointmentRow.jsx"},{"name":"ReviewCard","sourcePath":"components/patterns/ReviewCard.jsx"},{"name":"ServiceCard","sourcePath":"components/patterns/ServiceCard.jsx"},{"name":"Breadcrumbs","sourcePath":"components/public/Breadcrumbs.jsx"},{"name":"ContactCard","sourcePath":"components/public/ContactCard.jsx"},{"name":"DoctorCard","sourcePath":"components/public/DoctorCard.jsx"},{"name":"PublicHeader","sourcePath":"components/public/PublicHeader.jsx"},{"name":"RatingSummary","sourcePath":"components/public/RatingSummary.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"5f57669313f3","components/core/Badge.jsx":"4b510657e3e8","components/core/Button.jsx":"07c0e38dabc0","components/core/Card.jsx":"85a5b5fadc60","components/core/Input.jsx":"2ddfb610dd15","components/patterns/AppointmentRow.jsx":"0b8967a2b2c5","components/patterns/ReviewCard.jsx":"08774829835f","components/patterns/ServiceCard.jsx":"49c9926ef924","components/public/Breadcrumbs.jsx":"64146f75fc74","components/public/ContactCard.jsx":"8cbf6df2fc79","components/public/DoctorCard.jsx":"b72c849960d9","components/public/PublicHeader.jsx":"50019e3652f3","components/public/RatingSummary.jsx":"6c1d9fe5fa5e","ui_kits/panel-clinico/data.js":"3076e38bac28","ui_kits/panel-clinico/recetas.jsx":"b82c633af9c1","ui_kits/panel-clinico/ui.jsx":"0f16c176782d","ui_kits/panel-clinico/views.jsx":"1bbd436e6263","ui_kits/sitio-publico/agendar.jsx":"9b5bfd0c62b0","ui_kits/sitio-publico/contacto.jsx":"39562c800a02","ui_kits/sitio-publico/data.js":"cfb771c13538","ui_kits/sitio-publico/home.jsx":"2cb3a3fc9537","ui_kits/sitio-publico/perfil.jsx":"a011fa5b0014","ui_kits/sitio-publico/servicios.jsx":"6f9cfa6ea510","ui_kits/sitio-publico/ubicacion.jsx":"2dbcf1ed18c7","ui_kits/sitio-publico/ui.jsx":"de501656c27b"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.OtorrinoNetDesignSystem_fb3257 = window.OtorrinoNetDesignSystem_fb3257 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.dsf-avatar{
  display:inline-flex;align-items:center;justify-content:center;flex:none;
  font-family:var(--font-heading);font-weight:var(--font-weight-bold);
  border-radius:var(--radius-full);overflow:hidden;line-height:1;
  text-transform:uppercase;letter-spacing:.02em;
}
.dsf-avatar img{width:100%;height:100%;object-fit:cover;}
.dsf-avatar--xs{width:28px;height:28px;font-size:10px;}
.dsf-avatar--sm{width:36px;height:36px;font-size:12px;}
.dsf-avatar--md{width:40px;height:40px;font-size:13px;}
.dsf-avatar--lg{width:48px;height:48px;font-size:15px;}
.dsf-avatar--xl{width:56px;height:56px;border-radius:var(--radius-2xl);font-size:18px;}
.dsf-avatar--solid{background:var(--brand-primary);color:#fff;}
.dsf-avatar--soft{background:var(--color-sky-100);color:var(--color-sky-700);}
.dsf-avatar--neutral{background:var(--surface-sunken);color:var(--text-muted);}
.dsf-avatar--onPrimary{background:rgba(255,255,255,.2);color:#fff;}
`;
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-avatar-css')) return;
    const s = document.createElement('style');
    s.id = 'dsf-avatar-css';
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}
function initials(name = '') {
  return name.trim().split(/\s+/).slice(0, 2).map(n => n[0] || '').join('').toUpperCase();
}

/**
 * Circular initials/photo avatar. Used for patients, staff and reviewers.
 * `xl` switches to a rounded-square (used in the appointment detail hero).
 */
function Avatar({
  name = '',
  src,
  size = 'md',
  variant = 'soft',
  className = '',
  ...rest
}) {
  useStyles();
  const cls = ['dsf-avatar', `dsf-avatar--${size}`, `dsf-avatar--${variant}`, className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name
  }) : initials(name));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.dsf-badge{
  display:inline-flex;align-items:center;gap:6px;
  font-family:var(--font-sans);font-weight:var(--font-weight-semibold);
  font-size:var(--text-xs);line-height:1;
  padding:4px 10px;border-radius:var(--radius-full);white-space:nowrap;
}
.dsf-badge--sm{font-size:11px;padding:2px 8px;border-radius:var(--radius-sm);}
.dsf-badge__dot{width:6px;height:6px;border-radius:50%;flex:none;}
.dsf-badge__dot--pulse{animation:ds-pulse 1.6s ease-in-out infinite;}
.dsf-badge--info{background:var(--state-info-bg);color:var(--state-info-fg);}
.dsf-badge--info .dsf-badge__dot{background:var(--color-sky-500);}
.dsf-badge--warning{background:var(--state-warning-bg);color:var(--state-warning-fg);}
.dsf-badge--warning .dsf-badge__dot{background:var(--color-amber-400);}
.dsf-badge--success{background:var(--state-success-bg);color:var(--state-success-fg);}
.dsf-badge--success .dsf-badge__dot{background:var(--color-emerald-500);}
.dsf-badge--danger{background:var(--state-danger-bg);color:var(--state-danger-fg);}
.dsf-badge--danger .dsf-badge__dot{background:var(--color-rose-400);}
.dsf-badge--neutral{background:var(--surface-sunken);color:var(--text-body);}
.dsf-badge--neutral .dsf-badge__dot{background:var(--color-slate-400);}
`;
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-badge-css')) return;
    const s = document.createElement('style');
    s.id = 'dsf-badge-css';
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/**
 * Soft status pill used across appointments, orders and records
 * (Pendiente / Confirmada / Completada / Cancelada).
 */
function Badge({
  variant = 'neutral',
  size = 'md',
  dot = false,
  pulse = false,
  children,
  className = '',
  ...rest
}) {
  useStyles();
  const cls = ['dsf-badge', `dsf-badge--${variant}`, size === 'sm' ? 'dsf-badge--sm' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    className: `dsf-badge__dot${pulse ? ' dsf-badge__dot--pulse' : ''}`
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Inject component CSS once (real :hover / :active / :focus states). */
const CSS = `
.dsf-btn{
  --_bg:var(--brand-primary);--_bgh:var(--brand-primary-hover);--_bga:var(--brand-primary-active);
  --_fg:var(--text-on-primary);--_bd:transparent;--_sh:none;
  display:inline-flex;align-items:center;justify-content:center;gap:var(--space-2);
  font-family:var(--font-sans);font-weight:var(--font-weight-semibold);
  border:1px solid var(--_bd);border-radius:var(--radius-lg);
  background:var(--_bg);color:var(--_fg);cursor:pointer;white-space:nowrap;
  text-decoration:none;box-shadow:var(--_sh);
  transition:background var(--duration-base) var(--ease-standard),
             box-shadow var(--duration-base) var(--ease-standard),
             border-color var(--duration-base) var(--ease-standard),
             transform var(--duration-base) var(--ease-standard);
}
.dsf-btn:hover{background:var(--_bgh);box-shadow:var(--shadow-primary);}
.dsf-btn:active{background:var(--_bga);transform:scale(var(--press-scale));box-shadow:none;}
.dsf-btn:focus-visible{outline:none;box-shadow:var(--ring-focus);}
.dsf-btn[disabled]{opacity:.5;cursor:not-allowed;box-shadow:none;transform:none;background:var(--_bg);}

.dsf-btn--secondary{--_bg:var(--surface-card);--_bgh:var(--brand-accent-soft);--_bga:var(--brand-accent-soft);
  --_fg:var(--text-body);--_bd:var(--border-default);}
.dsf-btn--secondary:hover{border-color:var(--color-sky-300);color:var(--brand-primary-hover);box-shadow:none;}
.dsf-btn--secondary:active{transform:scale(var(--press-scale));}

.dsf-btn--ghost{--_bg:transparent;--_bgh:var(--surface-sunken);--_bga:var(--surface-sunken);--_fg:var(--text-body);}
.dsf-btn--ghost:hover{color:var(--text-strong);box-shadow:none;}

.dsf-btn--danger{--_bg:var(--color-rose-600);--_bgh:var(--color-rose-700);--_bga:var(--color-rose-700);--_fg:#fff;}
.dsf-btn--danger:hover{box-shadow:none;}

.dsf-btn--sm{font-size:var(--text-xs);padding:var(--space-2) var(--space-3);}
.dsf-btn--md{font-size:var(--text-sm);padding:10px var(--space-5);}
.dsf-btn--lg{font-size:var(--text-base);padding:14px var(--space-6);}
.dsf-btn--block{width:100%;}
`;
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-btn-css')) return;
    const s = document.createElement('style');
    s.id = 'dsf-btn-css';
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/**
 * Primary action button. Matches the product's sky-600 buttons with a tinted
 * hover glow and a 0.98 press scale.
 */
function Button({
  variant = 'primary',
  size = 'md',
  block = false,
  icon = null,
  iconRight = null,
  href,
  children,
  className = '',
  ...rest
}) {
  useStyles();
  const cls = ['dsf-btn', `dsf-btn--${variant}`, `dsf-btn--${size}`, block ? 'dsf-btn--block' : '', className].filter(Boolean).join(' ');
  const content = /*#__PURE__*/React.createElement(React.Fragment, null, icon, children, iconRight);
  if (href) {
    return /*#__PURE__*/React.createElement("a", _extends({
      href: href,
      className: cls
    }, rest), content);
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    className: cls
  }, rest), content);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.dsf-card{
  display:block;background:var(--surface-card);
  border:1px solid var(--border-subtle);border-radius:var(--radius-2xl);
  box-shadow:var(--shadow-sm);
  transition:box-shadow var(--duration-medium) var(--ease-standard),
    border-color var(--duration-medium) var(--ease-standard),
    transform var(--duration-medium) var(--ease-standard);
}
.dsf-card--pad-md{padding:var(--space-6);}
.dsf-card--pad-lg{padding:var(--space-8);}
.dsf-card--pad-none{padding:0;}
.dsf-card--hover:hover{box-shadow:var(--shadow-lg);border-color:var(--border-default);}
.dsf-card--interactive{cursor:pointer;}
.dsf-card--interactive:hover{box-shadow:var(--shadow-lg);border-color:var(--color-sky-200);transform:translateY(-2px);}
.dsf-card--interactive:active{transform:translateY(0);box-shadow:var(--shadow-sm);}
.dsf-card--flat{box-shadow:none;}
a.dsf-card{text-decoration:none;color:inherit;}
`;
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-card-css')) return;
    const s = document.createElement('style');
    s.id = 'dsf-card-css';
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/**
 * Surface container — white, rounded-2xl, soft shadow. The base building block
 * for content panels, feature blocks and list containers.
 */
function Card({
  padding = 'md',
  hover = false,
  interactive = false,
  flat = false,
  href,
  children,
  className = '',
  ...rest
}) {
  useStyles();
  const cls = ['dsf-card', `dsf-card--pad-${padding}`, hover ? 'dsf-card--hover' : '', interactive ? 'dsf-card--interactive' : '', flat ? 'dsf-card--flat' : '', className].filter(Boolean).join(' ');
  if (href) return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    className: cls
  }, rest), children);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.dsf-field{display:flex;flex-direction:column;gap:6px;font-family:var(--font-sans);}
.dsf-field__label{font-size:var(--text-sm);font-weight:var(--font-weight-medium);color:var(--text-strong);}
.dsf-field__req{color:var(--color-rose-600);margin-left:2px;}
.dsf-input{position:relative;display:flex;align-items:center;}
.dsf-input__icon{position:absolute;left:12px;display:flex;color:var(--text-muted);pointer-events:none;}
.dsf-input__el{
  width:100%;box-sizing:border-box;font-family:var(--font-sans);font-size:var(--text-sm);
  color:var(--text-strong);background:var(--surface-card);
  border:1px solid var(--border-default);border-radius:var(--radius-lg);
  padding:11px 14px;transition:border-color var(--duration-base) var(--ease-standard),
    box-shadow var(--duration-base) var(--ease-standard);
}
.dsf-input--icon .dsf-input__el{padding-left:38px;}
.dsf-input__el::placeholder{color:var(--text-muted);}
.dsf-input__el:hover{border-color:var(--border-strong);}
.dsf-input__el:focus{outline:none;border-color:var(--border-focus);
  box-shadow:0 0 0 3px rgb(14 165 233 / .18);}
.dsf-input--sunken .dsf-input__el{background:var(--surface-sunken);border-color:var(--border-default);}
.dsf-input--error .dsf-input__el{border-color:var(--color-rose-400);}
.dsf-input--error .dsf-input__el:focus{box-shadow:0 0 0 3px rgb(244 63 94 / .15);}
.dsf-field__hint{font-size:var(--text-xs);color:var(--text-muted);}
.dsf-field__hint--error{color:var(--color-rose-600);}
`;
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-input-css')) return;
    const s = document.createElement('style');
    s.id = 'dsf-input-css';
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/**
 * Labelled text input with an optional leading icon. Sky focus ring matches
 * the search fields and booking forms across the product.
 */
function Input({
  label,
  icon = null,
  hint,
  error,
  required = false,
  sunken = false,
  id,
  className = '',
  ...rest
}) {
  useStyles();
  const inputId = id || (label ? `dsf-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);
  const wrapCls = ['dsf-input', icon ? 'dsf-input--icon' : '', sunken ? 'dsf-input--sunken' : '', error ? 'dsf-input--error' : ''].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("label", {
    className: `dsf-field ${className}`.trim(),
    htmlFor: inputId
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "dsf-field__label"
  }, label, required && /*#__PURE__*/React.createElement("span", {
    className: "dsf-field__req"
  }, "*")), /*#__PURE__*/React.createElement("span", {
    className: wrapCls
  }, icon && /*#__PURE__*/React.createElement("span", {
    className: "dsf-input__icon"
  }, icon), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    className: "dsf-input__el"
  }, rest))), (error || hint) && /*#__PURE__*/React.createElement("span", {
    className: `dsf-field__hint${error ? ' dsf-field__hint--error' : ''}`
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/patterns/AppointmentRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const STATUS = {
  pendiente: {
    variant: 'warning',
    label: 'Pendiente'
  },
  confirmada: {
    variant: 'info',
    label: 'Confirmada'
  },
  reprogramada: {
    variant: 'info',
    label: 'Reprogramada'
  },
  completada: {
    variant: 'success',
    label: 'Completada'
  },
  cancelada: {
    variant: 'danger',
    label: 'Cancelada'
  }
};
const CSS = `
.dsf-aptrow{
  width:100%;text-align:left;display:flex;align-items:flex-start;gap:12px;
  padding:12px var(--space-6);background:transparent;border:0;cursor:pointer;
  font-family:var(--font-sans);position:relative;
  transition:background var(--duration-base) var(--ease-standard);
}
.dsf-aptrow:hover{background:var(--surface-page);}
.dsf-aptrow--selected{background:var(--color-sky-50);}
.dsf-aptrow--selected::before{content:"";position:absolute;left:0;top:8px;bottom:8px;
  width:3px;border-radius:0 3px 3px 0;background:var(--color-sky-500);}
.dsf-aptrow__main{flex:1;min-width:0;}
.dsf-aptrow__top{display:flex;align-items:baseline;justify-content:space-between;gap:8px;}
.dsf-aptrow__name{font-size:var(--text-sm);font-weight:var(--font-weight-semibold);
  color:var(--text-strong);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.dsf-aptrow--selected .dsf-aptrow__name{color:var(--color-sky-900);}
.dsf-aptrow__time{font-family:var(--font-mono);font-size:var(--text-xs);
  color:var(--text-muted);flex:none;}
.dsf-aptrow__svc{font-size:var(--text-xs);color:var(--text-body);margin-top:2px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.dsf-aptrow__badge{margin-top:8px;}
`;
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-aptrow-css')) return;
    const s = document.createElement('style');
    s.id = 'dsf-aptrow-css';
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/**
 * Appointment list row for the staff agenda — avatar, patient name, time,
 * service and a status badge, with a selected state.
 */
function AppointmentRow({
  patientName,
  time,
  serviceName,
  status = 'pendiente',
  selected = false,
  className = '',
  ...rest
}) {
  useStyles();
  const cfg = STATUS[status] || STATUS.pendiente;
  return /*#__PURE__*/React.createElement("button", _extends({
    className: ['dsf-aptrow', selected ? 'dsf-aptrow--selected' : '', className].filter(Boolean).join(' ')
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    name: patientName,
    size: "sm",
    variant: selected ? 'solid' : 'neutral'
  }), /*#__PURE__*/React.createElement("span", {
    className: "dsf-aptrow__main"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dsf-aptrow__top"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dsf-aptrow__name"
  }, patientName), /*#__PURE__*/React.createElement("span", {
    className: "dsf-aptrow__time"
  }, time)), /*#__PURE__*/React.createElement("span", {
    className: "dsf-aptrow__svc"
  }, serviceName), /*#__PURE__*/React.createElement("span", {
    className: "dsf-aptrow__badge"
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    variant: cfg.variant,
    size: "sm",
    dot: true
  }, cfg.label))));
}
Object.assign(__ds_scope, { AppointmentRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/patterns/AppointmentRow.jsx", error: String((e && e.message) || e) }); }

// components/patterns/ReviewCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.dsf-review{
  display:flex;flex-direction:column;gap:16px;padding:var(--space-6);
  background:var(--surface-card);border:1px solid var(--border-subtle);
  border-radius:var(--radius-xl);box-shadow:var(--shadow-sm);
  font-family:var(--font-sans);
  transition:box-shadow var(--duration-medium) var(--ease-standard),
    border-color var(--duration-medium) var(--ease-standard);
}
.dsf-review:hover{box-shadow:var(--shadow-md);border-color:var(--border-default);}
.dsf-review__head{display:flex;align-items:flex-start;gap:12px;}
.dsf-review__id{flex:1;min-width:0;}
.dsf-review__name{font-size:var(--text-sm);font-weight:var(--font-weight-semibold);
  color:var(--text-strong);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.dsf-review__sub{display:flex;align-items:center;gap:8px;margin-top:4px;}
.dsf-review__src{font-size:10px;color:var(--text-muted);font-weight:var(--font-weight-medium);}
.dsf-review__stars{display:flex;gap:2px;}
.dsf-review__quote{color:var(--color-sky-200);flex:none;}
.dsf-review__text{font-size:var(--text-sm);color:var(--text-body);
  line-height:var(--leading-relaxed);
  display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden;}
`;
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-review-css')) return;
    const s = document.createElement('style');
    s.id = 'dsf-review-css';
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}
function Star({
  filled
}) {
  return /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: filled ? 'var(--color-amber-400)' : 'var(--color-slate-200)'
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 2l2.9 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l7.1-1.01L12 2z"
  }));
}

/**
 * Patient testimonial card — initials avatar, name, star row, source and a
 * clamped quote. Mirrors the verified-Google-reviews grid on the homepage.
 */
function ReviewCard({
  authorName,
  rating = 5,
  text,
  source = 'Google',
  className = '',
  ...rest
}) {
  useStyles();
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `dsf-review ${className}`.trim()
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "dsf-review__head"
  }, /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    name: authorName,
    variant: "solid",
    size: "md"
  }), /*#__PURE__*/React.createElement("div", {
    className: "dsf-review__id"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dsf-review__name"
  }, authorName), /*#__PURE__*/React.createElement("div", {
    className: "dsf-review__sub"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dsf-review__stars"
  }, Array.from({
    length: 5
  }).map((_, i) => /*#__PURE__*/React.createElement(Star, {
    key: i,
    filled: i < rating
  }))), /*#__PURE__*/React.createElement("span", {
    className: "dsf-review__src"
  }, source))), /*#__PURE__*/React.createElement("svg", {
    className: "dsf-review__quote",
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M7.17 6A5.17 5.17 0 0 0 2 11.17V18h6.83v-6.83H5.5A1.67 1.67 0 0 1 7.17 9.5V6zm9 0A5.17 5.17 0 0 0 11 11.17V18h6.83v-6.83H14.5a1.67 1.67 0 0 1 1.67-1.67V6z"
  }))), /*#__PURE__*/React.createElement("p", {
    className: "dsf-review__text"
  }, text));
}
Object.assign(__ds_scope, { ReviewCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/patterns/ReviewCard.jsx", error: String((e && e.message) || e) }); }

// components/patterns/ServiceCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.dsf-service{
  display:flex;flex-direction:column;align-items:center;text-align:center;gap:12px;
  padding:var(--space-5);background:var(--surface-card);
  border:1px solid var(--border-subtle);border-radius:var(--radius-xl);
  font-family:var(--font-sans);text-decoration:none;color:inherit;
  transition:border-color var(--duration-slow) var(--ease-standard),
    box-shadow var(--duration-slow) var(--ease-standard);
}
.dsf-service:hover{border-color:var(--color-sky-200);box-shadow:var(--shadow-lg);}
.dsf-service__icon{
  width:48px;height:48px;border-radius:var(--radius-lg);
  display:flex;align-items:center;justify-content:center;
  background:var(--color-sky-50);color:var(--brand-primary);
  transition:background var(--duration-slow) var(--ease-standard);
}
.dsf-service:hover .dsf-service__icon{background:var(--color-sky-100);}
.dsf-service__name{font-size:var(--text-xs);font-weight:var(--font-weight-semibold);
  color:var(--text-strong);line-height:var(--leading-snug);}
`;
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-service-css')) return;
    const s = document.createElement('style');
    s.id = 'dsf-service-css';
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/**
 * Compact specialty tile — icon chip over a short label. Laid out in a
 * responsive grid on the homepage ("Nuestros Servicios").
 */
function ServiceCard({
  name,
  icon = null,
  href,
  className = '',
  ...rest
}) {
  useStyles();
  const cls = `dsf-service ${className}`.trim();
  const inner = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "dsf-service__icon"
  }, icon), /*#__PURE__*/React.createElement("span", {
    className: "dsf-service__name"
  }, name));
  if (href) return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    className: cls
  }, rest), inner);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), inner);
}
Object.assign(__ds_scope, { ServiceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/patterns/ServiceCard.jsx", error: String((e && e.message) || e) }); }

// components/public/Breadcrumbs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.dsf-bc{
  display:flex;align-items:center;gap:6px;flex-wrap:wrap;
  font-family:var(--font-sans);font-size:var(--text-sm);
}
.dsf-bc__item{display:flex;align-items:center;gap:6px;}
.dsf-bc__link{
  color:var(--text-muted);text-decoration:none;cursor:pointer;background:none;border:0;padding:0;
  transition:color var(--duration-fast) var(--ease-standard);
}
.dsf-bc__link:hover{color:var(--brand-primary);}
.dsf-bc__sep{color:var(--border-strong);}
.dsf-bc__current{color:var(--text-strong);font-weight:var(--font-weight-medium);}
`;
function useStyles(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const s = document.createElement('style');
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }, []);
}
const ChevR = () => /*#__PURE__*/React.createElement("svg", {
  width: "13",
  height: "13",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2.5",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, /*#__PURE__*/React.createElement("path", {
  d: "m9 18 6-6-6-6"
}));

/**
 * Breadcrumb navigation — a list of ancestor pages leading to the current one.
 * Used on interior public pages (Servicios, Perfil, Ubicación, etc.).
 */
function Breadcrumbs({
  items = [],
  className = '',
  ...rest
}) {
  useStyles('dsf-bc-css', CSS);
  return /*#__PURE__*/React.createElement("nav", _extends({
    "aria-label": "Breadcrumb",
    className: `dsf-bc ${className}`.trim()
  }, rest), items.map((item, i) => {
    const isLast = i === items.length - 1;
    return /*#__PURE__*/React.createElement("span", {
      key: i,
      className: "dsf-bc__item"
    }, i > 0 && /*#__PURE__*/React.createElement("span", {
      className: "dsf-bc__sep"
    }, /*#__PURE__*/React.createElement(ChevR, null)), isLast ? /*#__PURE__*/React.createElement("span", {
      className: "dsf-bc__current",
      "aria-current": "page"
    }, item.label) : /*#__PURE__*/React.createElement("button", {
      className: "dsf-bc__link",
      onClick: item.onClick
    }, item.label));
  }));
}
Object.assign(__ds_scope, { Breadcrumbs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/public/Breadcrumbs.jsx", error: String((e && e.message) || e) }); }

// components/public/ContactCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.dsf-contact{
  display:flex;flex-direction:column;gap:0;
  background:var(--surface-card);border:1px solid var(--border-subtle);
  border-radius:var(--radius-2xl);box-shadow:var(--shadow-sm);
  overflow:hidden;font-family:var(--font-sans);
}
.dsf-contact__section{padding:var(--space-5) var(--space-6);}
.dsf-contact__section+.dsf-contact__section{border-top:1px solid var(--border-subtle);}
.dsf-contact__eyebrow{font-size:10px;font-weight:700;text-transform:uppercase;
  letter-spacing:var(--tracking-widest);color:var(--text-muted);margin-bottom:var(--space-3);}
.dsf-contact__row{display:flex;align-items:flex-start;gap:10px;font-size:var(--text-sm);
  color:var(--text-body);margin-bottom:8px;}
.dsf-contact__row:last-child{margin-bottom:0;}
.dsf-contact__icon{flex:none;color:var(--brand-primary);margin-top:1px;}
.dsf-contact__sched{width:100%;font-size:var(--text-sm);}
.dsf-contact__sched tr td:first-child{color:var(--text-body);padding-bottom:6px;padding-right:16px;}
.dsf-contact__sched tr td:last-child{font-family:var(--font-mono);font-size:12px;
  font-weight:600;color:var(--text-strong);text-align:right;}
.dsf-contact__sched .closed td{color:var(--text-muted)!important;}
.dsf-contact__phone{font-family:var(--font-mono);font-size:var(--text-base);font-weight:600;
  color:var(--text-strong);}
`;
function useStyles(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const s = document.createElement('style');
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }, []);
}
const MapPin = () => /*#__PURE__*/React.createElement("svg", {
  width: "16",
  height: "16",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, /*#__PURE__*/React.createElement("path", {
  d: "M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "10",
  r: "3"
}));
const Clock = () => /*#__PURE__*/React.createElement("svg", {
  width: "16",
  height: "16",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "10"
}), /*#__PURE__*/React.createElement("path", {
  d: "M12 6v6l4 2"
}));
const Phone = () => /*#__PURE__*/React.createElement("svg", {
  width: "16",
  height: "16",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, /*#__PURE__*/React.createElement("path", {
  d: "M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.21 15.8 19.8 19.8 0 0 1 1.14 7.18 2 2 0 0 1 3.11 5h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L7.09 12.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z"
}));

/**
 * Contact info card — address, schedule table and phone. Used in the
 * homepage contact section and the Ubicación page.
 */
function ContactCard({
  address,
  city,
  schedule = [],
  phone,
  className = '',
  ...rest
}) {
  useStyles('dsf-contact-css', CSS);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `dsf-contact ${className}`.trim()
  }, rest), (address || city) && /*#__PURE__*/React.createElement("div", {
    className: "dsf-contact__section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dsf-contact__eyebrow"
  }, "Consultorio"), /*#__PURE__*/React.createElement("div", {
    className: "dsf-contact__row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dsf-contact__icon"
  }, /*#__PURE__*/React.createElement(MapPin, null)), /*#__PURE__*/React.createElement("span", null, address, city ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, city)) : null))), schedule.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "dsf-contact__section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dsf-contact__eyebrow"
  }, "Horario de atenci\xF3n"), /*#__PURE__*/React.createElement("div", {
    className: "dsf-contact__row",
    style: {
      marginBottom: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "dsf-contact__icon"
  }, /*#__PURE__*/React.createElement(Clock, null)), /*#__PURE__*/React.createElement("table", {
    className: "dsf-contact__sched"
  }, /*#__PURE__*/React.createElement("tbody", null, schedule.map((s, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    className: s.hours === 'Cerrado' ? 'closed' : ''
  }, /*#__PURE__*/React.createElement("td", null, s.days), /*#__PURE__*/React.createElement("td", null, s.hours))))))), phone && /*#__PURE__*/React.createElement("div", {
    className: "dsf-contact__section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dsf-contact__eyebrow"
  }, "Tel\xE9fono"), /*#__PURE__*/React.createElement("div", {
    className: "dsf-contact__row",
    style: {
      marginBottom: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "dsf-contact__icon"
  }, /*#__PURE__*/React.createElement(Phone, null)), /*#__PURE__*/React.createElement("span", {
    className: "dsf-contact__phone"
  }, phone))));
}
Object.assign(__ds_scope, { ContactCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/public/ContactCard.jsx", error: String((e && e.message) || e) }); }

// components/public/DoctorCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.dsf-dc{
  display:flex;flex-direction:column;background:var(--surface-card);
  border:1px solid var(--border-subtle);border-radius:var(--radius-2xl);
  box-shadow:var(--shadow-sm);overflow:hidden;font-family:var(--font-sans);
}
.dsf-dc__photo{position:relative;width:100%;background:var(--color-sky-50);}
.dsf-dc__photo img{width:100%;height:100%;object-fit:cover;object-position:center top;display:block;}
.dsf-dc__body{padding:var(--space-6);}
.dsf-dc__badge{
  display:inline-flex;align-items:center;gap:6px;margin-bottom:12px;
  font-size:var(--text-xs);font-weight:var(--font-weight-bold);
  text-transform:uppercase;letter-spacing:var(--tracking-widest);
  color:var(--brand-primary);background:var(--surface-primary-soft);
  padding:4px 12px;border-radius:var(--radius-full);
}
.dsf-dc__name{font-family:var(--font-heading);font-size:var(--text-xl);font-weight:700;
  color:var(--text-strong);line-height:var(--leading-snug);margin-bottom:4px;}
.dsf-dc__title{font-size:var(--text-sm);color:var(--brand-primary);font-weight:var(--font-weight-semibold);margin-bottom:var(--space-4);}
.dsf-dc__bio{font-size:var(--text-sm);color:var(--text-body);line-height:var(--leading-relaxed);margin-bottom:var(--space-4);}
.dsf-dc__certs{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:var(--space-4);}
.dsf-dc__cert{font-size:11px;font-weight:500;color:var(--text-body);
  background:var(--surface-sunken);padding:4px 10px;border-radius:var(--radius-full);}
.dsf-dc__ceds{display:flex;gap:8px;flex-wrap:wrap;}
.dsf-dc__ced{font-family:var(--font-mono);font-size:11px;font-weight:500;
  padding:4px 10px;border-radius:var(--radius-sm);}
.dsf-dc__ced--prof{background:var(--surface-sunken);color:var(--text-body);}
.dsf-dc__ced--esp{background:var(--color-sky-50);color:var(--color-sky-700);}
`;
function useStyles(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const s = document.createElement('style');
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }, []);
}

/**
 * Doctor profile card — photo, name, specialty title, bio blurb, certifications
 * and cédulas. Used in the public hero, profile page and sidebar.
 */
function DoctorCard({
  name,
  title,
  bio,
  photoSrc,
  photoHeight = 260,
  experienceYears,
  certifications = [],
  license,
  specialtyLicense,
  className = '',
  ...rest
}) {
  useStyles('dsf-dc-css', CSS);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `dsf-dc ${className}`.trim()
  }, rest), photoSrc && /*#__PURE__*/React.createElement("div", {
    className: "dsf-dc__photo",
    style: {
      height: photoHeight
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: photoSrc,
    alt: name
  })), /*#__PURE__*/React.createElement("div", {
    className: "dsf-dc__body"
  }, experienceYears && /*#__PURE__*/React.createElement("span", {
    className: "dsf-dc__badge"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--brand-primary)',
      animation: 'ds-pulse 1.6s ease-in-out infinite'
    }
  }), experienceYears, "+ a\xF1os de experiencia"), /*#__PURE__*/React.createElement("div", {
    className: "dsf-dc__name"
  }, name), title && /*#__PURE__*/React.createElement("div", {
    className: "dsf-dc__title"
  }, title), bio && /*#__PURE__*/React.createElement("p", {
    className: "dsf-dc__bio"
  }, bio), certifications.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "dsf-dc__certs"
  }, certifications.map((c, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    className: "dsf-dc__cert"
  }, c))), (license || specialtyLicense) && /*#__PURE__*/React.createElement("div", {
    className: "dsf-dc__ceds"
  }, license && /*#__PURE__*/React.createElement("span", {
    className: "dsf-dc__ced dsf-dc__ced--prof"
  }, "C\xE9d. Prof. ", license), specialtyLicense && /*#__PURE__*/React.createElement("span", {
    className: "dsf-dc__ced dsf-dc__ced--esp"
  }, "C\xE9d. Esp. ", specialtyLicense))));
}
Object.assign(__ds_scope, { DoctorCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/public/DoctorCard.jsx", error: String((e && e.message) || e) }); }

// components/public/PublicHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.dsf-ph{
  position:sticky;top:0;z-index:50;
  background:rgba(255,255,255,.95);
  backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
  border-bottom:1px solid var(--border-subtle);
  font-family:var(--font-sans);
}
.dsf-ph__inner{
  max-width:var(--container-max);margin:0 auto;
  height:var(--header-h);
  padding:0 var(--space-6);
  display:flex;align-items:center;justify-content:space-between;gap:var(--space-8);
}
.dsf-ph__logo{cursor:pointer;display:flex;align-items:center;flex:none;}
.dsf-ph__logo img{height:46px;width:auto;}
.dsf-ph__nav{display:flex;align-items:center;gap:var(--space-8);}
.dsf-ph__link{
  font-size:var(--text-sm);font-weight:var(--font-weight-medium);
  color:var(--text-body);text-decoration:none;cursor:pointer;background:none;border:0;padding:0;
  transition:color var(--duration-fast) var(--ease-standard);
}
.dsf-ph__link:hover,.dsf-ph__link.active{color:var(--brand-primary);}
.dsf-ph__cta{
  display:inline-flex;align-items:center;gap:var(--space-2);flex:none;
  font-family:var(--font-sans);font-size:var(--text-sm);font-weight:var(--font-weight-semibold);
  padding:8px var(--space-5);border-radius:var(--radius-lg);border:0;cursor:pointer;
  background:var(--brand-primary);color:#fff;text-decoration:none;white-space:nowrap;
  transition:background var(--duration-base) var(--ease-standard),box-shadow var(--duration-base) var(--ease-standard);
}
.dsf-ph__cta:hover{background:var(--brand-primary-hover);box-shadow:var(--shadow-primary);}
.dsf-ph__menu{display:none;align-items:center;justify-content:center;width:36px;height:36px;
  border-radius:var(--radius-md);border:1px solid var(--border-default);background:transparent;cursor:pointer;}
@media(max-width:700px){.dsf-ph__nav-links{display:none;}.dsf-ph__menu{display:flex;}}
`;
function useStyles(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const s = document.createElement('style');
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }, []);
}

/**
 * Sticky translucent public-site header — logo, nav links, and a booking CTA.
 */
function PublicHeader({
  links = [],
  activePage,
  onNav,
  ctaLabel = 'Agendar Cita',
  logoSrc = '/assets/logo-otorrinonet-transparent.svg',
  className = '',
  ...rest
}) {
  useStyles('dsf-ph-css', CSS);
  const CalIcon = () => /*#__PURE__*/React.createElement("svg", {
    width: "15",
    height: "15",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "4",
    width: "18",
    height: "18",
    rx: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M16 2v4M8 2v4M3 10h18"
  }));
  const MenuIcon = () => /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M4 12h16M4 6h16M4 18h16"
  }));
  return /*#__PURE__*/React.createElement("nav", _extends({
    className: `dsf-ph ${className}`.trim()
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "dsf-ph__inner"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dsf-ph__logo",
    onClick: () => onNav?.('inicio')
  }, /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "Logo"
  })), /*#__PURE__*/React.createElement("div", {
    className: "dsf-ph__nav"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dsf-ph__nav-links",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-8)'
    }
  }, links.map(([id, label]) => /*#__PURE__*/React.createElement("button", {
    key: id,
    className: `dsf-ph__link${activePage === id ? ' active' : ''}`,
    onClick: () => onNav?.(id)
  }, label))), /*#__PURE__*/React.createElement("button", {
    className: "dsf-ph__menu",
    "aria-label": "Men\xFA"
  }, /*#__PURE__*/React.createElement(MenuIcon, null)), /*#__PURE__*/React.createElement("button", {
    className: "dsf-ph__cta",
    onClick: () => onNav?.('agendar')
  }, /*#__PURE__*/React.createElement(CalIcon, null), ctaLabel))));
}
Object.assign(__ds_scope, { PublicHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/public/PublicHeader.jsx", error: String((e && e.message) || e) }); }

// components/public/RatingSummary.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.dsf-rating{
  display:inline-flex;align-items:center;gap:12px;
  background:var(--surface-card);border:1px solid var(--border-subtle);
  border-radius:var(--radius-xl);box-shadow:var(--shadow-md);
  padding:10px 16px;font-family:var(--font-sans);
}
.dsf-rating__score{display:flex;flex-direction:column;align-items:flex-start;}
.dsf-rating__num{font-family:var(--font-heading);font-size:var(--text-2xl);font-weight:700;
  color:var(--text-strong);line-height:1;}
.dsf-rating__of{font-size:var(--text-xs);color:var(--text-muted);}
.dsf-rating__div{width:1px;background:var(--border-default);align-self:stretch;}
.dsf-rating__stars{display:flex;flex-direction:column;gap:4px;}
.dsf-rating__row{display:flex;gap:2px;}
.dsf-rating__src{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--text-muted);}
.dsf-rating__count{font-size:11px;color:var(--text-muted);}
`;
function useStyles(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const s = document.createElement('style');
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }, []);
}
function Star({
  filled,
  size = 14
}) {
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: filled ? 'var(--color-amber-400)' : 'var(--color-slate-200)'
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 2l2.9 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l7.1-1.01L12 2z"
  }));
}

/**
 * Compact floating Google-rating widget — score, star row and review count.
 * Used as the floating badge on the hero image and on the profile page.
 */
function RatingSummary({
  average = 5.0,
  total = 0,
  source = 'Google',
  starSize = 14,
  className = '',
  ...rest
}) {
  useStyles('dsf-rating-css', CSS);
  const full = Math.round(average);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `dsf-rating ${className}`.trim()
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "dsf-rating__score"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dsf-rating__num"
  }, average.toFixed(1)), /*#__PURE__*/React.createElement("span", {
    className: "dsf-rating__of"
  }, "/ 5")), /*#__PURE__*/React.createElement("div", {
    className: "dsf-rating__div"
  }), /*#__PURE__*/React.createElement("div", {
    className: "dsf-rating__stars"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dsf-rating__row"
  }, [0, 1, 2, 3, 4].map(i => /*#__PURE__*/React.createElement(Star, {
    key: i,
    filled: i < full,
    size: starSize
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, total > 0 && /*#__PURE__*/React.createElement("span", {
    className: "dsf-rating__count"
  }, total, " rese\xF1as"), total > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--border-default)'
    }
  }, "\xB7"), /*#__PURE__*/React.createElement("span", {
    className: "dsf-rating__src"
  }, source))));
}
Object.assign(__ds_scope, { RatingSummary });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/public/RatingSummary.jsx", error: String((e && e.message) || e) }); }

// ui_kits/panel-clinico/data.js
try { (() => {
/* Sample clinical data for the staff panel (fictional patients). */
window.STAFF_DATA = {
  user: {
    name: 'Dr. Alejandro Viveros',
    role: 'Médico'
  },
  appointments: [{
    id: 'a1',
    name: 'Yazmín García',
    time: '10:00',
    service: 'Consulta ORL General',
    status: 'confirmada',
    day: 'Hoy · 9 jun',
    phone: '55 1432 8890',
    email: 'yazmin.g@correo.com',
    reason: 'Congestión nasal persistente y dolor de oído derecho desde hace dos semanas.'
  }, {
    id: 'a2',
    name: 'Consuelo Domínguez',
    time: '10:30',
    service: 'Audiología',
    status: 'pendiente',
    day: 'Hoy · 9 jun',
    phone: '55 2901 7745',
    email: 'consuelo.d@correo.com',
    reason: 'Evaluación de audición; refiere disminución auditiva del oído izquierdo.'
  }, {
    id: 'a3',
    name: 'Mijo León',
    time: '11:00',
    service: 'Rinitis Alérgica',
    status: 'confirmada',
    day: 'Hoy · 9 jun',
    phone: '55 6677 1203',
    email: 'mijo.leon@correo.com',
    reason: 'Seguimiento de inmunoterapia, tercera dosis.'
  }, {
    id: 'a4',
    name: 'Karen Sandoval',
    time: '16:00',
    service: 'Cirugía ORL',
    status: 'pendiente',
    day: 'Hoy · 9 jun',
    phone: '55 8123 0098',
    email: 'karen.s@correo.com',
    reason: 'Valoración prequirúrgica para septoplastia.'
  }, {
    id: 'a5',
    name: 'Alejandra Vázquez',
    time: '10:00',
    service: 'Vértigo y Equilibrio',
    status: 'confirmada',
    day: 'Mañana · 10 jun',
    phone: '55 3456 7788',
    email: 'ale.v@correo.com',
    reason: 'Episodios de vértigo posicional al levantarse.'
  }, {
    id: 'a6',
    name: 'Roberto Méndez',
    time: '11:30',
    service: 'Consulta ORL General',
    status: 'cancelada',
    day: 'Mañana · 10 jun',
    phone: '55 9988 2210',
    email: 'rmendez@correo.com',
    reason: 'Dolor de garganta recurrente.'
  }],
  patients: [{
    name: 'Yazmín García Soto',
    exp: 'EXP-0428',
    age: 34,
    sex: 'Femenino',
    updated: 'Hoy'
  }, {
    name: 'Consuelo Domínguez Ruiz',
    exp: 'EXP-0427',
    age: 61,
    sex: 'Femenino',
    updated: 'Hoy'
  }, {
    name: 'Mijo León Aguilar',
    exp: 'EXP-0425',
    age: 28,
    sex: 'Masculino',
    updated: 'Ayer'
  }, {
    name: 'Karen Sandoval Pérez',
    exp: 'EXP-0419',
    age: 45,
    sex: 'Femenino',
    updated: 'Hace 3 días'
  }, {
    name: 'Alejandra Vázquez Mora',
    exp: 'EXP-0411',
    age: 52,
    sex: 'Femenino',
    updated: 'Hace 1 sem.'
  }, {
    name: 'Roberto Méndez Lara',
    exp: 'EXP-0402',
    age: 39,
    sex: 'Masculino',
    updated: 'Hace 2 sem.'
  }],
  clinic: {
    name: 'Consultorio Dr. Alejandro Viveros Domínguez — ORL',
    address: 'Chosica 730, Col. Lindavista, GAM, CDMX 07300',
    phone: 'Tel. 55 5586 0000',
    cofepris: '193300C0234'
  },
  doctor: {
    name: 'Dr. Alejandro Viveros Domínguez',
    university: 'Otorrinolaringología — UNAM · CMN La Raza',
    license: 'Céd. Prof. 6277305',
    specialtyLicense: 'Céd. Esp. 10148701'
  },
  prescriptions: [{
    id: 'rx1',
    status: 'firmada',
    patientName: 'Yazmín García Soto',
    date: '2026-06-09',
    patientAge: 34,
    patientSex: 'Femenino',
    patientWeight: 62,
    patientAllergies: ['Penicilina'],
    diagnosis: 'Rinosinusitis aguda bacteriana',
    signedAt: '2026-06-09T17:24:00',
    signatureTimestamp: '2026-06-09T23:24:00Z',
    medications: [{
      name: 'Amoxicilina/Clavulanato',
      brandName: 'Augmentin',
      presentation: 'Tabletas 875/125 mg',
      dose: '875 mg',
      frequency: 'c/12 h',
      duration: '10 días',
      route: 'Oral',
      instructions: 'Tomar con alimentos.'
    }, {
      name: 'Mometasona',
      brandName: 'Nasonex',
      presentation: 'Spray nasal 50 mcg',
      dose: '2 disparos por fosa',
      frequency: 'c/24 h',
      duration: '4 semanas',
      route: 'Nasal',
      instructions: 'Agitar antes de usar; sonarse la nariz previamente.'
    }, {
      name: 'Paracetamol',
      brandName: '',
      presentation: 'Tabletas 500 mg',
      dose: '500 mg',
      frequency: 'c/8 h por dolor',
      duration: '5 días',
      route: 'Oral',
      instructions: ''
    }]
  }, {
    id: 'rx2',
    status: 'borrador',
    patientName: 'Mijo León Aguilar',
    date: '2026-06-09',
    patientAge: 28,
    patientSex: 'Masculino',
    diagnosis: 'Rinitis alérgica perenne',
    medications: [{
      name: 'Loratadina',
      brandName: 'Clarityne',
      presentation: 'Tabletas 10 mg',
      dose: '10 mg',
      frequency: 'c/24 h',
      duration: '30 días',
      route: 'Oral',
      instructions: 'Preferentemente por la mañana.'
    }]
  }, {
    id: 'rx3',
    status: 'firmada',
    patientName: 'Consuelo Domínguez Ruiz',
    date: '2026-06-05',
    patientAge: 61,
    patientSex: 'Femenino',
    diagnosis: 'Otitis externa difusa',
    signedAt: '2026-06-05T11:10:00',
    signatureTimestamp: '2026-06-05T17:10:00Z',
    medications: [{
      name: 'Ciprofloxacino/Hidrocortisona',
      brandName: 'Cipro HC',
      presentation: 'Gotas óticas',
      dose: '3 gotas oído afectado',
      frequency: 'c/12 h',
      duration: '7 días',
      route: 'Ótica',
      instructions: 'Mantener la cabeza inclinada 2 min tras la aplicación.'
    }]
  }],
  dashboard: {
    stats: [{
      label: 'Citas hoy',
      value: '4',
      delta: '+2',
      tone: 'info'
    }, {
      label: 'Pendientes',
      value: '2',
      delta: 'por confirmar',
      tone: 'warning'
    }, {
      label: 'Pacientes',
      value: '128',
      delta: '+6 este mes',
      tone: 'success'
    }, {
      label: 'Ventas tienda',
      value: '$8,450',
      delta: '+12%',
      tone: 'info'
    }],
    week: [{
      d: 'Lun',
      v: 6
    }, {
      d: 'Mar',
      v: 8
    }, {
      d: 'Mié',
      v: 5
    }, {
      d: 'Jue',
      v: 9
    }, {
      d: 'Vie',
      v: 7
    }, {
      d: 'Sáb',
      v: 2
    }, {
      d: 'Dom',
      v: 0
    }]
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/panel-clinico/data.js", error: String((e && e.message) || e) }); }

// ui_kits/panel-clinico/recetas.jsx
try { (() => {
/* Recetas — improved prescription flow: list → official document → new form.
   Cleaner letterhead, ℞ medication entries, refined electronic-signature block. */

const RxAL = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M19 12H5M12 19l-7-7 7-7"
}));
const RxPrint = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"
}), /*#__PURE__*/React.createElement("rect", {
  x: "6",
  y: "14",
  width: "12",
  height: "8",
  rx: "1"
}));
const RxPen = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"
}));
const RxLock = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("rect", {
  x: "3",
  y: "11",
  width: "18",
  height: "11",
  rx: "2"
}), /*#__PURE__*/React.createElement("path", {
  d: "M7 11V7a5 5 0 0 1 10 0v4"
}));
const RxTrash = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2m2 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"
}));
const RxPin = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "10",
  r: "3"
}));
const RxPhone = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z"
}));
function fmtDate(d) {
  return new Date(d + 'T00:00:00').toLocaleDateString('es-MX', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  });
}
function fmtStamp(iso) {
  return new Date(iso).toLocaleString('es-MX', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

/* ── Official prescription document ─────────────────────────────────────── */
function Receta({
  rx,
  onBack,
  onSign
}) {
  const D = window.STAFF_DATA.doctor,
    C = window.STAFF_DATA.clinic;
  const [signing, setSigning] = React.useState(false);
  const signed = rx.status === 'firmada';
  const vitals = [rx.patientAge != null && ['Edad', rx.patientAge + ' años'], rx.patientSex && ['Sexo', rx.patientSex], rx.patientWeight != null && ['Peso', rx.patientWeight + ' kg']].filter(Boolean);
  const lbl = {
    fontSize: 10,
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '.1em',
    color: 'var(--text-muted)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100vh',
      overflowY: 'auto',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 10,
      background: 'rgba(255,255,255,.92)',
      backdropFilter: 'blur(8px)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 680,
      margin: '0 auto',
      padding: '12px 20px',
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    className: "rx-icon-btn"
  }, /*#__PURE__*/React.createElement(RxAL, {
    size: 17
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      fontFamily: 'var(--font-heading)',
      color: 'var(--text-strong)'
    }
  }, "Receta m\xE9dica"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)'
    }
  }, rx.patientName)), /*#__PURE__*/React.createElement(SBadge, {
    variant: signed ? 'success' : 'warning',
    dot: true
  }, signed ? 'Firmada' : 'Borrador'), signed && /*#__PURE__*/React.createElement(SButton, {
    variant: "secondary",
    size: "sm",
    icon: RxPrint,
    onClick: () => window.open('receta-pdf.html', '_blank')
  }, "Imprimir"))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 680,
      margin: '0 auto',
      padding: '28px 20px 48px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-2xl)',
      boxShadow: 'var(--shadow-lg)',
      border: '1px solid var(--border-subtle)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '26px 32px 22px',
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 20,
      borderBottom: '2px solid var(--color-sky-600)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'center',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-otorrinonet-transparent.svg",
    alt: "",
    style: {
      height: 52,
      width: 'auto',
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 16,
      fontWeight: 700,
      color: 'var(--text-strong)',
      lineHeight: 1.2
    }
  }, D.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--brand-primary)',
      fontWeight: 600,
      marginTop: 2
    }
  }, D.university), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      marginTop: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-body)',
      background: 'var(--surface-sunken)',
      padding: '2px 8px',
      borderRadius: 'var(--radius-sm)'
    }
  }, D.license), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--color-sky-700)',
      background: 'var(--color-sky-50)',
      padding: '2px 8px',
      borderRadius: 'var(--radius-sm)'
    }
  }, D.specialtyLicense)))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 40,
      fontWeight: 700,
      color: 'var(--color-sky-200)',
      lineHeight: 1,
      flex: 'none'
    }
  }, "\u211E")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 32px',
      display: 'flex',
      gap: 18,
      flexWrap: 'wrap',
      background: 'var(--surface-page)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      fontSize: 11.5,
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement(RxPin, {
    size: 13,
    style: {
      color: 'var(--text-muted)'
    }
  }), C.address), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      fontSize: 11.5,
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement(RxPhone, {
    size: 13,
    style: {
      color: 'var(--text-muted)'
    }
  }), C.phone), C.cofepris && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11.5,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)'
    }
  }, "AF: ", C.cofepris)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 32px',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 20,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: lbl
  }, "Paciente"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      color: 'var(--text-strong)',
      marginTop: 4
    }
  }, rx.patientName)), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: lbl
  }, "Fecha de expedici\xF3n"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--text-strong)',
      marginTop: 4
    }
  }, fmtDate(rx.date)))), (vitals.length > 0 || rx.patientAllergies) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 28,
      flexWrap: 'wrap',
      marginTop: 16
    }
  }, vitals.map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k
  }, /*#__PURE__*/React.createElement("div", {
    style: lbl
  }, k), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 500,
      color: 'var(--text-body)',
      marginTop: 3
    }
  }, v))), rx.patientAllergies && rx.patientAllergies.length > 0 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: lbl
  }, "Alergias"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(SBadge, {
    variant: "danger",
    dot: true,
    sm: true
  }, rx.patientAllergies.join(', ')))))), rx.diagnosis && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 32px',
      borderBottom: '1px solid var(--border-subtle)',
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'var(--color-amber-400)',
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      ...lbl,
      marginRight: 10
    }
  }, "Diagn\xF3stico"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--text-strong)',
      fontWeight: 500
    }
  }, rx.diagnosis))), /*#__PURE__*/React.createElement("div", null, rx.medications.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: '20px 32px',
      borderBottom: i < rx.medications.length - 1 ? '1px solid var(--border-subtle)' : 0,
      display: 'flex',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 26,
      height: 26,
      borderRadius: '50%',
      flex: 'none',
      background: 'var(--color-sky-50)',
      color: 'var(--brand-primary)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 12,
      fontWeight: 700,
      fontFamily: 'var(--font-mono)',
      marginTop: 2
    }
  }, i + 1), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15.5,
      fontWeight: 700,
      fontFamily: 'var(--font-heading)',
      color: 'var(--text-strong)'
    }
  }, m.name), m.brandName && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12.5,
      fontStyle: 'italic',
      color: 'var(--text-muted)'
    }
  }, "(", m.brandName, ")")), m.presentation && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: 'var(--text-body)',
      marginTop: 2
    }
  }, m.presentation), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap',
      marginTop: 12
    }
  }, [['Dosis', m.dose], ['Frecuencia', m.frequency], ['Duración', m.duration || '—'], m.route && ['Vía', m.route]].filter(Boolean).map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      background: 'var(--surface-page)',
      borderRadius: 'var(--radius-md)',
      padding: '6px 12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '.08em',
      color: 'var(--text-muted)'
    }
  }, k), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--text-strong)',
      marginTop: 1
    }
  }, v)))), m.instructions && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: 'var(--text-body)',
      fontStyle: 'italic',
      marginTop: 10,
      paddingLeft: 12,
      borderLeft: '2px solid var(--border-default)'
    }
  }, m.instructions))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px 32px 28px',
      background: 'var(--surface-page)'
    }
  }, signed ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 220,
      borderBottom: '1.5px solid var(--text-strong)',
      paddingBottom: 6,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 22,
      color: 'var(--brand-primary)',
      fontStyle: 'italic'
    }
  }, "A. Viveros")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--text-strong)'
    }
  }, D.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      fontSize: 11,
      color: 'var(--state-success-fg)',
      background: 'var(--state-success-bg)',
      padding: '5px 12px',
      borderRadius: 'var(--radius-full)',
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement(RxLock, {
    size: 12
  }), "Firma electr\xF3nica \xB7 SHA-256"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10.5,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)',
      textAlign: 'center',
      marginTop: 2
    }
  }, "Sellada: ", fmtStamp(rx.signedAt), /*#__PURE__*/React.createElement("br", null), "UTC ", rx.signatureTimestamp)) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 320,
      border: '2px dashed var(--border-default)',
      borderRadius: 'var(--radius-xl)',
      padding: '18px',
      textAlign: 'center',
      color: 'var(--text-muted)',
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement(RxPen, {
    size: 20,
    style: {
      color: 'var(--color-amber-400)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 6
    }
  }, "Pendiente de firma. Al firmar se genera un sello SHA-256 con timestamp (NOM-004) y la receta queda inmutable.")), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 320
    }
  }, /*#__PURE__*/React.createElement(SButton, {
    icon: RxLock,
    onClick: () => {
      setSigning(true);
      setTimeout(() => {
        setSigning(false);
        onSign(rx.id);
      }, 700);
    }
  }, signing ? 'Firmando…' : 'Firmar receta')))))));
}

/* ── New prescription form ──────────────────────────────────────────────── */
const EMPTY_MED = {
  name: '',
  brandName: '',
  presentation: '',
  dose: '',
  frequency: '',
  duration: '',
  route: '',
  instructions: ''
};
function RxField({
  label,
  value,
  onChange,
  placeholder,
  req
}) {
  const [f, setF] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 5,
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '.08em',
      color: 'var(--text-muted)'
    }
  }, label, req && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--color-rose-600)'
    }
  }, " *")), /*#__PURE__*/React.createElement("input", {
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value),
    onFocus: () => setF(true),
    onBlur: () => setF(false),
    style: {
      width: '100%',
      boxSizing: 'border-box',
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      color: 'var(--text-strong)',
      background: 'var(--surface-card)',
      border: `1px solid ${f ? 'var(--border-focus)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-lg)',
      padding: '9px 12px',
      outline: 'none',
      boxShadow: f ? '0 0 0 3px rgb(14 165 233 / .18)' : 'none',
      transition: 'all .15s'
    }
  }));
}
function RecetaForm({
  onCancel,
  onSave
}) {
  const [diagnosis, setDiagnosis] = React.useState('');
  const [meds, setMeds] = React.useState([{
    ...EMPTY_MED
  }]);
  const set = (i, k, v) => setMeds(p => p.map((m, idx) => idx === i ? {
    ...m,
    [k]: v
  } : m));
  const card = {
    background: 'var(--surface-card)',
    border: '1px solid var(--border-default)',
    borderRadius: 'var(--radius-2xl)',
    padding: 22
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100vh',
      overflowY: 'auto',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 10,
      background: 'rgba(255,255,255,.92)',
      backdropFilter: 'blur(8px)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 680,
      margin: '0 auto',
      padding: '12px 20px',
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onCancel,
    className: "rx-icon-btn"
  }, /*#__PURE__*/React.createElement(RxAL, {
    size: 17
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      fontFamily: 'var(--font-heading)',
      color: 'var(--text-strong)'
    }
  }, "Nueva receta m\xE9dica"))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 680,
      margin: '0 auto',
      padding: '24px 20px 48px',
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: card
  }, /*#__PURE__*/React.createElement(RxField, {
    label: "Diagn\xF3stico / indicaci\xF3n",
    value: diagnosis,
    onChange: setDiagnosis,
    placeholder: "Ej. Rinosinusitis aguda bacteriana"
  })), meds.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: card
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 24,
      height: 24,
      borderRadius: '50%',
      background: 'var(--color-sky-50)',
      color: 'var(--brand-primary)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 12,
      fontWeight: 700,
      fontFamily: 'var(--font-mono)'
    }
  }, i + 1), meds.length > 1 && /*#__PURE__*/React.createElement("button", {
    onClick: () => setMeds(p => p.filter((_, idx) => idx !== i)),
    className: "rx-icon-btn rx-icon-btn--danger"
  }, /*#__PURE__*/React.createElement(RxTrash, {
    size: 15
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(RxField, {
    label: "Nombre gen\xE9rico",
    req: true,
    value: m.name,
    onChange: v => set(i, 'name', v),
    placeholder: "Amoxicilina"
  }), /*#__PURE__*/React.createElement(RxField, {
    label: "Nombre comercial",
    value: m.brandName,
    onChange: v => set(i, 'brandName', v),
    placeholder: "Amoxil"
  })), /*#__PURE__*/React.createElement(RxField, {
    label: "Presentaci\xF3n",
    value: m.presentation,
    onChange: v => set(i, 'presentation', v),
    placeholder: "C\xE1psulas 500 mg"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(RxField, {
    label: "Dosis",
    req: true,
    value: m.dose,
    onChange: v => set(i, 'dose', v),
    placeholder: "500 mg"
  }), /*#__PURE__*/React.createElement(RxField, {
    label: "Frecuencia",
    req: true,
    value: m.frequency,
    onChange: v => set(i, 'frequency', v),
    placeholder: "c/8 h"
  }), /*#__PURE__*/React.createElement(RxField, {
    label: "Duraci\xF3n",
    value: m.duration,
    onChange: v => set(i, 'duration', v),
    placeholder: "7 d\xEDas"
  }), /*#__PURE__*/React.createElement(RxField, {
    label: "V\xEDa",
    value: m.route,
    onChange: v => set(i, 'route', v),
    placeholder: "Oral"
  })), /*#__PURE__*/React.createElement(RxField, {
    label: "Indicaciones adicionales",
    value: m.instructions,
    onChange: v => set(i, 'instructions', v),
    placeholder: "Tomar con alimentos"
  })))), /*#__PURE__*/React.createElement("button", {
    onClick: () => setMeds(p => [...p, {
      ...EMPTY_MED
    }]),
    className: "rx-add"
  }, /*#__PURE__*/React.createElement(SPlus, {
    size: 16,
    sw: 2.4
  }), "Agregar medicamento"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement(SButton, {
    variant: "secondary",
    onClick: onCancel
  }, "Cancelar"), /*#__PURE__*/React.createElement(SButton, {
    icon: RxPen,
    onClick: () => {
      const valid = meds.filter(m => m.name && m.dose && m.frequency);
      if (valid.length) onSave(valid, diagnosis);
    }
  }, "Crear receta"))));
}

/* ── Recetas list (entry) ───────────────────────────────────────────────── */
function Recetas() {
  const [list, setList] = React.useState(window.STAFF_DATA.prescriptions);
  const [mode, setMode] = React.useState('list'); // list | detail | new
  const [sel, setSel] = React.useState(null);
  const [q, setQ] = React.useState('');
  const sign = id => setList(p => p.map(r => r.id === id ? {
    ...r,
    status: 'firmada',
    signedAt: new Date().toISOString(),
    signatureTimestamp: new Date().toISOString()
  } : r));
  const create = (meds, diagnosis) => {
    const rx = {
      id: 'rx' + Date.now(),
      status: 'borrador',
      patientName: 'Nuevo paciente',
      date: new Date().toISOString().slice(0, 10),
      patientAge: null,
      patientSex: '',
      diagnosis,
      medications: meds
    };
    setList(p => [rx, ...p]);
    setSel(rx);
    setMode('detail');
  };
  if (mode === 'detail' && sel) return /*#__PURE__*/React.createElement(Receta, {
    rx: list.find(r => r.id === sel.id) || sel,
    onBack: () => setMode('list'),
    onSign: sign
  });
  if (mode === 'new') return /*#__PURE__*/React.createElement(RecetaForm, {
    onCancel: () => setMode('list'),
    onSave: create
  });
  const filtered = list.filter(r => !q || r.patientName.toLowerCase().includes(q.toLowerCase()) || (r.diagnosis || '').toLowerCase().includes(q.toLowerCase()));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100vh',
      overflowY: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 760,
      margin: '0 auto',
      padding: '32px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 16,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 24,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: 0
    }
  }, "Recetas"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      margin: '4px 0 0'
    }
  }, list.length, " recetas \xB7 ", list.filter(r => r.status === 'firmada').length, " firmadas")), /*#__PURE__*/React.createElement(SButton, {
    icon: SPlus,
    onClick: () => setMode('new')
  }, "Nueva receta")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      margin: '16px 0'
    }
  }, /*#__PURE__*/React.createElement(SSearch, {
    size: 16,
    style: {
      position: 'absolute',
      left: 14,
      top: 13,
      color: 'var(--text-muted)'
    }
  }), /*#__PURE__*/React.createElement("input", {
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "Buscar por paciente o diagn\xF3stico\u2026",
    style: {
      width: '100%',
      boxSizing: 'border-box',
      padding: '12px 16px 12px 40px',
      fontSize: 14,
      fontFamily: 'var(--font-sans)',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-xl)',
      outline: 'none',
      boxShadow: 'var(--shadow-sm)',
      color: 'var(--text-strong)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, filtered.map(r => /*#__PURE__*/React.createElement("button", {
    key: r.id,
    onClick: () => {
      setSel(r);
      setMode('detail');
    },
    className: "rx-card"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 44,
      height: 44,
      borderRadius: 'var(--radius-lg)',
      flex: 'none',
      background: 'var(--color-sky-50)',
      color: 'var(--brand-primary)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-heading)',
      fontSize: 22,
      fontWeight: 700
    }
  }, "\u211E"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      textAlign: 'left'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14.5,
      fontWeight: 600,
      color: 'var(--text-strong)'
    }
  }, r.patientName), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: 'var(--text-muted)',
      marginTop: 2,
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, r.diagnosis || 'Sin diagnóstico', " \xB7 ", r.medications.length, " medicamento", r.medications.length !== 1 ? 's' : '')), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-end',
      gap: 6,
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement(SBadge, {
    variant: r.status === 'firmada' ? 'success' : 'warning',
    dot: true,
    sm: true
  }, r.status === 'firmada' ? 'Firmada' : 'Borrador'), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)'
    }
  }, fmtDate(r.date))))))));
}
window.Recetas = Recetas;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/panel-clinico/recetas.jsx", error: String((e && e.message) || e) }); }

// ui_kits/panel-clinico/ui.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Icons + primitives for the staff panel. Self-contained; tokens from styles.css. */
const SIc = ({
  children,
  size = 18,
  sw = 1.75,
  ...p
}) => /*#__PURE__*/React.createElement("svg", _extends({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: sw,
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, p), children);
const CalDays = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("rect", {
  x: "3",
  y: "4",
  width: "18",
  height: "18",
  rx: "2"
}), /*#__PURE__*/React.createElement("path", {
  d: "M16 2v4M8 2v4M3 10h18M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01"
}));
const Clip = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("rect", {
  x: "8",
  y: "2",
  width: "8",
  height: "4",
  rx: "1"
}), /*#__PURE__*/React.createElement("path", {
  d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2M9 12h6M9 16h6"
}));
const Scroll = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M8 21h12a2 2 0 0 0 2-2v-2H10v2a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v3h4"
}), /*#__PURE__*/React.createElement("path", {
  d: "M19 17V5a2 2 0 0 0-2-2H6M13 8h4M13 12h4"
}));
const Shield = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"
}));
const Gear = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "3"
}), /*#__PURE__*/React.createElement("path", {
  d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"
}));
const Bag = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"
}), /*#__PURE__*/React.createElement("path", {
  d: "M3 6h18M16 10a4 4 0 0 1-8 0"
}));
const Box = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M21 8 12 3 3 8v8l9 5 9-5Z"
}), /*#__PURE__*/React.createElement("path", {
  d: "m3 8 9 5 9-5M12 13v8"
}));
const SSearch = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("circle", {
  cx: "11",
  cy: "11",
  r: "8"
}), /*#__PURE__*/React.createElement("path", {
  d: "m21 21-4.3-4.3"
}));
const SPlus = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M12 5v14M5 12h14"
}));
const SChevR = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "m9 18 6-6-6-6"
}));
const SCheck = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M20 6 9 17l-5-5"
}));
const SX = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M18 6 6 18M6 6l12 12"
}));
const Refresh = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5M21 12a9 9 0 0 1-15 6.7L3 16M3 21v-5h5"
}));
const SPhone = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z"
}));
const SMail = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("rect", {
  x: "2",
  y: "4",
  width: "20",
  height: "16",
  rx: "2"
}), /*#__PURE__*/React.createElement("path", {
  d: "m2 7 10 6 10-6"
}));
const SClock = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "10"
}), /*#__PURE__*/React.createElement("path", {
  d: "M12 6v6l4 2"
}));
const SUser = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "7",
  r: "4"
}));
const Steth2 = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M4 3v5a5 5 0 0 0 10 0V3"
}), /*#__PURE__*/React.createElement("path", {
  d: "M4 3H2m12 0h-2M9 18a4 4 0 0 0 8 0v-2"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "20",
  cy: "10",
  r: "2"
}));
const LogOut = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"
}));
const Menu2 = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M4 12h16M4 6h16M4 18h16"
}));
const Bell = p => /*#__PURE__*/React.createElement(SIc, p, /*#__PURE__*/React.createElement("path", {
  d: "M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.94 1.94 0 0 0 3.4 0"
}));
const STATUS = {
  pendiente: {
    variant: 'warning',
    label: 'Pendiente'
  },
  confirmada: {
    variant: 'info',
    label: 'Confirmada'
  },
  reprogramada: {
    variant: 'info',
    label: 'Reprogramada'
  },
  completada: {
    variant: 'success',
    label: 'Completada'
  },
  cancelada: {
    variant: 'danger',
    label: 'Cancelada'
  }
};
const TONES = {
  info: {
    bg: 'var(--state-info-bg)',
    fg: 'var(--state-info-fg)',
    dot: 'var(--color-sky-500)'
  },
  warning: {
    bg: 'var(--state-warning-bg)',
    fg: 'var(--state-warning-fg)',
    dot: 'var(--color-amber-400)'
  },
  success: {
    bg: 'var(--state-success-bg)',
    fg: 'var(--state-success-fg)',
    dot: 'var(--color-emerald-500)'
  },
  danger: {
    bg: 'var(--state-danger-bg)',
    fg: 'var(--state-danger-fg)',
    dot: 'var(--color-rose-400)'
  },
  neutral: {
    bg: 'var(--surface-sunken)',
    fg: 'var(--text-body)',
    dot: 'var(--color-slate-400)'
  }
};
function SBadge({
  variant = 'neutral',
  dot,
  sm,
  children
}) {
  const t = TONES[variant];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: sm ? 11 : 12,
      padding: sm ? '2px 8px' : '4px 10px',
      borderRadius: sm ? 'var(--radius-sm)' : 'var(--radius-full)',
      background: t.bg,
      color: t.fg,
      whiteSpace: 'nowrap'
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: t.dot
    }
  }), children);
}
function SAvatar({
  name = '',
  size = 40,
  variant = 'soft'
}) {
  const init = name.trim().split(/\s+/).slice(0, 2).map(n => n[0] || '').join('').toUpperCase();
  const v = {
    solid: ['var(--brand-primary)', '#fff'],
    soft: ['var(--color-sky-100)', 'var(--color-sky-700)'],
    neutral: ['var(--surface-sunken)', 'var(--text-muted)'],
    onPrimary: ['rgba(255,255,255,.2)', '#fff']
  }[variant];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      flex: 'none',
      borderRadius: size >= 52 ? 'var(--radius-2xl)' : '50%',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-heading)',
      fontWeight: 700,
      fontSize: size * 0.33,
      background: v[0],
      color: v[1]
    }
  }, init);
}
function SButton({
  children,
  variant = 'primary',
  size = 'md',
  icon: Icon,
  onClick
}) {
  const [h, setH] = React.useState(false);
  const pad = size === 'sm' ? '7px 12px' : '9px 16px';
  const sty = {
    primary: {
      background: h ? 'var(--brand-primary-hover)' : 'var(--brand-primary)',
      color: '#fff',
      border: '1px solid transparent',
      boxShadow: 'var(--shadow-sm)'
    },
    secondary: {
      background: h ? 'var(--surface-page)' : 'var(--surface-card)',
      color: 'var(--text-body)',
      border: '1px solid var(--border-default)'
    },
    danger: {
      background: h ? 'var(--color-rose-50)' : 'var(--surface-card)',
      color: 'var(--color-rose-600)',
      border: '1px solid var(--color-rose-200, #fecdd3)'
    }
  }[variant];
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 6,
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: 13,
      padding: pad,
      borderRadius: 'var(--radius-md)',
      cursor: 'pointer',
      whiteSpace: 'nowrap',
      transition: 'all .15s',
      ...sty
    }
  }, Icon && /*#__PURE__*/React.createElement(Icon, {
    size: 15,
    sw: 2.2
  }), children);
}
Object.assign(window, {
  SIc,
  CalDays,
  Clip,
  Scroll,
  Shield,
  Gear,
  Bag,
  Box,
  SSearch,
  SPlus,
  SChevR,
  SCheck,
  SX,
  Refresh,
  SPhone,
  SMail,
  SClock,
  SUser,
  Steth2,
  LogOut,
  Menu2,
  Bell,
  STATUS,
  TONES,
  SBadge,
  SAvatar,
  SButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/panel-clinico/ui.jsx", error: String((e && e.message) || e) }); }

// ui_kits/panel-clinico/views.jsx
try { (() => {
/* StaffShell + Agenda + Expedientes + Dashboard views. */

const NAV = [{
  id: 'dashboard',
  label: 'Dashboard',
  icon: 'Steth2'
}, {
  id: 'agenda',
  label: 'Agenda de Citas',
  icon: 'CalDays'
}, {
  id: 'ehr',
  label: 'Expediente Clínico',
  icon: 'Clip'
}, {
  id: 'recetas',
  label: 'Recetas',
  icon: 'Scroll'
}, {
  id: 'notas',
  label: 'Notas de Evolución',
  icon: 'Clip'
}, {
  id: 'tienda',
  label: 'Pedidos de Tienda',
  icon: 'Bag'
}, {
  id: 'productos',
  label: 'Productos',
  icon: 'Box'
}, {
  id: 'admin',
  label: 'Administración',
  icon: 'Shield'
}, {
  id: 'config',
  label: 'Configuración',
  icon: 'Gear'
}];
const ICONS = {
  Steth2,
  CalDays,
  Clip,
  Scroll,
  Bag,
  Box,
  Shield,
  Gear
};
function StaffShell({
  view,
  onView,
  children
}) {
  const u = window.STAFF_DATA.user;
  const init = u.name.split(' ').slice(0, 2).map(n => n[0]).join('').toUpperCase();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      display: 'flex',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 'var(--sidebar-w)',
      flex: 'none',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-card)',
      borderRight: '1px solid var(--border-default)'
    },
    className: "staff-aside"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 'var(--header-h)',
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '0 16px',
      borderBottom: '1px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 32,
      height: 32,
      borderRadius: 'var(--radius-md)',
      background: 'var(--brand-primary)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement(Steth2, {
    size: 17,
    sw: 1.9,
    style: {
      color: '#fff'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      lineHeight: 1.15,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      fontFamily: 'var(--font-heading)',
      color: 'var(--text-strong)'
    }
  }, "Dr. Viveros \xB7 ORL"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      fontWeight: 600,
      color: 'var(--brand-primary)',
      textTransform: 'uppercase',
      letterSpacing: '.08em'
    }
  }, "Panel Cl\xEDnico"))), /*#__PURE__*/React.createElement("nav", {
    style: {
      flex: 1,
      padding: '12px 8px',
      overflowY: 'auto'
    }
  }, /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, NAV.map(item => {
    const Icon = ICONS[item.icon],
      active = view === item.id;
    return /*#__PURE__*/React.createElement("li", {
      key: item.id
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => onView(item.id),
      className: 'nav-item' + (active ? ' active' : '')
    }, /*#__PURE__*/React.createElement(Icon, {
      size: 17,
      sw: active ? 2 : 1.75,
      style: {
        flex: 'none'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13.5,
        fontWeight: active ? 600 : 500
      }
    }, item.label)));
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border-default)',
      padding: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(SAvatar, {
    name: u.name,
    size: 36
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      lineHeight: 1.2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--text-strong)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, u.name), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      fontSize: 10,
      fontWeight: 600,
      padding: '1px 7px',
      borderRadius: 'var(--radius-full)',
      background: 'var(--color-sky-100)',
      color: 'var(--color-sky-700)',
      marginTop: 3
    }
  }, u.role))), /*#__PURE__*/React.createElement("button", {
    style: {
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginTop: 10,
      padding: '7px 8px',
      borderRadius: 'var(--radius-md)',
      cursor: 'pointer',
      background: 'transparent',
      border: 0,
      color: 'var(--text-muted)',
      fontSize: 12,
      fontFamily: 'var(--font-sans)'
    },
    onMouseEnter: e => {
      e.currentTarget.style.background = 'var(--color-rose-50)';
      e.currentTarget.style.color = 'var(--color-rose-600)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.background = 'transparent';
      e.currentTarget.style.color = 'var(--text-muted)';
    }
  }, /*#__PURE__*/React.createElement(LogOut, {
    size: 14
  }), "Cerrar sesi\xF3n"))), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, children));
}

/* ── Agenda ─────────────────────────────────────────────────────────────── */
function Agenda() {
  const apts = window.STAFF_DATA.appointments;
  const [selId, setSelId] = React.useState(apts[0].id);
  const [q, setQ] = React.useState('');
  const filtered = apts.filter(a => !q || a.name.toLowerCase().includes(q.toLowerCase()) || a.phone.includes(q));
  const groups = {};
  filtered.forEach(a => {
    (groups[a.day] = groups[a.day] || []).push(a);
  });
  const sel = apts.find(a => a.id === selId);
  const pending = apts.filter(a => a.status === 'pendiente').length;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: '100vh'
    }
  }, /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 440,
      flex: 'none',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-card)',
      borderRight: '1px solid var(--border-default)'
    },
    className: "agenda-list"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px 24px 16px',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 20,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: 0
    }
  }, "Agenda de Citas"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, "4 citas hoy"), pending > 0 && /*#__PURE__*/React.createElement(SBadge, {
    variant: "warning",
    dot: true,
    sm: true
  }, pending, " pendientes"))), /*#__PURE__*/React.createElement(SButton, {
    icon: SPlus,
    size: "sm"
  }, "Nueva")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement(SSearch, {
    size: 16,
    style: {
      position: 'absolute',
      left: 12,
      top: 11,
      color: 'var(--text-muted)'
    }
  }), /*#__PURE__*/React.createElement("input", {
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "Buscar paciente o tel\xE9fono\u2026",
    style: {
      width: '100%',
      boxSizing: 'border-box',
      padding: '10px 14px 10px 36px',
      fontSize: 13,
      fontFamily: 'var(--font-sans)',
      background: 'var(--surface-sunken)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-lg)',
      outline: 'none',
      color: 'var(--text-strong)'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '8px 0'
    }
  }, Object.entries(groups).map(([day, list]) => /*#__PURE__*/React.createElement("div", {
    key: day
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '8px 24px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '.1em',
      color: day.startsWith('Hoy') ? 'var(--brand-primary)' : 'var(--text-muted)'
    }
  }, day), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: 'var(--border-subtle)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-muted)'
    }
  }, list.length)), list.map(a => {
    const cfg = STATUS[a.status],
      on = a.id === selId;
    return /*#__PURE__*/React.createElement("button", {
      key: a.id,
      onClick: () => setSelId(a.id),
      className: 'agenda-row' + (on ? ' active' : '')
    }, on && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: 0,
        top: 8,
        bottom: 8,
        width: 3,
        borderRadius: '0 3px 3px 0',
        background: 'var(--color-sky-500)'
      }
    }), /*#__PURE__*/React.createElement(SAvatar, {
      name: a.name,
      size: 36,
      variant: on ? 'solid' : 'neutral'
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13.5,
        fontWeight: 600,
        color: on ? 'var(--color-sky-900)' : 'var(--text-strong)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, a.name), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        fontFamily: 'var(--font-mono)',
        color: 'var(--text-muted)',
        flex: 'none'
      }
    }, a.time)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: 'var(--text-body)',
        marginTop: 2,
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, a.service), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 8
      }
    }, /*#__PURE__*/React.createElement(SBadge, {
      variant: cfg.variant,
      dot: true,
      sm: true
    }, cfg.label))));
  }))))), /*#__PURE__*/React.createElement("section", {
    style: {
      flex: 1,
      minWidth: 0,
      overflowY: 'auto',
      background: 'var(--surface-card)'
    },
    className: "agenda-detail"
  }, sel && /*#__PURE__*/React.createElement(AptDetail, {
    apt: sel
  })));
}
function AptDetail({
  apt
}) {
  const cfg = STATUS[apt.status];
  const Row = ({
    icon: Icon,
    accent,
    label,
    value,
    mono
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 32,
      height: 32,
      borderRadius: 'var(--radius-md)',
      flex: 'none',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: accent ? 'var(--color-sky-50)' : 'var(--surface-sunken)',
      color: accent ? 'var(--brand-primary)' : 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    size: 15,
    sw: 1.6
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 600,
      textTransform: 'uppercase',
      letterSpacing: '.06em',
      color: 'var(--text-muted)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      fontWeight: 500,
      color: 'var(--text-strong)',
      fontFamily: mono ? 'var(--font-mono)' : 'inherit'
    }
  }, value)));
  const card = {
    background: 'var(--surface-page)',
    borderRadius: 'var(--radius-xl)',
    padding: 16,
    display: 'flex',
    flexDirection: 'column',
    gap: 14
  };
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--brand-primary)',
      padding: '24px 32px',
      display: 'flex',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(SAvatar, {
    name: apt.name,
    size: 56,
    variant: "onPrimary"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      color: '#fff',
      fontSize: 21,
      fontWeight: 600,
      fontFamily: 'var(--font-heading)',
      margin: 0
    }
  }, apt.name), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement(SBadge, {
    variant: cfg.variant,
    dot: true
  }, cfg.label)))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px 32px',
      maxWidth: 520,
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: card
  }, /*#__PURE__*/React.createElement(Row, {
    icon: CalDays,
    accent: true,
    label: "Fecha",
    value: apt.day
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--border-default)'
    }
  }), /*#__PURE__*/React.createElement(Row, {
    icon: SClock,
    accent: true,
    label: "Hora",
    value: `${apt.time} hrs`,
    mono: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--border-default)'
    }
  }), /*#__PURE__*/React.createElement(Row, {
    icon: SUser,
    accent: true,
    label: "Servicio",
    value: apt.service
  })), /*#__PURE__*/React.createElement("div", {
    style: card
  }, /*#__PURE__*/React.createElement(Row, {
    icon: SPhone,
    label: "Tel\xE9fono",
    value: apt.phone,
    mono: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--border-default)'
    }
  }), /*#__PURE__*/React.createElement(Row, {
    icon: SMail,
    label: "Correo",
    value: apt.email
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-page)',
      borderRadius: 'var(--radius-xl)',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 600,
      textTransform: 'uppercase',
      letterSpacing: '.06em',
      color: 'var(--text-muted)',
      marginBottom: 8
    }
  }, "Motivo de consulta"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 13.5,
      color: 'var(--text-body)',
      lineHeight: 1.6
    }
  }, apt.reason)), apt.status === 'pendiente' ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(SButton, {
    icon: SCheck
  }, "Confirmar")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(SButton, {
    variant: "danger",
    icon: SX
  }, "Rechazar"))) : apt.status === 'cancelada' ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      padding: 14,
      borderRadius: 'var(--radius-lg)',
      background: 'var(--color-rose-50)',
      color: 'var(--color-rose-600)',
      fontSize: 13,
      fontWeight: 500
    }
  }, /*#__PURE__*/React.createElement(SX, {
    size: 15
  }), "Esta cita fue cancelada") : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(SButton, {
    variant: "secondary",
    icon: Refresh
  }, "Reprogramar"), /*#__PURE__*/React.createElement(SButton, {
    variant: "danger",
    icon: SX
  }, "Cancelar"))));
}

/* ── Expedientes ────────────────────────────────────────────────────────── */
function Expedientes() {
  const pts = window.STAFF_DATA.patients;
  const [q, setQ] = React.useState('');
  const list = pts.filter(p => !q || p.name.toLowerCase().includes(q.toLowerCase()) || p.exp.toLowerCase().includes(q.toLowerCase()));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      overflowY: 'auto',
      height: '100vh'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 760,
      margin: '0 auto',
      padding: '32px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 16,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 24,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: 0
    }
  }, "Expedientes"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, pts.length, " pacientes registrados"), /*#__PURE__*/React.createElement(SBadge, {
    variant: "info",
    dot: true,
    sm: true
  }, "M\xE9dico"))), /*#__PURE__*/React.createElement(SButton, {
    icon: SPlus
  }, "Nuevo paciente")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(SSearch, {
    size: 16,
    style: {
      position: 'absolute',
      left: 14,
      top: 13,
      color: 'var(--text-muted)'
    }
  }), /*#__PURE__*/React.createElement("input", {
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "Buscar por nombre o n\xFAmero de expediente\u2026",
    style: {
      width: '100%',
      boxSizing: 'border-box',
      padding: '12px 16px 12px 40px',
      fontSize: 14,
      fontFamily: 'var(--font-sans)',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-xl)',
      outline: 'none',
      boxShadow: 'var(--shadow-sm)',
      color: 'var(--text-strong)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-xl)',
      border: '1px solid var(--border-default)',
      boxShadow: 'var(--shadow-sm)',
      overflow: 'hidden'
    }
  }, list.map((p, i) => /*#__PURE__*/React.createElement("button", {
    key: p.exp,
    className: "exp-row",
    style: {
      borderBottom: i < list.length - 1 ? '1px solid var(--border-subtle)' : 0
    }
  }, /*#__PURE__*/React.createElement(SAvatar, {
    name: p.name,
    size: 40
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--text-strong)'
    }
  }, p.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-muted)'
    }
  }, p.exp)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, p.age, " a\xF1os \xB7 ", p.sex)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)'
    },
    className: "exp-updated"
  }, p.updated), /*#__PURE__*/React.createElement(SChevR, {
    size: 16,
    style: {
      color: 'var(--border-strong)'
    }
  }))))));
}

/* ── Dashboard ──────────────────────────────────────────────────────────── */
function Dashboard() {
  const d = window.STAFF_DATA.dashboard;
  const max = Math.max(...d.week.map(w => w.v));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      overflowY: 'auto',
      height: '100vh'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 980,
      margin: '0 auto',
      padding: '32px 24px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 24,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '0 0 4px'
    }
  }, "Buenos d\xEDas, Dr. Viveros"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: 'var(--text-muted)',
      margin: '0 0 24px'
    }
  }, "Lunes 9 de junio \xB7 4 citas programadas para hoy"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 16,
      marginBottom: 24
    },
    className: "dash-stats"
  }, d.stats.map(s => {
    const t = TONES[s.tone];
    return /*#__PURE__*/React.createElement("div", {
      key: s.label,
      style: {
        background: 'var(--surface-card)',
        border: '1px solid var(--border-default)',
        borderRadius: 'var(--radius-xl)',
        padding: 20,
        boxShadow: 'var(--shadow-sm)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        fontWeight: 600,
        textTransform: 'uppercase',
        letterSpacing: '.05em',
        color: 'var(--text-muted)'
      }
    }, s.label), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 30,
        fontWeight: 700,
        fontFamily: 'var(--font-heading)',
        color: 'var(--text-strong)',
        margin: '6px 0 8px'
      }
    }, s.value), /*#__PURE__*/React.createElement(SBadge, {
      variant: s.tone,
      sm: true
    }, s.delta));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.5fr 1fr',
      gap: 16
    },
    className: "dash-row"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-xl)',
      padding: 24,
      boxShadow: 'var(--shadow-sm)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 16,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: 0
    }
  }, "Citas por d\xEDa"), /*#__PURE__*/React.createElement(SBadge, {
    variant: "neutral",
    sm: true
  }, "Esta semana")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 16,
      height: 160
    }
  }, d.week.map(w => /*#__PURE__*/React.createElement("div", {
    key: w.d,
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 8,
      height: '100%',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-muted)'
    }
  }, w.v), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 40,
      height: `${Math.max(4, w.v / max * 130)}px`,
      borderRadius: '6px 6px 0 0',
      background: w.v === max ? 'var(--brand-primary)' : 'var(--color-sky-200)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)'
    }
  }, w.d))))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-xl)',
      padding: 24,
      boxShadow: 'var(--shadow-sm)'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 16,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '0 0 16px'
    }
  }, "Pr\xF3ximas citas"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, window.STAFF_DATA.appointments.slice(0, 4).map(a => /*#__PURE__*/React.createElement("div", {
    key: a.id,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(SAvatar, {
    name: a.name,
    size: 34
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--text-strong)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, a.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11.5,
      color: 'var(--text-muted)'
    }
  }, a.service)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-body)'
    }
  }, a.time))))))));
}
function Placeholder({
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 12,
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Box, {
    size: 40,
    sw: 1.2
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14
    }
  }, label, " \u2014 vista no incluida en este UI kit"));
}
Object.assign(window, {
  StaffShell,
  Agenda,
  Expedientes,
  Dashboard,
  Placeholder
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/panel-clinico/views.jsx", error: String((e && e.message) || e) }); }

// ui_kits/sitio-publico/agendar.jsx
try { (() => {
/* Agendar — 3-step appointment booking (servicio → fecha/hora → datos → listo). */

function Stepper({
  step
}) {
  const steps = ['Servicio', 'Fecha y hora', 'Tus datos'];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 32
    }
  }, steps.map((s, i) => {
    const done = i < step,
      active = i === step;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: s
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 28,
        height: 28,
        borderRadius: '50%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 13,
        fontWeight: 700,
        fontFamily: 'var(--font-mono)',
        background: done ? 'var(--brand-primary)' : active ? 'var(--color-sky-50)' : 'var(--surface-sunken)',
        color: done ? '#fff' : active ? 'var(--brand-primary)' : 'var(--text-muted)',
        border: active ? '1.5px solid var(--brand-primary)' : '1.5px solid transparent'
      }
    }, done ? /*#__PURE__*/React.createElement(Check, {
      size: 15
    }) : i + 1), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        fontWeight: active ? 600 : 500,
        color: active || done ? 'var(--text-strong)' : 'var(--text-muted)'
      },
      className: "step-label"
    }, s)), i < steps.length - 1 && /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1.5,
        background: done ? 'var(--brand-primary)' : 'var(--border-default)',
        minWidth: 16
      }
    }));
  }));
}
function Field({
  label,
  value,
  onChange,
  placeholder,
  type = 'text',
  required
}) {
  const [f, setF] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 500,
      color: 'var(--text-strong)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--color-rose-600)'
    }
  }, " *")), /*#__PURE__*/React.createElement("input", {
    type: type,
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value),
    onFocus: () => setF(true),
    onBlur: () => setF(false),
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      color: 'var(--text-strong)',
      background: 'var(--surface-card)',
      border: `1px solid ${f ? 'var(--border-focus)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-lg)',
      padding: '11px 14px',
      outline: 'none',
      boxShadow: f ? '0 0 0 3px rgb(14 165 233 / .18)' : 'none',
      transition: 'all .15s'
    }
  }));
}
function AgendarPage({
  onNav
}) {
  const [step, setStep] = React.useState(0);
  const [svc, setSvc] = React.useState(null);
  const [date, setDate] = React.useState(null);
  const [time, setTime] = React.useState(null);
  const [form, setForm] = React.useState({
    name: '',
    phone: '',
    email: '',
    reason: ''
  });
  const services = window.OTORRINO_DATA.services;
  const days = [{
    d: 'Lun',
    n: '9',
    m: 'jun'
  }, {
    d: 'Mar',
    n: '10',
    m: 'jun'
  }, {
    d: 'Mié',
    n: '11',
    m: 'jun'
  }, {
    d: 'Jue',
    n: '12',
    m: 'jun'
  }, {
    d: 'Vie',
    n: '13',
    m: 'jun'
  }];
  const times = ['10:00', '10:30', '11:00', '16:00', '16:30', '17:00', '17:30', '18:00'];
  const card = {
    background: 'var(--surface-card)',
    border: '1px solid var(--border-default)',
    borderRadius: 'var(--radius-2xl)',
    padding: 32,
    boxShadow: 'var(--shadow-sm)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-page)',
      minHeight: '70vh',
      padding: '48px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Cita en l\xEDnea"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 32,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '10px 0 0'
    }
  }, "Agenda tu consulta")), step < 3 && /*#__PURE__*/React.createElement(Stepper, {
    step: step
  }), step === 0 && /*#__PURE__*/React.createElement("div", {
    style: card
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 17,
      margin: '0 0 16px',
      color: 'var(--text-strong)'
    }
  }, "\xBFQu\xE9 servicio necesitas?"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12
    }
  }, services.map(s => {
    const Icon = SERVICE_ICONS[s.icon] || Stethoscope,
      sel = svc === s.id;
    return /*#__PURE__*/React.createElement("button", {
      key: s.id,
      onClick: () => setSvc(s.id),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        textAlign: 'left',
        padding: 14,
        borderRadius: 'var(--radius-lg)',
        cursor: 'pointer',
        background: sel ? 'var(--color-sky-50)' : 'var(--surface-card)',
        border: `1.5px solid ${sel ? 'var(--brand-primary)' : 'var(--border-default)'}`,
        transition: 'all .15s'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 38,
        height: 38,
        borderRadius: 'var(--radius-md)',
        flex: 'none',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: sel ? 'var(--brand-primary)' : 'var(--color-sky-50)',
        color: sel ? '#fff' : 'var(--brand-primary)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      size: 18
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        fontWeight: 600,
        color: 'var(--text-strong)'
      }
    }, s.name));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement(Button, {
    onClick: () => svc && setStep(1),
    iconR: ChevronR
  }, "Continuar"))), step === 1 && /*#__PURE__*/React.createElement("div", {
    style: card
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 17,
      margin: '0 0 16px',
      color: 'var(--text-strong)'
    }
  }, "Elige fecha y hora"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '.08em',
      color: 'var(--text-muted)',
      margin: '0 0 10px'
    }
  }, "Junio 2026"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginBottom: 24
    }
  }, days.map(dy => {
    const sel = date === dy.n;
    return /*#__PURE__*/React.createElement("button", {
      key: dy.n,
      onClick: () => setDate(dy.n),
      style: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 4,
        padding: '12px 0',
        borderRadius: 'var(--radius-lg)',
        cursor: 'pointer',
        background: sel ? 'var(--brand-primary)' : 'var(--surface-card)',
        border: `1.5px solid ${sel ? 'var(--brand-primary)' : 'var(--border-default)'}`,
        transition: 'all .15s'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: 600,
        color: sel ? 'rgba(255,255,255,.8)' : 'var(--text-muted)'
      }
    }, dy.d), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 18,
        fontWeight: 700,
        fontFamily: 'var(--font-heading)',
        color: sel ? '#fff' : 'var(--text-strong)'
      }
    }, dy.n));
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '.08em',
      color: 'var(--text-muted)',
      margin: '0 0 10px'
    }
  }, "Horarios disponibles"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 10
    }
  }, times.map(t => {
    const sel = time === t;
    return /*#__PURE__*/React.createElement("button", {
      key: t,
      onClick: () => setTime(t),
      style: {
        padding: '10px 0',
        borderRadius: 'var(--radius-lg)',
        cursor: 'pointer',
        fontSize: 13,
        fontWeight: 600,
        fontFamily: 'var(--font-mono)',
        background: sel ? 'var(--color-sky-50)' : 'var(--surface-card)',
        color: sel ? 'var(--brand-primary)' : 'var(--text-body)',
        border: `1.5px solid ${sel ? 'var(--brand-primary)' : 'var(--border-default)'}`,
        transition: 'all .15s'
      }
    }, t);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => setStep(0)
  }, "Atr\xE1s"), /*#__PURE__*/React.createElement(Button, {
    onClick: () => date && time && setStep(2),
    iconR: ChevronR
  }, "Continuar"))), step === 2 && /*#__PURE__*/React.createElement("div", {
    style: card
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 17,
      margin: '0 0 16px',
      color: 'var(--text-strong)'
    }
  }, "Tus datos de contacto"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Nombre completo",
    required: true,
    value: form.name,
    onChange: v => setForm({
      ...form,
      name: v
    }),
    placeholder: "Tu nombre"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Tel\xE9fono",
    required: true,
    type: "tel",
    value: form.phone,
    onChange: v => setForm({
      ...form,
      phone: v
    }),
    placeholder: "55 1234 5678"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Correo",
    type: "email",
    value: form.email,
    onChange: v => setForm({
      ...form,
      email: v
    }),
    placeholder: "tu@correo.com"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Motivo de consulta",
    value: form.reason,
    onChange: v => setForm({
      ...form,
      reason: v
    }),
    placeholder: "Describe brevemente tu padecimiento"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => setStep(1)
  }, "Atr\xE1s"), /*#__PURE__*/React.createElement(Button, {
    onClick: () => form.name && form.phone && setStep(3),
    icon: Check
  }, "Confirmar cita"))), step === 3 && /*#__PURE__*/React.createElement("div", {
    style: {
      ...card,
      textAlign: 'center',
      padding: 44
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 64,
      height: 64,
      borderRadius: '50%',
      background: 'var(--color-emerald-50)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--color-emerald-500)',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Check, {
    size: 32
  })), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 24,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '0 0 8px'
    }
  }, "\xA1Cita solicitada!"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-body)',
      fontSize: 14,
      lineHeight: 1.6,
      maxWidth: 380,
      margin: '0 auto 24px'
    }
  }, "Recibimos tu solicitud para el ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)'
    }
  }, date, " de junio a las ", time, " hrs"), ". Te enviaremos la confirmaci\xF3n por correo y WhatsApp."), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-page)',
      borderRadius: 'var(--radius-xl)',
      padding: 20,
      textAlign: 'left',
      maxWidth: 380,
      margin: '0 auto 24px'
    }
  }, [['Paciente', form.name || '—'], ['Servicio', (services.find(s => s.id === svc) || {}).name || '—'], ['Fecha', `${date} jun · ${time} hrs`]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      padding: '7px 0',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      color: 'var(--text-strong)'
    }
  }, v)))), /*#__PURE__*/React.createElement(Button, {
    onClick: () => onNav('inicio')
  }, "Volver al inicio"))));
}
window.AgendarPage = AgendarPage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/sitio-publico/agendar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/sitio-publico/contacto.jsx
try { (() => {
/* Página de Contacto */

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = 'text',
  required
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'block',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--text-strong)',
      marginBottom: 6
    }
  }, label), /*#__PURE__*/React.createElement("input", {
    type: type,
    value: value,
    onChange: e => onChange(e.target.value),
    placeholder: placeholder,
    required: required,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      padding: '10px 14px',
      borderRadius: 'var(--radius-lg)',
      border: `1px solid ${focus ? 'var(--brand-primary)' : 'var(--border-default)'}`,
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      color: 'var(--text-body)',
      background: 'var(--surface-input)',
      boxSizing: 'border-box',
      outline: 'none',
      transition: 'border-color .15s'
    }
  }));
}
function ContactoPage({
  onNav
}) {
  const c = window.OTORRINO_DATA.contact;
  const [form, setForm] = React.useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [sent, setSent] = React.useState(false);
  const [focusTa, setFocusTa] = React.useState(false);
  const handleSubmit = e => {
    e.preventDefault();
    setSent(true);
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-subtle)',
      padding: '56px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Escr\xEDbenos"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 40,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '12px 0 0',
      lineHeight: 1.08
    }
  }, "Contacto"))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '64px 0',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px',
      display: 'grid',
      gridTemplateColumns: '1fr 1.3fr',
      gap: 64
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 36
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 22,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '0 0 24px'
    }
  }, "Informaci\xF3n del consultorio"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 'var(--radius-lg)',
      background: 'var(--color-sky-50)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: 'none',
      color: 'var(--brand-primary)'
    }
  }, /*#__PURE__*/React.createElement(MapPin, {
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 3px',
      fontWeight: 600,
      fontSize: 14,
      color: 'var(--text-strong)'
    }
  }, "Direcci\xF3n"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      color: 'var(--text-body)',
      lineHeight: 1.55
    }
  }, c.address, /*#__PURE__*/React.createElement("br", null), c.city))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 'var(--radius-lg)',
      background: 'var(--color-sky-50)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: 'none',
      color: 'var(--brand-primary)'
    }
  }, /*#__PURE__*/React.createElement(Clock, {
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 10px',
      fontWeight: 600,
      fontSize: 14,
      color: 'var(--text-strong)'
    }
  }, "Horario de atenci\xF3n"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 7
    }
  }, c.schedule.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 16,
      fontSize: 13.5,
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("span", null, s.days), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12.5,
      fontWeight: 600,
      color: s.hours === 'Cerrado' ? 'var(--text-muted)' : 'var(--text-strong)'
    }
  }, s.hours)))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 24px',
      background: 'var(--color-sky-50)',
      borderRadius: 'var(--radius-xl)',
      border: '1px solid var(--color-sky-100)'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 14px',
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--color-sky-700)'
    }
  }, "\xBFPrefieres agendar directamente?"), /*#__PURE__*/React.createElement(Button, {
    icon: Calendar,
    onClick: () => onNav('agendar')
  }, "Agendar Cita en l\xEDnea")), /*#__PURE__*/React.createElement("button", {
    onClick: () => onNav('ubicacion'),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: 'var(--brand-primary)',
      fontFamily: 'var(--font-sans)',
      fontSize: 13.5,
      fontWeight: 600,
      padding: 0,
      width: 'fit-content'
    }
  }, /*#__PURE__*/React.createElement(MapPin, {
    size: 15
  }), "Ver c\xF3mo llegar al consultorio", /*#__PURE__*/React.createElement(ArrowUR, {
    size: 14
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-2xl)',
      padding: 40,
      border: '1px solid var(--border-subtle)',
      boxShadow: 'var(--shadow-sm)'
    }
  }, sent ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '40px 20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: '50%',
      background: 'var(--color-sky-50)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      margin: '0 auto 20px',
      color: 'var(--brand-primary)'
    }
  }, /*#__PURE__*/React.createElement(Check, {
    size: 24
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 22,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '0 0 12px'
    }
  }, "Mensaje enviado"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-body)',
      fontSize: 14.5,
      lineHeight: 1.65,
      margin: '0 0 24px'
    }
  }, "Nos pondremos en contacto contigo a la brevedad posible."), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => {
      setForm({
        name: '',
        email: '',
        phone: '',
        message: ''
      });
      setSent(false);
    }
  }, "Enviar otro mensaje")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 22,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '0 0 28px'
    }
  }, "Env\xEDanos un mensaje"), /*#__PURE__*/React.createElement("form", {
    onSubmit: handleSubmit,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Nombre completo",
    value: form.name,
    onChange: v => setForm(f => ({
      ...f,
      name: v
    })),
    placeholder: "Tu nombre",
    required: true
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Tel\xE9fono",
    value: form.phone,
    onChange: v => setForm(f => ({
      ...f,
      phone: v
    })),
    placeholder: "55 1234 5678"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Correo electr\xF3nico",
    value: form.email,
    onChange: v => setForm(f => ({
      ...f,
      email: v
    })),
    placeholder: "correo@ejemplo.com",
    type: "email",
    required: true
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'block',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--text-strong)',
      marginBottom: 6
    }
  }, "Mensaje"), /*#__PURE__*/React.createElement("textarea", {
    value: form.message,
    onChange: e => setForm(f => ({
      ...f,
      message: e.target.value
    })),
    onFocus: () => setFocusTa(true),
    onBlur: () => setFocusTa(false),
    placeholder: "Cu\xE9ntanos en qu\xE9 podemos ayudarte...",
    required: true,
    style: {
      width: '100%',
      minHeight: 110,
      padding: '10px 14px',
      borderRadius: 'var(--radius-lg)',
      border: `1px solid ${focusTa ? 'var(--brand-primary)' : 'var(--border-default)'}`,
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      color: 'var(--text-body)',
      background: 'var(--surface-input)',
      resize: 'vertical',
      boxSizing: 'border-box',
      outline: 'none',
      transition: 'border-color .15s'
    }
  })), /*#__PURE__*/React.createElement(Button, null, "Enviar mensaje")))))));
}
Object.assign(window, {
  ContactoPage,
  Field
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/sitio-publico/contacto.jsx", error: String((e && e.message) || e) }); }

// ui_kits/sitio-publico/data.js
try { (() => {
/* Real content for the Dr. Viveros public site — lifted from the product's
   sitio-publico-data.ts so the kit reads like the live site. */
window.OTORRINO_DATA = {
  doctor: {
    fullName: 'Dr. Alejandro Viveros Domínguez',
    title: 'Médico Otorrinolaringólogo',
    licenseNumber: '6277305',
    yearsOfExperience: 10,
    photo: '../../assets/dr-viveros-perfil.jpg',
    tagline: 'Especialista en Otorrinolaringología y Cirugía de Cabeza y Cuello. Atención humana, ética y de alta calidad con las técnicas más modernas y menos invasivas.',
    certifications: ['Sociedad Mexicana de Otorrinolaringología y CCC', 'Médico adscrito al IMSS desde 2016']
  },
  services: [{
    id: 'consulta',
    name: 'Consulta ORL General',
    icon: 'stethoscope'
  }, {
    id: 'audiologia',
    name: 'Audiología',
    icon: 'ear'
  }, {
    id: 'vacunacion',
    name: 'Vacunación',
    icon: 'syringe'
  }, {
    id: 'rinitis',
    name: 'Rinitis Alérgica e Inmunoterapia',
    icon: 'allergen'
  }, {
    id: 'cirugia',
    name: 'Cirugía ORL',
    icon: 'surgery'
  }, {
    id: 'vertigo',
    name: 'Vértigo y Equilibrio',
    icon: 'balance'
  }],
  reviews: [{
    name: 'Mónica Bautista',
    rating: 5,
    text: 'Urgentemente necesitaba un otorrino y lo encontré por Google Maps. Lo recomiendo ampliamente. Muy amable, considerado, me explicó la causa de mi dolencia y nada abusivo en pedir estudios. Calidad humana de doctor.'
  }, {
    name: 'Yazmín García',
    rating: 5,
    text: 'Ha sido una experiencia increíble, servicio y atención de primera. Gracias a la atención oportuna varios de mis padecimientos han desaparecido. Agradezco su profesionalismo y calidad humana.'
  }, {
    name: 'Karen Sandoval',
    rating: 5,
    text: 'Un excelente doctor. Atendió a mi mamá con mucho profesionalismo, muy amable y explicó todo detalladamente. Le agradezco mucho su atención. Lo recomiendo totalmente.'
  }, {
    name: 'Alejandra Vázquez',
    rating: 5,
    text: 'Extraordinaria intervención, muy valiosa la visión sistémica del Doctor Alejandro Viveros, gran atención. Altamente recomendable.'
  }, {
    name: 'Consuelo Domínguez',
    rating: 5,
    text: 'Muy buen doctor. Llevé a mi hijo y el diagnóstico muy acertado; el doctor muy paciente y muy amable.'
  }, {
    name: 'Mijo León',
    rating: 5,
    text: 'Excelente doctor, muy buena atención, súper profesional. Estoy muy agradecido por sus atenciones como médico. Muy recomendable.'
  }],
  rating: {
    average: 5.0,
    total: 6
  },
  contact: {
    address: 'Chosica 730, Col. Lindavista',
    city: 'Gustavo A. Madero, CDMX · 07300',
    schedule: [{
      days: 'Lunes a Miércoles',
      hours: '16:00 – 20:00'
    }, {
      days: 'Jueves y Viernes',
      hours: '10:00 – 14:00'
    }, {
      days: 'Sábado y Domingo',
      hours: 'Cerrado'
    }]
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/sitio-publico/data.js", error: String((e && e.message) || e) }); }

// ui_kits/sitio-publico/home.jsx
try { (() => {
/* Public homepage sections for Dr. Viveros — Header, Hero, Services, Reviews,
   Tienda band, bottom CTA, Footer. */

function PublicHeader({
  onNav,
  page
}) {
  const links = [['inicio', 'Inicio'], ['perfil', 'Perfil'], ['servicios', 'Servicios'], ['tienda', 'Tienda'], ['ubicacion', 'Ubicación'], ['contacto', 'Contacto']];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 50,
      background: 'rgba(255,255,255,.95)',
      backdropFilter: 'blur(8px)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px',
      height: 'var(--header-h)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: () => onNav('inicio'),
    style: {
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-otorrinonet-transparent.svg",
    alt: "Dr. Alejandro Viveros Dom\xEDnguez",
    style: {
      height: 46,
      width: 'auto'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 28
    },
    className: "nav-links"
  }, links.map(([id, label]) => {
    const active = page === id;
    return /*#__PURE__*/React.createElement("a", {
      key: id,
      onClick: () => onNav(id),
      style: {
        cursor: 'pointer',
        fontSize: 14,
        fontWeight: 500,
        color: active ? 'var(--brand-primary)' : 'var(--text-body)',
        transition: 'color .12s'
      }
    }, label);
  }), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    icon: Calendar,
    onClick: () => onNav('agendar')
  }, "Agendar Cita"))));
}
function Hero({
  onNav
}) {
  const d = window.OTORRINO_DATA.doctor,
    r = window.OTORRINO_DATA.rating;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      background: 'var(--surface-card)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "hero-diag",
    style: {
      position: 'absolute',
      top: 0,
      right: 0,
      height: '100%',
      width: '55%',
      background: 'linear-gradient(to bottom left, var(--color-sky-600), var(--color-sky-700))',
      clipPath: 'polygon(18% 0%, 100% 0%, 100% 100%, 0% 100%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '72px 24px',
      display: 'grid',
      gridTemplateColumns: '1.1fr 0.9fr',
      gap: 56,
      alignItems: 'center'
    },
    className: "hero-grid"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      background: 'var(--color-sky-50)',
      color: 'var(--color-sky-700)',
      fontSize: 12,
      fontWeight: 700,
      padding: '6px 12px',
      borderRadius: 'var(--radius-full)',
      width: 'fit-content',
      border: '1px solid var(--color-sky-100)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--color-sky-500)',
      animation: 'ds-pulse 1.6s ease-in-out infinite'
    }
  }), d.yearsOfExperience, "+ a\xF1os de experiencia"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 46,
      fontWeight: 700,
      color: 'var(--text-strong)',
      lineHeight: 1.08,
      letterSpacing: '-.02em',
      margin: 0
    }
  }, d.fullName), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 18,
      color: 'var(--brand-primary)',
      fontWeight: 600,
      marginTop: 8
    }
  }, d.title)), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-body)',
      lineHeight: 1.65,
      fontSize: 15,
      maxWidth: 420,
      margin: 0
    }
  }, d.tagline), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(Button, {
    icon: Calendar,
    onClick: () => onNav('agendar')
  }, "Agendar Cita"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    iconR: ChevronR,
    onClick: () => onNav('perfil')
  }, "Ver perfil completo")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8,
      paddingTop: 4
    }
  }, d.certifications.map((c, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      fontSize: 11,
      background: 'var(--surface-sunken)',
      color: 'var(--text-body)',
      padding: '5px 10px',
      borderRadius: 'var(--radius-full)',
      fontWeight: 500
    }
  }, c)))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: 300,
      height: 380
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 'var(--radius-2xl)',
      overflow: 'hidden',
      boxShadow: 'var(--shadow-2xl)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: d.photo,
    alt: d.fullName,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      objectPosition: 'center top'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: -16,
      left: -20,
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-xl)',
      boxShadow: 'var(--shadow-xl)',
      padding: 12,
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      border: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 36,
      height: 36,
      borderRadius: 'var(--radius-lg)',
      background: 'var(--color-amber-50)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Star, {
    size: 16,
    fill: "var(--color-amber-400)"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      lineHeight: 1.2
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      fontWeight: 700,
      color: 'var(--text-strong)'
    }
  }, r.average, " / 5"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 10,
      color: 'var(--text-muted)'
    }
  }, r.total, " rese\xF1as \xB7 Google"))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: -12,
      right: -16,
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-xl)',
      boxShadow: 'var(--shadow-xl)',
      padding: '10px 14px',
      border: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 10,
      fontWeight: 700,
      color: 'var(--brand-primary)',
      textTransform: 'uppercase',
      letterSpacing: '.08em'
    }
  }, "C\xE9dula Prof."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 13,
      fontWeight: 700,
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-strong)'
    }
  }, d.licenseNumber))))));
}
function ServiceTile({
  name,
  icon,
  onClick
}) {
  const [h, setH] = React.useState(false);
  const Icon = SERVICE_ICONS[icon] || Stethoscope;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
      gap: 12,
      padding: 20,
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-xl)',
      cursor: 'default',
      border: `1px solid ${h ? 'var(--color-sky-200)' : 'var(--border-subtle)'}`,
      boxShadow: h ? 'var(--shadow-lg)' : 'none',
      transition: 'all .3s var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 48,
      height: 48,
      borderRadius: 'var(--radius-lg)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: h ? 'var(--color-sky-100)' : 'var(--color-sky-50)',
      color: 'var(--brand-primary)',
      transition: 'background .3s'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12.5,
      fontWeight: 600,
      color: 'var(--text-strong)',
      lineHeight: 1.25
    }
  }, name));
}
function Services({
  onNav
}) {
  const s = window.OTORRINO_DATA.services;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '80px 0',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 24,
      marginBottom: 44
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Especialidades"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 34,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '12px 0 0'
    }
  }, "Nuestros Servicios"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-muted)',
      marginTop: 12,
      maxWidth: 420,
      fontSize: 14,
      lineHeight: 1.6
    }
  }, "Atenci\xF3n integral en otorrinolaringolog\xEDa con tecnolog\xEDa de vanguardia para todas las edades.")), /*#__PURE__*/React.createElement("a", {
    onClick: () => onNav('servicios'),
    style: {
      cursor: 'pointer',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      color: 'var(--brand-primary)',
      fontWeight: 600,
      fontSize: 14,
      whiteSpace: 'nowrap'
    }
  }, "Ver todos los servicios ", /*#__PURE__*/React.createElement(ArrowUR, {
    size: 16
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(6, 1fr)',
      gap: 16
    },
    className: "svc-grid"
  }, s.map(x => /*#__PURE__*/React.createElement(ServiceTile, {
    key: x.id,
    name: x.name,
    icon: x.icon,
    onClick: () => onNav('servicios')
  })))));
}
function Reviews() {
  const rv = window.OTORRINO_DATA.reviews,
    sum = window.OTORRINO_DATA.rating;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '80px 0',
      background: 'var(--surface-card)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 24,
      marginBottom: 44
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Rese\xF1as verificadas"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 34,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '12px 0 0',
      lineHeight: 1.1
    }
  }, "Lo que dicen", /*#__PURE__*/React.createElement("br", null), "nuestros pacientes")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 12,
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-xl)',
      padding: '12px 20px',
      boxShadow: 'var(--shadow-sm)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 26,
      fontWeight: 700,
      color: 'var(--text-strong)',
      fontFamily: 'var(--font-heading)'
    }
  }, sum.average), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, "/5")), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)'
    }
  }, sum.total, " rese\xF1as")), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      height: 32,
      background: 'var(--border-default)'
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(StarRow, {
    size: 13
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      color: 'var(--text-muted)',
      textTransform: 'uppercase',
      letterSpacing: '.06em',
      marginTop: 4
    }
  }, "Google")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 16
    },
    className: "rev-grid"
  }, rv.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      padding: 24,
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-xl)',
      boxShadow: 'var(--shadow-sm)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: r.name,
    solid: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--text-strong)'
    }
  }, r.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(StarRow, {
    rating: r.rating
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: 'var(--text-muted)'
    }
  }, "Google")))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      color: 'var(--text-body)',
      lineHeight: 1.65
    }
  }, r.text))))));
}
function TiendaBand({
  onNav
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '72px 0',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-2xl)',
      padding: 40,
      display: 'flex',
      alignItems: 'center',
      gap: 40,
      boxShadow: 'var(--shadow-sm)'
    },
    className: "tienda-band"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 64,
      height: 64,
      background: 'var(--color-sky-50)',
      borderRadius: 'var(--radius-xl)',
      flex: 'none',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--brand-primary)'
    }
  }, /*#__PURE__*/React.createElement(Shop, {
    size: 30
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Tienda en l\xEDnea"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 26,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '8px 0 8px'
    }
  }, "Productos recomendados por el Dr. Viveros"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--text-body)',
      lineHeight: 1.6,
      maxWidth: 560,
      fontSize: 14.5
    }
  }, "Dispositivos m\xE9dicos, suplementos y paquetes de consulta seleccionados por el especialista. Entrega en consultorio o env\xEDo a domicilio.")), /*#__PURE__*/React.createElement(Button, {
    iconR: ArrowUR,
    onClick: () => onNav('tienda')
  }, "Ver productos"))));
}
function BottomCTA({
  onNav
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      background: 'var(--color-sky-600)',
      padding: '72px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      opacity: .2,
      backgroundImage: 'radial-gradient(circle, rgba(255,255,255,.5) 1px, transparent 1px)',
      backgroundSize: '28px 28px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 620,
      margin: '0 auto',
      textAlign: 'center',
      padding: '0 24px'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    light: true
  }, "Agenda tu consulta"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 36,
      fontWeight: 700,
      color: '#fff',
      margin: '16px 0 16px',
      lineHeight: 1.1
    }
  }, "\xBFListo para sentirte", /*#__PURE__*/React.createElement("br", null), "mejor?"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--color-sky-100)',
      fontSize: 15,
      lineHeight: 1.65,
      marginBottom: 28
    }
  }, "Primera consulta disponible esta semana. Atenci\xF3n especializada en el coraz\xF3n de la Ciudad de M\xE9xico."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      justifyContent: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "onPrimary",
    icon: Calendar,
    onClick: () => onNav('agendar')
  }, "Agendar Cita Ahora"), /*#__PURE__*/React.createElement(Button, {
    variant: "outlineLight",
    icon: Phone
  }, "Llamar al consultorio"))));
}
function PublicFooter() {
  const c = window.OTORRINO_DATA.contact;
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--color-slate-900)',
      color: 'var(--color-slate-400)',
      padding: '48px 0 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px',
      display: 'grid',
      gridTemplateColumns: '1.4fr 1fr 1fr',
      gap: 40
    },
    className: "footer-grid"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-otorrinonet-white.svg",
    alt: "Logo",
    style: {
      height: 56,
      width: 'auto',
      opacity: .95
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      lineHeight: 1.65,
      marginTop: 16,
      maxWidth: 320
    }
  }, "Otorrinolaringolog\xEDa y Cirug\xEDa de Cabeza y Cuello. Atenci\xF3n humana, \xE9tica y de alta calidad en CDMX.")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      color: '#fff',
      fontWeight: 600,
      fontSize: 13,
      marginBottom: 12
    }
  }, "Consultorio"), /*#__PURE__*/React.createElement("p", {
    style: {
      display: 'flex',
      gap: 8,
      fontSize: 13,
      lineHeight: 1.5,
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement(MapPin, {
    size: 16,
    style: {
      flex: 'none',
      marginTop: 1,
      color: 'var(--color-sky-400)'
    }
  }), /*#__PURE__*/React.createElement("span", null, c.address, /*#__PURE__*/React.createElement("br", null), c.city))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      color: '#fff',
      fontWeight: 600,
      fontSize: 13,
      marginBottom: 12
    }
  }, "Horario"), c.schedule.map((s, i) => /*#__PURE__*/React.createElement("p", {
    key: i,
    style: {
      fontSize: 13,
      marginBottom: 8,
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", null, s.days), /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#fff',
      fontFamily: 'var(--font-mono)',
      fontSize: 12
    }
  }, s.hours))))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '32px auto 0',
      padding: '20px 24px 0',
      borderTop: '1px solid var(--color-slate-800)',
      fontSize: 12
    }
  }, "\xA9 2026 Dr. Alejandro Viveros Dom\xEDnguez \xB7 C\xE9dula Prof. 6277305 \xB7 Hecho con OtorrinoNet"));
}
function HomePage({
  onNav
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Hero, {
    onNav: onNav
  }), /*#__PURE__*/React.createElement(Services, {
    onNav: onNav
  }), /*#__PURE__*/React.createElement(Reviews, null), /*#__PURE__*/React.createElement(TiendaBand, {
    onNav: onNav
  }), /*#__PURE__*/React.createElement(BottomCTA, {
    onNav: onNav
  }));
}
Object.assign(window, {
  PublicHeader,
  PublicFooter,
  HomePage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/sitio-publico/home.jsx", error: String((e && e.message) || e) }); }

// ui_kits/sitio-publico/perfil.jsx
try { (() => {
/* Página de Perfil completo — Dr. Alejandro Viveros Domínguez */

const education = [{
  year: '2008 – 2014',
  degree: 'Médico Cirujano',
  institution: 'Universidad Nacional Autónoma de México',
  detail: 'Facultad de Medicina, UNAM'
}, {
  year: '2015 – 2019',
  degree: 'Especialidad en Otorrinolaringología y CCC',
  institution: 'Hospital de Especialidades CMN Siglo XXI — IMSS',
  detail: 'Residencia médica certificada'
}, {
  year: '2019 – actual',
  degree: 'Médico Adscrito en ORL',
  institution: 'Instituto Mexicano del Seguro Social',
  detail: 'Atención institucional y consulta privada'
}];
const certRows = ['Sociedad Mexicana de Otorrinolaringología y Cirugía de Cabeza y Cuello', 'Consejo Mexicano de Otorrinolaringología y CCC', 'Médico adscrito al IMSS desde 2016', 'Cédula profesional 6277305 — SEP'];
const stats = [{
  value: '10+',
  label: 'Años de experiencia'
}, {
  value: '5.0★',
  label: 'Calificación Google'
}, {
  value: 'IMSS',
  label: 'Médico adscrito'
}, {
  value: 'UNAM',
  label: 'Formación médica'
}];
function PerfilPage({
  onNav
}) {
  const d = window.OTORRINO_DATA.doctor;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-subtle)',
      padding: '72px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px',
      display: 'grid',
      gridTemplateColumns: '1fr 320px',
      gap: 64,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "M\xE9dico Especialista"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 42,
      fontWeight: 700,
      color: 'var(--text-strong)',
      lineHeight: 1.08,
      letterSpacing: '-.02em',
      margin: 0
    }
  }, d.fullName), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      color: 'var(--brand-primary)',
      fontWeight: 600,
      margin: '10px 0 0'
    }
  }, d.title)), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-body)',
      lineHeight: 1.7,
      fontSize: 15.5,
      maxWidth: 560,
      margin: 0
    }
  }, "Con m\xE1s de ", d.yearsOfExperience, " a\xF1os de trayectoria, el Dr. Viveros combina el rigor acad\xE9mico de su formaci\xF3n en la UNAM y el IMSS con un trato humano y personalizado. Atiende a pacientes de todas las edades con las t\xE9cnicas m\xE1s modernas y menos invasivas disponibles en M\xE9xico."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, d.certifications.map((c, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      fontSize: 11,
      background: 'var(--surface-sunken)',
      color: 'var(--text-body)',
      padding: '5px 11px',
      borderRadius: 'var(--radius-full)',
      fontWeight: 500
    }
  }, c))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(Button, {
    icon: Calendar,
    onClick: () => onNav('agendar')
  }, "Agendar Cita"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: Phone,
    onClick: () => onNav('contacto')
  }, "Contactar"))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 'var(--radius-2xl)',
      overflow: 'hidden',
      boxShadow: 'var(--shadow-2xl)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: d.photo,
    alt: d.fullName,
    style: {
      width: '100%',
      aspectRatio: '3/4',
      objectFit: 'cover',
      objectPosition: 'center top',
      display: 'block'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: -16,
      right: -16,
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-xl)',
      boxShadow: 'var(--shadow-xl)',
      padding: '12px 16px',
      border: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 10,
      fontWeight: 700,
      color: 'var(--brand-primary)',
      textTransform: 'uppercase',
      letterSpacing: '.08em'
    }
  }, "C\xE9dula Prof."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      fontWeight: 700,
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-strong)'
    }
  }, d.licenseNumber))))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--color-sky-600)',
      padding: '44px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px',
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)'
    }
  }, stats.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      textAlign: 'center',
      padding: '12px 20px',
      borderRight: i < stats.length - 1 ? '1px solid rgba(255,255,255,.2)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 34,
      fontWeight: 700,
      color: '#fff',
      lineHeight: 1
    }
  }, s.value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--color-sky-100)',
      marginTop: 6,
      fontWeight: 500
    }
  }, s.label))))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '80px 0',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px',
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 72
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Trayectoria"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 28,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '12px 0 36px'
    }
  }, "Formaci\xF3n Acad\xE9mica"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, education.map((e, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 20,
      paddingBottom: i < education.length - 1 ? 36 : 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 10,
      height: 10,
      borderRadius: '50%',
      background: 'var(--brand-primary)',
      flex: 'none',
      marginTop: 5
    }
  }), i < education.length - 1 && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 2,
      flex: 1,
      background: 'var(--border-default)',
      marginTop: 6
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: 'var(--brand-primary)',
      fontFamily: 'var(--font-mono)'
    }
  }, e.year), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '4px 0 2px',
      fontSize: 15,
      fontWeight: 600,
      color: 'var(--text-strong)'
    }
  }, e.degree), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 13.5,
      color: 'var(--text-body)'
    }
  }, e.institution), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '2px 0 0',
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, e.detail)))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Membres\xEDas"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 28,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '12px 0 36px'
    }
  }, "Certificaciones y Sociedades"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, certRows.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'flex-start',
      padding: '16px 20px',
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-lg)',
      border: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 24,
      height: 24,
      borderRadius: 'var(--radius-md)',
      background: 'var(--color-sky-50)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: 'none',
      color: 'var(--brand-primary)'
    }
  }, /*#__PURE__*/React.createElement(Check, {
    size: 13
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--text-body)',
      lineHeight: 1.5
    }
  }, m))))))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '72px 0',
      background: 'var(--surface-card)',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 560,
      margin: '0 auto',
      padding: '0 24px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Primera consulta disponible esta semana"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 30,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '12px 0 16px'
    }
  }, "\xBFListo para una consulta?"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-body)',
      fontSize: 15,
      lineHeight: 1.65,
      marginBottom: 28
    }
  }, "Agenda en l\xEDnea o cont\xE1ctanos para m\xE1s informaci\xF3n."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      justifyContent: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    icon: Calendar,
    onClick: () => onNav('agendar')
  }, "Agendar en l\xEDnea"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    iconR: ArrowUR,
    onClick: () => onNav('servicios')
  }, "Ver servicios")))));
}
Object.assign(window, {
  PerfilPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/sitio-publico/perfil.jsx", error: String((e && e.message) || e) }); }

// ui_kits/sitio-publico/servicios.jsx
try { (() => {
/* Página de Servicios detallados */

const SERVICES_DETAIL = [{
  id: 'consulta',
  name: 'Consulta ORL General',
  icon: 'stethoscope',
  description: 'Evaluación integral de oídos, nariz y garganta. Diagnóstico de infecciones, alergias, problemas de audición y vías respiratorias superiores en pacientes de todas las edades.',
  includes: ['Historia clínica completa', 'Exploración física ORL', 'Diagnóstico y plan de tratamiento', 'Seguimiento post-consulta']
}, {
  id: 'audiologia',
  name: 'Audiología',
  icon: 'ear',
  description: 'Evaluación completa de la función auditiva mediante estudios especializados. Diagnóstico y manejo de hipoacusia, tinnitus, otitis y otros padecimientos del oído.',
  includes: ['Audiometría tonal y vocal', 'Timpanometría', 'Potenciales evocados auditivos', 'Orientación en auxiliares auditivos']
}, {
  id: 'vacunacion',
  name: 'Vacunación',
  icon: 'syringe',
  description: 'Aplicación de vacunas preventivas para adultos y niños con esquemas personalizados según historial médico y factores de riesgo individual.',
  includes: ['Influenza estacional', 'Neumococo', 'VPH y otras vacunas', 'Esquemas de refuerzo']
}, {
  id: 'rinitis',
  name: 'Rinitis Alérgica e Inmunoterapia',
  icon: 'allergen',
  description: 'Diagnóstico y tratamiento de alergias respiratorias con inmunoterapia sublingual o subcutánea para reducir la sensibilidad a los alérgenos y mejorar la calidad de vida.',
  includes: ['Identificación de alérgenos', 'Pruebas cutáneas', 'Inmunoterapia personalizada', 'Seguimiento y ajuste de dosis']
}, {
  id: 'cirugia',
  name: 'Cirugía ORL',
  icon: 'surgery',
  description: 'Procedimientos quirúrgicos de mínima invasión para nariz, garganta y oídos. Técnicas modernas que reducen el tiempo de recuperación y las molestias postoperatorias.',
  includes: ['Septoplastia y turbinoplastia', 'Amigdalectomía y adenoidectomía', 'Cirugía endoscópica nasosinusal', 'Timpanoplastia']
}, {
  id: 'vertigo',
  name: 'Vértigo y Equilibrio',
  icon: 'balance',
  description: 'Evaluación y tratamiento del vértigo posicional benigno, enfermedad de Ménière y otros trastornos del sistema vestibular que afectan el equilibrio y la calidad de vida.',
  includes: ['Videonistagmografía', 'Maniobras de reposición canalicular', 'Rehabilitación vestibular', 'Tratamiento farmacológico']
}];
function ServiceCard({
  service
}) {
  const [open, setOpen] = React.useState(false);
  const Icon = SERVICE_ICONS[service.icon] || Stethoscope;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-2xl)',
      border: '1px solid var(--border-subtle)',
      overflow: 'hidden',
      boxShadow: 'var(--shadow-sm)',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '32px 32px 24px',
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 52,
      height: 52,
      borderRadius: 'var(--radius-xl)',
      background: 'var(--color-sky-50)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--brand-primary)',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    size: 22
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 20,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '0 0 12px',
      lineHeight: 1.2
    }
  }, service.name), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-body)',
      fontSize: 14,
      lineHeight: 1.7,
      margin: 0
    }
  }, service.description)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 32px 28px'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(!open),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: 'var(--brand-primary)',
      fontFamily: 'var(--font-sans)',
      fontSize: 13.5,
      fontWeight: 600,
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("span", null, open ? 'Ocultar' : 'Ver', " qu\xE9 incluye"), /*#__PURE__*/React.createElement(ChevronR, {
    size: 14,
    style: {
      transform: open ? 'rotate(90deg)' : 'none',
      transition: 'transform .2s'
    }
  })), open && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      padding: '16px',
      background: 'var(--surface-sunken)',
      borderRadius: 'var(--radius-lg)'
    }
  }, service.includes.map((item, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: '50%',
      background: 'var(--color-sky-100)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: 'none',
      color: 'var(--brand-primary)'
    }
  }, /*#__PURE__*/React.createElement(Check, {
    size: 11
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13.5,
      color: 'var(--text-body)'
    }
  }, item))))));
}
function ServiciosPage({
  onNav
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'linear-gradient(135deg, var(--color-sky-700) 0%, var(--color-sky-600) 100%)',
      padding: '72px 0 80px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    light: true
  }, "Especialidades"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 42,
      fontWeight: 700,
      color: '#fff',
      margin: '16px 0 20px',
      lineHeight: 1.08
    }
  }, "Nuestros Servicios"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--color-sky-100)',
      fontSize: 16,
      lineHeight: 1.65,
      maxWidth: 500,
      margin: '0 auto 32px'
    }
  }, "Atenci\xF3n integral en otorrinolaringolog\xEDa con tecnolog\xEDa de vanguardia para todas las edades."), /*#__PURE__*/React.createElement(Button, {
    variant: "onPrimary",
    icon: Calendar,
    onClick: () => onNav('agendar')
  }, "Agendar Cita"))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '80px 0',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 24
    }
  }, SERVICES_DETAIL.map(s => /*#__PURE__*/React.createElement(ServiceCard, {
    key: s.id,
    service: s
  }))))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '72px 0',
      background: 'var(--surface-card)',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 560,
      margin: '0 auto',
      padding: '0 24px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "\xBFTienes dudas?"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 30,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '12px 0 16px'
    }
  }, "Agenda tu consulta"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-body)',
      fontSize: 15,
      lineHeight: 1.65,
      marginBottom: 28
    }
  }, "Primera consulta disponible esta semana. Llama o agenda en l\xEDnea."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      justifyContent: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    icon: Calendar,
    onClick: () => onNav('agendar')
  }, "Agendar en l\xEDnea"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: Phone,
    onClick: () => onNav('contacto')
  }, "Ver contacto")))));
}
Object.assign(window, {
  ServiciosPage,
  SERVICES_DETAIL,
  ServiceCard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/sitio-publico/servicios.jsx", error: String((e && e.message) || e) }); }

// ui_kits/sitio-publico/ubicacion.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Página de Ubicación — cómo llegar al consultorio */

const TrainIc = p => /*#__PURE__*/React.createElement("svg", _extends({
  width: "18",
  height: "18",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.75",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, p), /*#__PURE__*/React.createElement("rect", {
  x: "4",
  y: "3",
  width: "16",
  height: "16",
  rx: "3"
}), /*#__PURE__*/React.createElement("path", {
  d: "M4 11h16M12 3v8M8 19l-2 2M16 19l2 2M8 15h.01M16 15h.01"
}));
const BusIc = p => /*#__PURE__*/React.createElement("svg", _extends({
  width: "18",
  height: "18",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.75",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, p), /*#__PURE__*/React.createElement("path", {
  d: "M8 6v6M15 6v6M2 12h19.6M18 18h2M4 18H2M18 18a2 2 0 1 1-4 0M8 18a2 2 0 1 1-4 0"
}), /*#__PURE__*/React.createElement("path", {
  d: "M1 18V6a5 5 0 0 1 5-5h12a5 5 0 0 1 5 5v12"
}));
const CarIc = p => /*#__PURE__*/React.createElement("svg", _extends({
  width: "18",
  height: "18",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.75",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, p), /*#__PURE__*/React.createElement("path", {
  d: "M5 17H3v-7l2-5h14l2 5v7h-2M5 17a2 2 0 1 0 4 0 2 2 0 0 0-4 0M15 17a2 2 0 1 0 4 0 2 2 0 0 0-4 0"
}), /*#__PURE__*/React.createElement("path", {
  d: "M5 10h14"
}));
const howToArrive = [{
  Icon: TrainIc,
  label: 'Metro',
  detail: 'Línea 6 — Estación Lindavista, 5 min caminando hacia el norte por Av. Montevideo.'
}, {
  Icon: BusIc,
  label: 'Metrobús',
  detail: 'Línea 6 — Parada Lindavista Sur, 7 min caminando. Baja en dirección a Chosica.'
}, {
  Icon: CarIc,
  label: 'Auto',
  detail: 'Acceso por Av. Montevideo o Insurgentes Norte. Estacionamiento en calle disponible en Chosica y calles aledañas.'
}];
function UbicacionPage({
  onNav
}) {
  const c = window.OTORRINO_DATA.contact;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-subtle)',
      padding: '56px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "C\xF3mo llegar"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 40,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '12px 0 0',
      lineHeight: 1.08
    }
  }, "Ubicaci\xF3n"))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '64px 0',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px',
      display: 'grid',
      gridTemplateColumns: '360px 1fr',
      gap: 48,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 18,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '0 0 14px'
    }
  }, "Direcci\xF3n"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(MapPin, {
    size: 18,
    style: {
      color: 'var(--brand-primary)',
      flex: 'none',
      marginTop: 2
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 15,
      color: 'var(--text-body)',
      lineHeight: 1.6
    }
  }, c.address, /*#__PURE__*/React.createElement("br", null), c.city))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 18,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '0 0 14px'
    }
  }, "Horario"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 0
    }
  }, c.schedule.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 16,
      fontSize: 14,
      color: 'var(--text-body)',
      padding: '10px 0',
      borderBottom: i < c.schedule.length - 1 ? '1px solid var(--border-subtle)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("span", null, s.days), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12.5,
      fontWeight: 600,
      color: s.hours === 'Cerrado' ? 'var(--text-muted)' : 'var(--text-strong)'
    }
  }, s.hours))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 18,
      fontWeight: 700,
      color: 'var(--text-strong)',
      margin: '0 0 14px'
    }
  }, "C\xF3mo llegar"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, howToArrive.map(({
    Icon,
    label,
    detail
  }, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 14,
      padding: '14px 16px',
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-lg)',
      border: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 36,
      height: 36,
      borderRadius: 'var(--radius-md)',
      background: 'var(--color-sky-50)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: 'none',
      color: 'var(--brand-primary)'
    }
  }, /*#__PURE__*/React.createElement(Icon, null)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 3px',
      fontWeight: 600,
      fontSize: 13.5,
      color: 'var(--text-strong)'
    }
  }, label), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 13,
      color: 'var(--text-body)',
      lineHeight: 1.5
    }
  }, detail)))))), /*#__PURE__*/React.createElement(Button, {
    icon: Calendar,
    onClick: () => onNav('agendar')
  }, "Agendar Cita")), /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 'var(--radius-2xl)',
      overflow: 'hidden',
      boxShadow: 'var(--shadow-lg)',
      border: '1px solid var(--border-subtle)',
      height: 520,
      background: 'var(--surface-sunken)'
    }
  }, /*#__PURE__*/React.createElement("iframe", {
    title: "Consultorio Dr. Viveros \u2014 Chosica 730 Lindavista CDMX",
    src: "https://maps.google.com/maps?q=Chosica+730+Lindavista+Gustavo+A+Madero+CDMX&output=embed&z=16",
    width: "100%",
    height: "100%",
    style: {
      border: 'none',
      display: 'block'
    },
    allowFullScreen: true,
    loading: "lazy",
    referrerPolicy: "no-referrer-when-downgrade"
  })))));
}
Object.assign(window, {
  UbicacionPage,
  TrainIc,
  BusIc,
  CarIc
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/sitio-publico/ubicacion.jsx", error: String((e && e.message) || e) }); }

// ui_kits/sitio-publico/ui.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Lucide-style icons + brand UI primitives for the Dr. Viveros public site.
   Self-contained (no external bundle); styled with the design-system tokens
   linked via styles.css. */

const Ic = ({
  children,
  size = 20,
  sw = 1.75,
  ...p
}) => /*#__PURE__*/React.createElement("svg", _extends({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: sw,
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, p), children);
const Calendar = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("rect", {
  x: "3",
  y: "4",
  width: "18",
  height: "18",
  rx: "2"
}), /*#__PURE__*/React.createElement("path", {
  d: "M16 2v4M8 2v4M3 10h18"
}));
const ChevronR = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "m9 18 6-6-6-6"
}));
const ArrowUR = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "M7 17 17 7M7 7h10v10"
}));
const Star = ({
  size = 14,
  fill = 'none',
  ...p
}) => /*#__PURE__*/React.createElement("svg", _extends({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: fill,
  stroke: fill === 'none' ? 'currentColor' : 'none',
  strokeWidth: "1.5"
}, p), /*#__PURE__*/React.createElement("path", {
  d: "M12 2l2.9 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l7.1-1.01L12 2z"
}));
const MapPin = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "10",
  r: "3"
}));
const Clock = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "10"
}), /*#__PURE__*/React.createElement("path", {
  d: "M12 6v6l4 2"
}));
const Phone = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z"
}));
const Shop = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"
}), /*#__PURE__*/React.createElement("path", {
  d: "M3 6h18M16 10a4 4 0 0 1-8 0"
}));
const Menu = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "M4 12h16M4 6h16M4 18h16"
}));
const Check = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "M20 6 9 17l-5-5"
}));
const Stethoscope = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "M4 3v5a5 5 0 0 0 10 0V3"
}), /*#__PURE__*/React.createElement("path", {
  d: "M4 3H2m12 0h-2M9 18a4 4 0 0 0 8 0v-2"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "20",
  cy: "10",
  r: "2"
}));
const Ear = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "M6 8.5a6.5 6.5 0 1 1 13 0c0 2.5-1.5 3.5-2.5 4.5s-1.5 2-1.5 3.5a3 3 0 0 1-6 0"
}), /*#__PURE__*/React.createElement("path", {
  d: "M9 8.5a3 3 0 0 1 5 2"
}));
const Syringe = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "m18 2 4 4M17 7 8.5 15.5M5 11l8 8M9 7l8 8M7 14l-4 4-1 1m6-3-3 3"
}));
const Flower = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "3"
}), /*#__PURE__*/React.createElement("path", {
  d: "M12 9V2M12 22v-7M15 12h7M2 12h7M19 5l-5 5M5 19l5-5M19 19l-5-5M5 5l5 5"
}));
const Scissors = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("circle", {
  cx: "6",
  cy: "6",
  r: "3"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "6",
  cy: "18",
  r: "3"
}), /*#__PURE__*/React.createElement("path", {
  d: "M20 4 8.12 15.88M14.47 14.48 20 20M8.12 8.12 12 12"
}));
const Activity = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "M22 12h-4l-3 9L9 3l-3 9H2"
}));
const SERVICE_ICONS = {
  stethoscope: Stethoscope,
  ear: Ear,
  syringe: Syringe,
  allergen: Flower,
  surgery: Scissors,
  balance: Activity
};

/* ── Primitives ─────────────────────────────────────────────────────────── */
function Eyebrow({
  children,
  light
}) {
  return /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '.12em',
      color: light ? 'var(--color-sky-200)' : 'var(--brand-primary)',
      margin: 0
    }
  }, children);
}
function Button({
  children,
  variant = 'primary',
  size = 'md',
  icon: Icon,
  iconR: IconR,
  onClick,
  href,
  light
}) {
  const [h, setH] = React.useState(false),
    [a, setA] = React.useState(false);
  const sizes = {
    sm: '8px 14px',
    md: '12px 22px',
    lg: '15px 26px'
  };
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    fontFamily: 'var(--font-sans)',
    fontWeight: 600,
    fontSize: size === 'lg' ? 15 : 14,
    borderRadius: 'var(--radius-lg)',
    padding: sizes[size],
    cursor: 'pointer',
    border: '1px solid transparent',
    textDecoration: 'none',
    whiteSpace: 'nowrap',
    transform: a ? 'scale(.98)' : 'none',
    transition: 'all .15s var(--ease-standard)'
  };
  const styles = {
    primary: {
      ...base,
      background: h ? 'var(--brand-primary-hover)' : 'var(--brand-primary)',
      color: '#fff',
      boxShadow: h ? 'var(--shadow-primary)' : 'none'
    },
    secondary: {
      ...base,
      background: h ? 'var(--brand-accent-soft)' : 'var(--surface-card)',
      color: h ? 'var(--brand-primary-hover)' : 'var(--text-body)',
      borderColor: h ? 'var(--color-sky-300)' : 'var(--border-default)'
    },
    onPrimary: {
      ...base,
      background: h ? 'var(--color-sky-50)' : '#fff',
      color: 'var(--color-sky-700)',
      boxShadow: h ? 'var(--shadow-xl)' : 'none'
    },
    outlineLight: {
      ...base,
      background: h ? 'rgba(3,105,161,.5)' : 'transparent',
      color: '#fff',
      borderColor: 'rgba(56,189,248,.6)',
      borderWidth: 2
    }
  };
  const El = href ? 'a' : 'button';
  return /*#__PURE__*/React.createElement(El, {
    href: href,
    onClick: onClick,
    style: styles[variant],
    onMouseEnter: () => setH(true),
    onMouseLeave: () => {
      setH(false);
      setA(false);
    },
    onMouseDown: () => setA(true),
    onMouseUp: () => setA(false)
  }, Icon && /*#__PURE__*/React.createElement(Icon, {
    size: size === 'lg' ? 18 : 16
  }), children, IconR && /*#__PURE__*/React.createElement(IconR, {
    size: 16
  }));
}
function StarRow({
  rating = 5,
  size = 14
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 2
    }
  }, [0, 1, 2, 3, 4].map(i => /*#__PURE__*/React.createElement(Star, {
    key: i,
    size: size,
    fill: i < rating ? 'var(--color-amber-400)' : 'var(--color-slate-200)'
  })));
}
function Avatar({
  name = '',
  solid,
  size = 40
}) {
  const init = name.trim().split(/\s+/).slice(0, 2).map(n => n[0] || '').join('').toUpperCase();
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      flex: 'none',
      borderRadius: '50%',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-heading)',
      fontWeight: 700,
      fontSize: size * 0.32,
      background: solid ? 'var(--brand-primary)' : 'var(--color-sky-100)',
      color: solid ? '#fff' : 'var(--color-sky-700)'
    }
  }, init);
}
Object.assign(window, {
  Ic,
  Calendar,
  ChevronR,
  ArrowUR,
  Star,
  MapPin,
  Clock,
  Phone,
  Shop,
  Menu,
  Check,
  Stethoscope,
  Ear,
  Syringe,
  Flower,
  Scissors,
  Activity,
  SERVICE_ICONS,
  Eyebrow,
  Button,
  StarRow,
  Avatar
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/sitio-publico/ui.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.AppointmentRow = __ds_scope.AppointmentRow;

__ds_ns.ReviewCard = __ds_scope.ReviewCard;

__ds_ns.ServiceCard = __ds_scope.ServiceCard;

__ds_ns.Breadcrumbs = __ds_scope.Breadcrumbs;

__ds_ns.ContactCard = __ds_scope.ContactCard;

__ds_ns.DoctorCard = __ds_scope.DoctorCard;

__ds_ns.PublicHeader = __ds_scope.PublicHeader;

__ds_ns.RatingSummary = __ds_scope.RatingSummary;

})();
