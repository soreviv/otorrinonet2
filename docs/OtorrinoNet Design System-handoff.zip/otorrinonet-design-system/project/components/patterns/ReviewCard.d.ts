import * as React from 'react'

/**
 * Patient testimonial card — avatar, name, star rating, source and a clamped
 * quote. Used in the homepage reviews grid.
 */
export interface ReviewCardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Reviewer name. */
  authorName: string
  /** Star rating 1–5. @default 5 */
  rating?: number
  /** Review body. */
  text: string
  /** Source label. @default 'Google' */
  source?: string
}

export function ReviewCard(props: ReviewCardProps): React.JSX.Element
