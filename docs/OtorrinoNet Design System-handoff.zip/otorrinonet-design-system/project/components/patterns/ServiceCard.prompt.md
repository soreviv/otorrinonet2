Compact specialty tile — a sky icon chip over a short label, with a hover lift. Lay several in a grid for the homepage services section.

```jsx
<ServiceCard name="Audiología" icon={<Ear size={20} />} />
<ServiceCard name="Vacunación" icon={<Syringe size={20} />} href="/vacunacion" />
```

Pass a lucide icon (~20px) as `icon`. Optional `href` makes the whole tile a link.
