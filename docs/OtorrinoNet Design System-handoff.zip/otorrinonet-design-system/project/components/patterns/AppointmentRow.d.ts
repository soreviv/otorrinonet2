import * as React from 'react'

export type AppointmentStatus =
  | 'pendiente' | 'confirmada' | 'reprogramada' | 'completada' | 'cancelada'

/**
 * Appointment list row for the staff agenda — avatar, name, time, service and
 * a status badge, with a selectable state.
 */
export interface AppointmentRowProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Patient full name. */
  patientName: string
  /** Time string, e.g. "16:30". */
  time: string
  /** Service / reason label. */
  serviceName: string
  /** Status — drives the badge colour. @default 'pendiente' */
  status?: AppointmentStatus
  /** Highlight as the selected row. */
  selected?: boolean
}

export function AppointmentRow(props: AppointmentRowProps): React.JSX.Element
