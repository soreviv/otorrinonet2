Appointment list row for the staff agenda — avatar, patient name, mono time, service and a status badge; supports a selected state with a sky rail.

```jsx
<AppointmentRow
  patientName="Yazmín García"
  time="16:30"
  serviceName="Consulta ORL General"
  status="confirmada"
  selected
  onClick={() => select(apt.id)}
/>
```

`status`: `pendiente` / `confirmada` / `reprogramada` / `completada` / `cancelada`. Composes `Avatar` and `Badge`.
