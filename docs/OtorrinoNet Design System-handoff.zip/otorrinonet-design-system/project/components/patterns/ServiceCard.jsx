import React from 'react'

const CSS = `
.dsf-service{
  display:flex;flex-direction:column;align-items:center;text-align:center;gap:12px;
  padding:var(--space-5);background:var(--surface-card);
  border:1px solid var(--border-subtle);border-radius:var(--radius-xl);
  font-family:var(--font-sans);text-decoration:none;color:inherit;
  transition:border-color var(--duration-slow) var(--ease-standard),
    box-shadow var(--duration-slow) var(--ease-standard);
}
.dsf-service:hover{border-color:var(--color-sky-200);box-shadow:var(--shadow-lg);}
.dsf-service__icon{
  width:48px;height:48px;border-radius:var(--radius-lg);
  display:flex;align-items:center;justify-content:center;
  background:var(--color-sky-50);color:var(--brand-primary);
  transition:background var(--duration-slow) var(--ease-standard);
}
.dsf-service:hover .dsf-service__icon{background:var(--color-sky-100);}
.dsf-service__name{font-size:var(--text-xs);font-weight:var(--font-weight-semibold);
  color:var(--text-strong);line-height:var(--leading-snug);}
`
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-service-css')) return
    const s = document.createElement('style')
    s.id = 'dsf-service-css'; s.textContent = CSS; document.head.appendChild(s)
  }, [])
}

/**
 * Compact specialty tile — icon chip over a short label. Laid out in a
 * responsive grid on the homepage ("Nuestros Servicios").
 */
export function ServiceCard({ name, icon = null, href, className = '', ...rest }) {
  useStyles()
  const cls = `dsf-service ${className}`.trim()
  const inner = (
    <>
      <span className="dsf-service__icon">{icon}</span>
      <span className="dsf-service__name">{name}</span>
    </>
  )
  if (href) return <a href={href} className={cls} {...rest}>{inner}</a>
  return <div className={cls} {...rest}>{inner}</div>
}
