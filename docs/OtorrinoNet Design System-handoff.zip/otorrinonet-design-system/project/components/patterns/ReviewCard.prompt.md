Patient testimonial card — avatar, name, amber star row, source tag and a 4-line clamped quote. Lay several in a grid for social proof.

```jsx
<ReviewCard
  authorName="Mónica Bautista"
  rating={5}
  source="Google"
  text="Lo recomiendo ampliamente. Muy amable y me explicó la causa de mi dolencia…"
/>
```

Stars fill to `rating` (default 5). Composes the `Avatar` primitive internally.
