import React from 'react'
import { Avatar } from '../core/Avatar.jsx'

const CSS = `
.dsf-review{
  display:flex;flex-direction:column;gap:16px;padding:var(--space-6);
  background:var(--surface-card);border:1px solid var(--border-subtle);
  border-radius:var(--radius-xl);box-shadow:var(--shadow-sm);
  font-family:var(--font-sans);
  transition:box-shadow var(--duration-medium) var(--ease-standard),
    border-color var(--duration-medium) var(--ease-standard);
}
.dsf-review:hover{box-shadow:var(--shadow-md);border-color:var(--border-default);}
.dsf-review__head{display:flex;align-items:flex-start;gap:12px;}
.dsf-review__id{flex:1;min-width:0;}
.dsf-review__name{font-size:var(--text-sm);font-weight:var(--font-weight-semibold);
  color:var(--text-strong);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.dsf-review__sub{display:flex;align-items:center;gap:8px;margin-top:4px;}
.dsf-review__src{font-size:10px;color:var(--text-muted);font-weight:var(--font-weight-medium);}
.dsf-review__stars{display:flex;gap:2px;}
.dsf-review__quote{color:var(--color-sky-200);flex:none;}
.dsf-review__text{font-size:var(--text-sm);color:var(--text-body);
  line-height:var(--leading-relaxed);
  display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden;}
`
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-review-css')) return
    const s = document.createElement('style')
    s.id = 'dsf-review-css'; s.textContent = CSS; document.head.appendChild(s)
  }, [])
}

function Star({ filled }) {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill={filled ? 'var(--color-amber-400)' : 'var(--color-slate-200)'}>
      <path d="M12 2l2.9 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l7.1-1.01L12 2z" />
    </svg>
  )
}

/**
 * Patient testimonial card — initials avatar, name, star row, source and a
 * clamped quote. Mirrors the verified-Google-reviews grid on the homepage.
 */
export function ReviewCard({
  authorName,
  rating = 5,
  text,
  source = 'Google',
  className = '',
  ...rest
}) {
  useStyles()
  return (
    <div className={`dsf-review ${className}`.trim()} {...rest}>
      <div className="dsf-review__head">
        <Avatar name={authorName} variant="solid" size="md" />
        <div className="dsf-review__id">
          <div className="dsf-review__name">{authorName}</div>
          <div className="dsf-review__sub">
            <span className="dsf-review__stars">
              {Array.from({ length: 5 }).map((_, i) => <Star key={i} filled={i < rating} />)}
            </span>
            <span className="dsf-review__src">{source}</span>
          </div>
        </div>
        <svg className="dsf-review__quote" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
          <path d="M7.17 6A5.17 5.17 0 0 0 2 11.17V18h6.83v-6.83H5.5A1.67 1.67 0 0 1 7.17 9.5V6zm9 0A5.17 5.17 0 0 0 11 11.17V18h6.83v-6.83H14.5a1.67 1.67 0 0 1 1.67-1.67V6z" />
        </svg>
      </div>
      <p className="dsf-review__text">{text}</p>
    </div>
  )
}
