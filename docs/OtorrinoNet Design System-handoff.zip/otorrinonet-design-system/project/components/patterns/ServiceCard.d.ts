import * as React from 'react'

/**
 * Compact specialty tile — icon chip over a label. Used in the homepage
 * services grid.
 */
export interface ServiceCardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Service name, e.g. "Audiología". */
  name: string
  /** Icon node (a lucide icon at ~20px). */
  icon?: React.ReactNode
  /** Optional link target. */
  href?: string
}

export function ServiceCard(props: ServiceCardProps): React.JSX.Element
