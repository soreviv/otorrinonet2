import React from 'react'
import { Avatar } from '../core/Avatar.jsx'
import { Badge } from '../core/Badge.jsx'

const STATUS = {
  pendiente:    { variant: 'warning', label: 'Pendiente' },
  confirmada:   { variant: 'info',    label: 'Confirmada' },
  reprogramada: { variant: 'info',    label: 'Reprogramada' },
  completada:   { variant: 'success', label: 'Completada' },
  cancelada:    { variant: 'danger',  label: 'Cancelada' },
}

const CSS = `
.dsf-aptrow{
  width:100%;text-align:left;display:flex;align-items:flex-start;gap:12px;
  padding:12px var(--space-6);background:transparent;border:0;cursor:pointer;
  font-family:var(--font-sans);position:relative;
  transition:background var(--duration-base) var(--ease-standard);
}
.dsf-aptrow:hover{background:var(--surface-page);}
.dsf-aptrow--selected{background:var(--color-sky-50);}
.dsf-aptrow--selected::before{content:"";position:absolute;left:0;top:8px;bottom:8px;
  width:3px;border-radius:0 3px 3px 0;background:var(--color-sky-500);}
.dsf-aptrow__main{flex:1;min-width:0;}
.dsf-aptrow__top{display:flex;align-items:baseline;justify-content:space-between;gap:8px;}
.dsf-aptrow__name{font-size:var(--text-sm);font-weight:var(--font-weight-semibold);
  color:var(--text-strong);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.dsf-aptrow--selected .dsf-aptrow__name{color:var(--color-sky-900);}
.dsf-aptrow__time{font-family:var(--font-mono);font-size:var(--text-xs);
  color:var(--text-muted);flex:none;}
.dsf-aptrow__svc{font-size:var(--text-xs);color:var(--text-body);margin-top:2px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.dsf-aptrow__badge{margin-top:8px;}
`
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-aptrow-css')) return
    const s = document.createElement('style')
    s.id = 'dsf-aptrow-css'; s.textContent = CSS; document.head.appendChild(s)
  }, [])
}

/**
 * Appointment list row for the staff agenda — avatar, patient name, time,
 * service and a status badge, with a selected state.
 */
export function AppointmentRow({
  patientName,
  time,
  serviceName,
  status = 'pendiente',
  selected = false,
  className = '',
  ...rest
}) {
  useStyles()
  const cfg = STATUS[status] || STATUS.pendiente
  return (
    <button
      className={['dsf-aptrow', selected ? 'dsf-aptrow--selected' : '', className].filter(Boolean).join(' ')}
      {...rest}
    >
      <Avatar name={patientName} size="sm" variant={selected ? 'solid' : 'neutral'} />
      <span className="dsf-aptrow__main">
        <span className="dsf-aptrow__top">
          <span className="dsf-aptrow__name">{patientName}</span>
          <span className="dsf-aptrow__time">{time}</span>
        </span>
        <span className="dsf-aptrow__svc">{serviceName}</span>
        <span className="dsf-aptrow__badge">
          <Badge variant={cfg.variant} size="sm" dot>{cfg.label}</Badge>
        </span>
      </span>
    </button>
  )
}
