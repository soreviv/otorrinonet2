import * as React from 'react'

export interface ScheduleRow { days: string; hours: string }

/**
 * Contact info card — address, schedule table and phone number. Used on the
 * homepage contact section and the Ubicación page.
 */
export interface ContactCardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Street address line. */
  address?: string
  /** City / state / postal code line. */
  city?: string
  /** Schedule rows — "Cerrado" entries are visually muted. */
  schedule?: ScheduleRow[]
  /** Phone number string (displayed in monospace). */
  phone?: string
}

export function ContactCard(props: ContactCardProps): React.JSX.Element
