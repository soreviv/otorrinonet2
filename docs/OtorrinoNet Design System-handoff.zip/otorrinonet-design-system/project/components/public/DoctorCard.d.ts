import * as React from 'react'

/**
 * Doctor profile card — photo, name, specialty, bio, certifications and cédulas.
 *
 * @startingPoint section="Sitio público" subtitle="Doctor profile card — photo, credentials, bio" viewport="340x520"
 */
export interface DoctorCardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Full name with title, e.g. "Dr. Alejandro Viveros Domínguez". */
  name: string
  /** Specialty line. */
  title?: string
  /** Short bio paragraph. */
  bio?: string
  /** Photo URL. */
  photoSrc?: string
  /** Photo area height in px. @default 260 */
  photoHeight?: number
  /** Years of experience (shows an animated "live" badge). */
  experienceYears?: number
  /** Certification/membership strings. */
  certifications?: string[]
  /** Cédula profesional number. */
  license?: string
  /** Cédula de especialidad number. */
  specialtyLicense?: string
}

export function DoctorCard(props: DoctorCardProps): React.JSX.Element
