import React from 'react'

const CSS = `
.dsf-bc{
  display:flex;align-items:center;gap:6px;flex-wrap:wrap;
  font-family:var(--font-sans);font-size:var(--text-sm);
}
.dsf-bc__item{display:flex;align-items:center;gap:6px;}
.dsf-bc__link{
  color:var(--text-muted);text-decoration:none;cursor:pointer;background:none;border:0;padding:0;
  transition:color var(--duration-fast) var(--ease-standard);
}
.dsf-bc__link:hover{color:var(--brand-primary);}
.dsf-bc__sep{color:var(--border-strong);}
.dsf-bc__current{color:var(--text-strong);font-weight:var(--font-weight-medium);}
`
function useStyles(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return
    const s = document.createElement('style')
    s.id = id; s.textContent = css; document.head.appendChild(s)
  }, [])
}

const ChevR = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="m9 18 6-6-6-6" />
  </svg>
)

/**
 * Breadcrumb navigation — a list of ancestor pages leading to the current one.
 * Used on interior public pages (Servicios, Perfil, Ubicación, etc.).
 */
export function Breadcrumbs({ items = [], className = '', ...rest }) {
  useStyles('dsf-bc-css', CSS)
  return (
    <nav aria-label="Breadcrumb" className={`dsf-bc ${className}`.trim()} {...rest}>
      {items.map((item, i) => {
        const isLast = i === items.length - 1
        return (
          <span key={i} className="dsf-bc__item">
            {i > 0 && <span className="dsf-bc__sep"><ChevR /></span>}
            {isLast
              ? <span className="dsf-bc__current" aria-current="page">{item.label}</span>
              : <button className="dsf-bc__link" onClick={item.onClick}>{item.label}</button>
            }
          </span>
        )
      })}
    </nav>
  )
}
