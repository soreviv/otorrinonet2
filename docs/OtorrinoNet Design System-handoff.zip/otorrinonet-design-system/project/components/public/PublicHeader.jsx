import React from 'react'

const CSS = `
.dsf-ph{
  position:sticky;top:0;z-index:50;
  background:rgba(255,255,255,.95);
  backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
  border-bottom:1px solid var(--border-subtle);
  font-family:var(--font-sans);
}
.dsf-ph__inner{
  max-width:var(--container-max);margin:0 auto;
  height:var(--header-h);
  padding:0 var(--space-6);
  display:flex;align-items:center;justify-content:space-between;gap:var(--space-8);
}
.dsf-ph__logo{cursor:pointer;display:flex;align-items:center;flex:none;}
.dsf-ph__logo img{height:46px;width:auto;}
.dsf-ph__nav{display:flex;align-items:center;gap:var(--space-8);}
.dsf-ph__link{
  font-size:var(--text-sm);font-weight:var(--font-weight-medium);
  color:var(--text-body);text-decoration:none;cursor:pointer;background:none;border:0;padding:0;
  transition:color var(--duration-fast) var(--ease-standard);
}
.dsf-ph__link:hover,.dsf-ph__link.active{color:var(--brand-primary);}
.dsf-ph__cta{
  display:inline-flex;align-items:center;gap:var(--space-2);flex:none;
  font-family:var(--font-sans);font-size:var(--text-sm);font-weight:var(--font-weight-semibold);
  padding:8px var(--space-5);border-radius:var(--radius-lg);border:0;cursor:pointer;
  background:var(--brand-primary);color:#fff;text-decoration:none;white-space:nowrap;
  transition:background var(--duration-base) var(--ease-standard),box-shadow var(--duration-base) var(--ease-standard);
}
.dsf-ph__cta:hover{background:var(--brand-primary-hover);box-shadow:var(--shadow-primary);}
.dsf-ph__menu{display:none;align-items:center;justify-content:center;width:36px;height:36px;
  border-radius:var(--radius-md);border:1px solid var(--border-default);background:transparent;cursor:pointer;}
@media(max-width:700px){.dsf-ph__nav-links{display:none;}.dsf-ph__menu{display:flex;}}
`

function useStyles(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return
    const s = document.createElement('style')
    s.id = id; s.textContent = css; document.head.appendChild(s)
  }, [])
}

/**
 * Sticky translucent public-site header — logo, nav links, and a booking CTA.
 */
export function PublicHeader({
  links = [],
  activePage,
  onNav,
  ctaLabel = 'Agendar Cita',
  logoSrc = '/assets/logo-otorrinonet-transparent.svg',
  className = '',
  ...rest
}) {
  useStyles('dsf-ph-css', CSS)
  const CalIcon = () => (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>
    </svg>
  )
  const MenuIcon = () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 12h16M4 6h16M4 18h16"/>
    </svg>
  )
  return (
    <nav className={`dsf-ph ${className}`.trim()} {...rest}>
      <div className="dsf-ph__inner">
        <span className="dsf-ph__logo" onClick={() => onNav?.('inicio')}>
          <img src={logoSrc} alt="Logo" />
        </span>
        <div className="dsf-ph__nav">
          <div className="dsf-ph__nav-links" style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-8)' }}>
            {links.map(([id, label]) => (
              <button key={id} className={`dsf-ph__link${activePage === id ? ' active' : ''}`} onClick={() => onNav?.(id)}>
                {label}
              </button>
            ))}
          </div>
          <button className="dsf-ph__menu" aria-label="Menú"><MenuIcon /></button>
          <button className="dsf-ph__cta" onClick={() => onNav?.('agendar')}>
            <CalIcon />{ctaLabel}
          </button>
        </div>
      </div>
    </nav>
  )
}
