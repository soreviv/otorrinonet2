import * as React from 'react'

/**
 * Compact Google-rating floating widget — numeric score, amber stars, review count
 * and source attribution.
 */
export interface RatingSummaryProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Average rating. @default 5.0 */
  average?: number
  /** Total review count. */
  total?: number
  /** Source label. @default 'Google' */
  source?: string
  /** Star icon size in px. @default 14 */
  starSize?: number
}

export function RatingSummary(props: RatingSummaryProps): React.JSX.Element
