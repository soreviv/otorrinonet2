import React from 'react'

const CSS = `
.dsf-contact{
  display:flex;flex-direction:column;gap:0;
  background:var(--surface-card);border:1px solid var(--border-subtle);
  border-radius:var(--radius-2xl);box-shadow:var(--shadow-sm);
  overflow:hidden;font-family:var(--font-sans);
}
.dsf-contact__section{padding:var(--space-5) var(--space-6);}
.dsf-contact__section+.dsf-contact__section{border-top:1px solid var(--border-subtle);}
.dsf-contact__eyebrow{font-size:10px;font-weight:700;text-transform:uppercase;
  letter-spacing:var(--tracking-widest);color:var(--text-muted);margin-bottom:var(--space-3);}
.dsf-contact__row{display:flex;align-items:flex-start;gap:10px;font-size:var(--text-sm);
  color:var(--text-body);margin-bottom:8px;}
.dsf-contact__row:last-child{margin-bottom:0;}
.dsf-contact__icon{flex:none;color:var(--brand-primary);margin-top:1px;}
.dsf-contact__sched{width:100%;font-size:var(--text-sm);}
.dsf-contact__sched tr td:first-child{color:var(--text-body);padding-bottom:6px;padding-right:16px;}
.dsf-contact__sched tr td:last-child{font-family:var(--font-mono);font-size:12px;
  font-weight:600;color:var(--text-strong);text-align:right;}
.dsf-contact__sched .closed td{color:var(--text-muted)!important;}
.dsf-contact__phone{font-family:var(--font-mono);font-size:var(--text-base);font-weight:600;
  color:var(--text-strong);}
`
function useStyles(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return
    const s = document.createElement('style')
    s.id = id; s.textContent = css; document.head.appendChild(s)
  }, [])
}

const MapPin = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
const Clock  = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
const Phone  = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.21 15.8 19.8 19.8 0 0 1 1.14 7.18 2 2 0 0 1 3.11 5h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L7.09 12.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z"/></svg>

/**
 * Contact info card — address, schedule table and phone. Used in the
 * homepage contact section and the Ubicación page.
 */
export function ContactCard({
  address,
  city,
  schedule = [],
  phone,
  className = '',
  ...rest
}) {
  useStyles('dsf-contact-css', CSS)
  return (
    <div className={`dsf-contact ${className}`.trim()} {...rest}>
      {(address || city) && (
        <div className="dsf-contact__section">
          <div className="dsf-contact__eyebrow">Consultorio</div>
          <div className="dsf-contact__row">
            <span className="dsf-contact__icon"><MapPin /></span>
            <span>{address}{city ? <><br /><span style={{ color: 'var(--text-muted)' }}>{city}</span></> : null}</span>
          </div>
        </div>
      )}
      {schedule.length > 0 && (
        <div className="dsf-contact__section">
          <div className="dsf-contact__eyebrow">Horario de atención</div>
          <div className="dsf-contact__row" style={{ marginBottom: 0 }}>
            <span className="dsf-contact__icon"><Clock /></span>
            <table className="dsf-contact__sched">
              <tbody>
                {schedule.map((s, i) => (
                  <tr key={i} className={s.hours === 'Cerrado' ? 'closed' : ''}>
                    <td>{s.days}</td>
                    <td>{s.hours}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      {phone && (
        <div className="dsf-contact__section">
          <div className="dsf-contact__eyebrow">Teléfono</div>
          <div className="dsf-contact__row" style={{ marginBottom: 0 }}>
            <span className="dsf-contact__icon"><Phone /></span>
            <span className="dsf-contact__phone">{phone}</span>
          </div>
        </div>
      )}
    </div>
  )
}
