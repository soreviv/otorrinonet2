import * as React from 'react'

export interface BreadcrumbItem {
  /** Displayed label. */
  label: string
  /** Click handler — omit for the last (current) item. */
  onClick?: () => void
}

/**
 * Breadcrumb navigation for interior public pages (Servicios, Perfil, Ubicación…).
 */
export interface BreadcrumbsProps extends React.HTMLAttributes<HTMLElement> {
  /** Ordered list of ancestors + current page. Last item is the current page. */
  items: BreadcrumbItem[]
}

export function Breadcrumbs(props: BreadcrumbsProps): React.JSX.Element
