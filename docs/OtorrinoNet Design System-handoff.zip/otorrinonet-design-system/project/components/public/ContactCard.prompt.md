Contact info card — address, schedule table and phone. Each section is separated by a divider and labeled with an uppercase eyebrow.

```jsx
<ContactCard
  address="Chosica 730, Col. Lindavista"
  city="Gustavo A. Madero, CDMX · 07300"
  schedule={[
    { days: 'Lunes – Miércoles', hours: '16:00 – 20:00' },
    { days: 'Jueves – Viernes',  hours: '10:00 – 14:00' },
    { days: 'Sábado y Domingo',  hours: 'Cerrado' },
  ]}
  phone="55 5586 0000"
/>
```

Any section (address / schedule / phone) is optional — omit the prop to hide it. Schedule rows with `hours: 'Cerrado'` are rendered in muted color.
