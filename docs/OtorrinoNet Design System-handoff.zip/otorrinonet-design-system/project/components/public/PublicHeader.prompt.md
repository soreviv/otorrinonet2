Sticky translucent public-site header — logo on the left, nav links in the middle, "Agendar Cita" CTA on the right. Collapses nav links on mobile (shows a hamburger).

```jsx
const LINKS = [['inicio','Inicio'],['perfil','Perfil'],['servicios','Servicios'],['tienda','Tienda'],['ubicacion','Ubicación']]
<PublicHeader links={LINKS} activePage={page} onNav={setPage} />
```

`onNav` receives the page id on any click (nav items or CTA both call it). `ctaLabel` overrides the button text. `logoSrc` swaps the logo image.
