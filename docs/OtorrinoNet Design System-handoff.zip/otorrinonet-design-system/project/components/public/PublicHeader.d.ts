import * as React from 'react'

/**
 * Sticky translucent public-site header — logo, nav links, and an "Agendar Cita" CTA.
 */
export interface PublicHeaderProps extends React.HTMLAttributes<HTMLElement> {
  /** Nav items as [id, label] tuples. */
  links?: [string, string][]
  /** ID of the currently active nav item. */
  activePage?: string
  /** Called with the target page id on any nav or CTA click. */
  onNav?: (page: string) => void
  /** CTA button label. @default 'Agendar Cita' */
  ctaLabel?: string
  /** Logo src. @default '/assets/logo-otorrinonet-transparent.svg' */
  logoSrc?: string
}

export function PublicHeader(props: PublicHeaderProps): React.JSX.Element
