Breadcrumb navigation for interior public pages — the last item is the current page (bold, no click); earlier items are clickable links.

```jsx
<Breadcrumbs items={[
  { label: 'Inicio', onClick: () => nav('inicio') },
  { label: 'Servicios', onClick: () => nav('servicios') },
  { label: 'Audiología' },
]} />
```

Pass any number of items. `onClick` is omitted on the last item (current page). Renders a `<nav aria-label="Breadcrumb">` for accessibility.
