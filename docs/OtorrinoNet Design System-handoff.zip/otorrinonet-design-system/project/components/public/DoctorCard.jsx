import React from 'react'

const CSS = `
.dsf-dc{
  display:flex;flex-direction:column;background:var(--surface-card);
  border:1px solid var(--border-subtle);border-radius:var(--radius-2xl);
  box-shadow:var(--shadow-sm);overflow:hidden;font-family:var(--font-sans);
}
.dsf-dc__photo{position:relative;width:100%;background:var(--color-sky-50);}
.dsf-dc__photo img{width:100%;height:100%;object-fit:cover;object-position:center top;display:block;}
.dsf-dc__body{padding:var(--space-6);}
.dsf-dc__badge{
  display:inline-flex;align-items:center;gap:6px;margin-bottom:12px;
  font-size:var(--text-xs);font-weight:var(--font-weight-bold);
  text-transform:uppercase;letter-spacing:var(--tracking-widest);
  color:var(--brand-primary);background:var(--surface-primary-soft);
  padding:4px 12px;border-radius:var(--radius-full);
}
.dsf-dc__name{font-family:var(--font-heading);font-size:var(--text-xl);font-weight:700;
  color:var(--text-strong);line-height:var(--leading-snug);margin-bottom:4px;}
.dsf-dc__title{font-size:var(--text-sm);color:var(--brand-primary);font-weight:var(--font-weight-semibold);margin-bottom:var(--space-4);}
.dsf-dc__bio{font-size:var(--text-sm);color:var(--text-body);line-height:var(--leading-relaxed);margin-bottom:var(--space-4);}
.dsf-dc__certs{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:var(--space-4);}
.dsf-dc__cert{font-size:11px;font-weight:500;color:var(--text-body);
  background:var(--surface-sunken);padding:4px 10px;border-radius:var(--radius-full);}
.dsf-dc__ceds{display:flex;gap:8px;flex-wrap:wrap;}
.dsf-dc__ced{font-family:var(--font-mono);font-size:11px;font-weight:500;
  padding:4px 10px;border-radius:var(--radius-sm);}
.dsf-dc__ced--prof{background:var(--surface-sunken);color:var(--text-body);}
.dsf-dc__ced--esp{background:var(--color-sky-50);color:var(--color-sky-700);}
`

function useStyles(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return
    const s = document.createElement('style')
    s.id = id; s.textContent = css; document.head.appendChild(s)
  }, [])
}

/**
 * Doctor profile card — photo, name, specialty title, bio blurb, certifications
 * and cédulas. Used in the public hero, profile page and sidebar.
 */
export function DoctorCard({
  name,
  title,
  bio,
  photoSrc,
  photoHeight = 260,
  experienceYears,
  certifications = [],
  license,
  specialtyLicense,
  className = '',
  ...rest
}) {
  useStyles('dsf-dc-css', CSS)
  return (
    <div className={`dsf-dc ${className}`.trim()} {...rest}>
      {photoSrc && (
        <div className="dsf-dc__photo" style={{ height: photoHeight }}>
          <img src={photoSrc} alt={name} />
        </div>
      )}
      <div className="dsf-dc__body">
        {experienceYears && (
          <span className="dsf-dc__badge">
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--brand-primary)', animation: 'ds-pulse 1.6s ease-in-out infinite' }} />
            {experienceYears}+ años de experiencia
          </span>
        )}
        <div className="dsf-dc__name">{name}</div>
        {title && <div className="dsf-dc__title">{title}</div>}
        {bio && <p className="dsf-dc__bio">{bio}</p>}
        {certifications.length > 0 && (
          <div className="dsf-dc__certs">
            {certifications.map((c, i) => <span key={i} className="dsf-dc__cert">{c}</span>)}
          </div>
        )}
        {(license || specialtyLicense) && (
          <div className="dsf-dc__ceds">
            {license && <span className="dsf-dc__ced dsf-dc__ced--prof">Céd. Prof. {license}</span>}
            {specialtyLicense && <span className="dsf-dc__ced dsf-dc__ced--esp">Céd. Esp. {specialtyLicense}</span>}
          </div>
        )}
      </div>
    </div>
  )
}
