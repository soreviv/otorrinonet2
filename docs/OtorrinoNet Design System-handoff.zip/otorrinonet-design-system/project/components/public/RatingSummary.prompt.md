Compact floating Google-rating widget — score, amber stars, review count and source. Used as the floating badge on the hero image or standalone on the profile page.

```jsx
<RatingSummary average={5.0} total={6} source="Google" />
```

`average` drives how many stars fill (rounded to nearest integer). `starSize` scales the stars (default 14px). Renders as an `inline-flex` so it floats naturally over images via `position:absolute`.
