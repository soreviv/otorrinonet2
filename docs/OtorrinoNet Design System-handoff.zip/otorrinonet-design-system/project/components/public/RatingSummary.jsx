import React from 'react'

const CSS = `
.dsf-rating{
  display:inline-flex;align-items:center;gap:12px;
  background:var(--surface-card);border:1px solid var(--border-subtle);
  border-radius:var(--radius-xl);box-shadow:var(--shadow-md);
  padding:10px 16px;font-family:var(--font-sans);
}
.dsf-rating__score{display:flex;flex-direction:column;align-items:flex-start;}
.dsf-rating__num{font-family:var(--font-heading);font-size:var(--text-2xl);font-weight:700;
  color:var(--text-strong);line-height:1;}
.dsf-rating__of{font-size:var(--text-xs);color:var(--text-muted);}
.dsf-rating__div{width:1px;background:var(--border-default);align-self:stretch;}
.dsf-rating__stars{display:flex;flex-direction:column;gap:4px;}
.dsf-rating__row{display:flex;gap:2px;}
.dsf-rating__src{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--text-muted);}
.dsf-rating__count{font-size:11px;color:var(--text-muted);}
`
function useStyles(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return
    const s = document.createElement('style')
    s.id = id; s.textContent = css; document.head.appendChild(s)
  }, [])
}

function Star({ filled, size = 14 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={filled ? 'var(--color-amber-400)' : 'var(--color-slate-200)'}>
      <path d="M12 2l2.9 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l7.1-1.01L12 2z" />
    </svg>
  )
}

/**
 * Compact floating Google-rating widget — score, star row and review count.
 * Used as the floating badge on the hero image and on the profile page.
 */
export function RatingSummary({
  average = 5.0,
  total = 0,
  source = 'Google',
  starSize = 14,
  className = '',
  ...rest
}) {
  useStyles('dsf-rating-css', CSS)
  const full = Math.round(average)
  return (
    <div className={`dsf-rating ${className}`.trim()} {...rest}>
      <div className="dsf-rating__score">
        <span className="dsf-rating__num">{average.toFixed(1)}</span>
        <span className="dsf-rating__of">/ 5</span>
      </div>
      <div className="dsf-rating__div" />
      <div className="dsf-rating__stars">
        <div className="dsf-rating__row">
          {[0,1,2,3,4].map(i => <Star key={i} filled={i < full} size={starSize} />)}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          {total > 0 && <span className="dsf-rating__count">{total} reseñas</span>}
          {total > 0 && <span style={{ color: 'var(--border-default)' }}>·</span>}
          <span className="dsf-rating__src">{source}</span>
        </div>
      </div>
    </div>
  )
}
