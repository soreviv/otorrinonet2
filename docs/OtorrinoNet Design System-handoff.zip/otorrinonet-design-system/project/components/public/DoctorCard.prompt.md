Doctor profile card — photo, name, specialty, animated experience badge, certifications and cédulas. Used in the public hero, profile page and sidebar.

```jsx
<DoctorCard
  name="Dr. Alejandro Viveros Domínguez"
  title="Médico Otorrinolaringólogo"
  bio="Especialista en Otorrinolaringología y Cirugía de Cabeza y Cuello…"
  photoSrc="/assets/dr-viveros-perfil.jpg"
  photoHeight={280}
  experienceYears={10}
  certifications={['Sociedad Mexicana de ORL y CCC', 'IMSS adscrito desde 2016']}
  license="6277305"
  specialtyLicense="10148701"
/>
```

Omit `photoSrc` to render text-only. `photoHeight` controls the image area. `certifications` render as soft pills below the bio.
