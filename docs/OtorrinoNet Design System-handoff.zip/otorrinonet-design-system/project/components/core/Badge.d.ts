import * as React from 'react'

export type BadgeVariant = 'info' | 'warning' | 'success' | 'danger' | 'neutral'

/**
 * Soft status pill — maps clinical/order states to a colour + optional dot.
 */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** State colour. @default 'neutral' */
  variant?: BadgeVariant
  /** @default 'md' */
  size?: 'sm' | 'md'
  /** Show the leading status dot. */
  dot?: boolean
  /** Animate the dot (use for "live"/availability). */
  pulse?: boolean
  children?: React.ReactNode
}

export function Badge(props: BadgeProps): React.JSX.Element
