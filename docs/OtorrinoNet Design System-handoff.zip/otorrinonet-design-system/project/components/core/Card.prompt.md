White surface container (rounded-2xl, soft shadow) — the base for panels, feature blocks and list containers.

```jsx
<Card>
  <h3>Productos recomendados</h3>
  <p>Dispositivos médicos seleccionados por el especialista.</p>
</Card>

<Card interactive href="/tienda" padding="lg">…</Card>
```

`padding`: `none` / `md` / `lg`. `hover` lifts the shadow; `interactive` adds pointer + translate for clickable cards; `flat` drops the resting shadow (border-only). Pass `href` to render an anchor.
