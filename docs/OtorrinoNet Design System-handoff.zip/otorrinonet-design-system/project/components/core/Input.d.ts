import * as React from 'react'

/**
 * Labelled text input with optional leading icon, hint and error states.
 */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  /** Field label rendered above the control. */
  label?: string
  /** Leading icon node (e.g. a lucide <Search/>). */
  icon?: React.ReactNode
  /** Helper text below the field. */
  hint?: string
  /** Error message — overrides hint and turns the field rose. */
  error?: string
  /** Show a required asterisk. */
  required?: boolean
  /** Use the sunken (slate-50) fill — for in-app search bars. */
  sunken?: boolean
}

export function Input(props: InputProps): React.JSX.Element
