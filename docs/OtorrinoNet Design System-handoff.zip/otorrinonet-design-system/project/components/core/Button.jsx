import React from 'react'

/* Inject component CSS once (real :hover / :active / :focus states). */
const CSS = `
.dsf-btn{
  --_bg:var(--brand-primary);--_bgh:var(--brand-primary-hover);--_bga:var(--brand-primary-active);
  --_fg:var(--text-on-primary);--_bd:transparent;--_sh:none;
  display:inline-flex;align-items:center;justify-content:center;gap:var(--space-2);
  font-family:var(--font-sans);font-weight:var(--font-weight-semibold);
  border:1px solid var(--_bd);border-radius:var(--radius-lg);
  background:var(--_bg);color:var(--_fg);cursor:pointer;white-space:nowrap;
  text-decoration:none;box-shadow:var(--_sh);
  transition:background var(--duration-base) var(--ease-standard),
             box-shadow var(--duration-base) var(--ease-standard),
             border-color var(--duration-base) var(--ease-standard),
             transform var(--duration-base) var(--ease-standard);
}
.dsf-btn:hover{background:var(--_bgh);box-shadow:var(--shadow-primary);}
.dsf-btn:active{background:var(--_bga);transform:scale(var(--press-scale));box-shadow:none;}
.dsf-btn:focus-visible{outline:none;box-shadow:var(--ring-focus);}
.dsf-btn[disabled]{opacity:.5;cursor:not-allowed;box-shadow:none;transform:none;background:var(--_bg);}

.dsf-btn--secondary{--_bg:var(--surface-card);--_bgh:var(--brand-accent-soft);--_bga:var(--brand-accent-soft);
  --_fg:var(--text-body);--_bd:var(--border-default);}
.dsf-btn--secondary:hover{border-color:var(--color-sky-300);color:var(--brand-primary-hover);box-shadow:none;}
.dsf-btn--secondary:active{transform:scale(var(--press-scale));}

.dsf-btn--ghost{--_bg:transparent;--_bgh:var(--surface-sunken);--_bga:var(--surface-sunken);--_fg:var(--text-body);}
.dsf-btn--ghost:hover{color:var(--text-strong);box-shadow:none;}

.dsf-btn--danger{--_bg:var(--color-rose-600);--_bgh:var(--color-rose-700);--_bga:var(--color-rose-700);--_fg:#fff;}
.dsf-btn--danger:hover{box-shadow:none;}

.dsf-btn--sm{font-size:var(--text-xs);padding:var(--space-2) var(--space-3);}
.dsf-btn--md{font-size:var(--text-sm);padding:10px var(--space-5);}
.dsf-btn--lg{font-size:var(--text-base);padding:14px var(--space-6);}
.dsf-btn--block{width:100%;}
`
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-btn-css')) return
    const s = document.createElement('style')
    s.id = 'dsf-btn-css'; s.textContent = CSS; document.head.appendChild(s)
  }, [])
}

/**
 * Primary action button. Matches the product's sky-600 buttons with a tinted
 * hover glow and a 0.98 press scale.
 */
export function Button({
  variant = 'primary',
  size = 'md',
  block = false,
  icon = null,
  iconRight = null,
  href,
  children,
  className = '',
  ...rest
}) {
  useStyles()
  const cls = [
    'dsf-btn',
    `dsf-btn--${variant}`,
    `dsf-btn--${size}`,
    block ? 'dsf-btn--block' : '',
    className,
  ].filter(Boolean).join(' ')

  const content = (
    <>
      {icon}
      {children}
      {iconRight}
    </>
  )

  if (href) {
    return <a href={href} className={cls} {...rest}>{content}</a>
  }
  return <button className={cls} {...rest}>{content}</button>
}
