Soft status pill — maps appointment/order/record states to a colour with an optional leading dot.

```jsx
<Badge variant="warning" dot>Pendiente</Badge>
<Badge variant="info" dot>Confirmada</Badge>
<Badge variant="success" dot>Completada</Badge>
<Badge variant="danger" dot>Cancelada</Badge>
```

Variants: `info` (sky), `warning` (amber), `success` (emerald), `danger` (rose), `neutral` (slate). `size="sm"` switches to a squarer table-tag shape. `pulse` animates the dot for availability indicators.
