import * as React from 'react'

export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger'
export type ButtonSize = 'sm' | 'md' | 'lg'

/**
 * Primary action button for OtorrinoNet. sky-600 fill with a tinted hover glow
 * and a subtle press scale; secondary/ghost/danger variants cover the rest.
 *
 * @startingPoint section="Core" subtitle="Primary action button — 4 variants, 3 sizes" viewport="700x150"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual style. @default 'primary' */
  variant?: ButtonVariant
  /** Size. @default 'md' */
  size?: ButtonSize
  /** Stretch to full width. */
  block?: boolean
  /** Leading icon node (e.g. a lucide <Calendar/>). */
  icon?: React.ReactNode
  /** Trailing icon node. */
  iconRight?: React.ReactNode
  /** Render as an <a> with this href instead of a <button>. */
  href?: string
  children?: React.ReactNode
}

export function Button(props: ButtonProps): React.JSX.Element
