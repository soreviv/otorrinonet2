import React from 'react'

const CSS = `
.dsf-card{
  display:block;background:var(--surface-card);
  border:1px solid var(--border-subtle);border-radius:var(--radius-2xl);
  box-shadow:var(--shadow-sm);
  transition:box-shadow var(--duration-medium) var(--ease-standard),
    border-color var(--duration-medium) var(--ease-standard),
    transform var(--duration-medium) var(--ease-standard);
}
.dsf-card--pad-md{padding:var(--space-6);}
.dsf-card--pad-lg{padding:var(--space-8);}
.dsf-card--pad-none{padding:0;}
.dsf-card--hover:hover{box-shadow:var(--shadow-lg);border-color:var(--border-default);}
.dsf-card--interactive{cursor:pointer;}
.dsf-card--interactive:hover{box-shadow:var(--shadow-lg);border-color:var(--color-sky-200);transform:translateY(-2px);}
.dsf-card--interactive:active{transform:translateY(0);box-shadow:var(--shadow-sm);}
.dsf-card--flat{box-shadow:none;}
a.dsf-card{text-decoration:none;color:inherit;}
`
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-card-css')) return
    const s = document.createElement('style')
    s.id = 'dsf-card-css'; s.textContent = CSS; document.head.appendChild(s)
  }, [])
}

/**
 * Surface container — white, rounded-2xl, soft shadow. The base building block
 * for content panels, feature blocks and list containers.
 */
export function Card({
  padding = 'md',
  hover = false,
  interactive = false,
  flat = false,
  href,
  children,
  className = '',
  ...rest
}) {
  useStyles()
  const cls = [
    'dsf-card',
    `dsf-card--pad-${padding}`,
    hover ? 'dsf-card--hover' : '',
    interactive ? 'dsf-card--interactive' : '',
    flat ? 'dsf-card--flat' : '',
    className,
  ].filter(Boolean).join(' ')

  if (href) return <a href={href} className={cls} {...rest}>{children}</a>
  return <div className={cls} {...rest}>{children}</div>
}
