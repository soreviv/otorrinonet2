Circular initials/photo avatar for patients, staff and reviewers; derives initials from a name or shows a photo.

```jsx
<Avatar name="Mónica Bautista" />
<Avatar name="Dr. Alejandro Viveros" variant="solid" size="lg" />
<Avatar src="/assets/dr-viveros-perfil.jpg" name="Dr. Viveros" size="xl" />
```

Sizes `xs`–`xl` (`xl` is a rounded-square, used in the appointment hero). Variants: `solid` (sky fill), `soft` (sky-100), `neutral` (slate), `onPrimary` (translucent white, for use on sky surfaces).
