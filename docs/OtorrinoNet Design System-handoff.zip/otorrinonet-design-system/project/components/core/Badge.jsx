import React from 'react'

const CSS = `
.dsf-badge{
  display:inline-flex;align-items:center;gap:6px;
  font-family:var(--font-sans);font-weight:var(--font-weight-semibold);
  font-size:var(--text-xs);line-height:1;
  padding:4px 10px;border-radius:var(--radius-full);white-space:nowrap;
}
.dsf-badge--sm{font-size:11px;padding:2px 8px;border-radius:var(--radius-sm);}
.dsf-badge__dot{width:6px;height:6px;border-radius:50%;flex:none;}
.dsf-badge__dot--pulse{animation:ds-pulse 1.6s ease-in-out infinite;}
.dsf-badge--info{background:var(--state-info-bg);color:var(--state-info-fg);}
.dsf-badge--info .dsf-badge__dot{background:var(--color-sky-500);}
.dsf-badge--warning{background:var(--state-warning-bg);color:var(--state-warning-fg);}
.dsf-badge--warning .dsf-badge__dot{background:var(--color-amber-400);}
.dsf-badge--success{background:var(--state-success-bg);color:var(--state-success-fg);}
.dsf-badge--success .dsf-badge__dot{background:var(--color-emerald-500);}
.dsf-badge--danger{background:var(--state-danger-bg);color:var(--state-danger-fg);}
.dsf-badge--danger .dsf-badge__dot{background:var(--color-rose-400);}
.dsf-badge--neutral{background:var(--surface-sunken);color:var(--text-body);}
.dsf-badge--neutral .dsf-badge__dot{background:var(--color-slate-400);}
`
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-badge-css')) return
    const s = document.createElement('style')
    s.id = 'dsf-badge-css'; s.textContent = CSS; document.head.appendChild(s)
  }, [])
}

/**
 * Soft status pill used across appointments, orders and records
 * (Pendiente / Confirmada / Completada / Cancelada).
 */
export function Badge({
  variant = 'neutral',
  size = 'md',
  dot = false,
  pulse = false,
  children,
  className = '',
  ...rest
}) {
  useStyles()
  const cls = [
    'dsf-badge',
    `dsf-badge--${variant}`,
    size === 'sm' ? 'dsf-badge--sm' : '',
    className,
  ].filter(Boolean).join(' ')
  return (
    <span className={cls} {...rest}>
      {dot && <span className={`dsf-badge__dot${pulse ? ' dsf-badge__dot--pulse' : ''}`} />}
      {children}
    </span>
  )
}
