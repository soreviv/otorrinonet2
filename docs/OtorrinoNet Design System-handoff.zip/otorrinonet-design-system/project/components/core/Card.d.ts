import * as React from 'react'

/**
 * Surface container — white, rounded-2xl, soft shadow. Base for panels,
 * feature blocks and list containers.
 */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Inner padding. @default 'md' */
  padding?: 'none' | 'md' | 'lg'
  /** Lift shadow on hover (static cards). */
  hover?: boolean
  /** Clickable card — pointer cursor + lift + translate. */
  interactive?: boolean
  /** Remove the resting shadow (border-only). */
  flat?: boolean
  /** Render as an <a> with this href. */
  href?: string
  children?: React.ReactNode
}

export function Card(props: CardProps): React.JSX.Element
