import * as React from 'react'

/**
 * Circular initials-or-photo avatar for patients, staff and reviewers.
 */
export interface AvatarProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Full name — initials are derived from the first two words. */
  name?: string
  /** Photo URL; falls back to initials when omitted. */
  src?: string
  /** @default 'md' */
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  /** Colour treatment. @default 'soft' */
  variant?: 'solid' | 'soft' | 'neutral' | 'onPrimary'
}

export function Avatar(props: AvatarProps): React.JSX.Element
