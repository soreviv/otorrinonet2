import React from 'react'

const CSS = `
.dsf-field{display:flex;flex-direction:column;gap:6px;font-family:var(--font-sans);}
.dsf-field__label{font-size:var(--text-sm);font-weight:var(--font-weight-medium);color:var(--text-strong);}
.dsf-field__req{color:var(--color-rose-600);margin-left:2px;}
.dsf-input{position:relative;display:flex;align-items:center;}
.dsf-input__icon{position:absolute;left:12px;display:flex;color:var(--text-muted);pointer-events:none;}
.dsf-input__el{
  width:100%;box-sizing:border-box;font-family:var(--font-sans);font-size:var(--text-sm);
  color:var(--text-strong);background:var(--surface-card);
  border:1px solid var(--border-default);border-radius:var(--radius-lg);
  padding:11px 14px;transition:border-color var(--duration-base) var(--ease-standard),
    box-shadow var(--duration-base) var(--ease-standard);
}
.dsf-input--icon .dsf-input__el{padding-left:38px;}
.dsf-input__el::placeholder{color:var(--text-muted);}
.dsf-input__el:hover{border-color:var(--border-strong);}
.dsf-input__el:focus{outline:none;border-color:var(--border-focus);
  box-shadow:0 0 0 3px rgb(14 165 233 / .18);}
.dsf-input--sunken .dsf-input__el{background:var(--surface-sunken);border-color:var(--border-default);}
.dsf-input--error .dsf-input__el{border-color:var(--color-rose-400);}
.dsf-input--error .dsf-input__el:focus{box-shadow:0 0 0 3px rgb(244 63 94 / .15);}
.dsf-field__hint{font-size:var(--text-xs);color:var(--text-muted);}
.dsf-field__hint--error{color:var(--color-rose-600);}
`
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-input-css')) return
    const s = document.createElement('style')
    s.id = 'dsf-input-css'; s.textContent = CSS; document.head.appendChild(s)
  }, [])
}

/**
 * Labelled text input with an optional leading icon. Sky focus ring matches
 * the search fields and booking forms across the product.
 */
export function Input({
  label,
  icon = null,
  hint,
  error,
  required = false,
  sunken = false,
  id,
  className = '',
  ...rest
}) {
  useStyles()
  const inputId = id || (label ? `dsf-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined)
  const wrapCls = [
    'dsf-input',
    icon ? 'dsf-input--icon' : '',
    sunken ? 'dsf-input--sunken' : '',
    error ? 'dsf-input--error' : '',
  ].filter(Boolean).join(' ')

  return (
    <label className={`dsf-field ${className}`.trim()} htmlFor={inputId}>
      {label && (
        <span className="dsf-field__label">
          {label}{required && <span className="dsf-field__req">*</span>}
        </span>
      )}
      <span className={wrapCls}>
        {icon && <span className="dsf-input__icon">{icon}</span>}
        <input id={inputId} className="dsf-input__el" {...rest} />
      </span>
      {(error || hint) && (
        <span className={`dsf-field__hint${error ? ' dsf-field__hint--error' : ''}`}>
          {error || hint}
        </span>
      )}
    </label>
  )
}
