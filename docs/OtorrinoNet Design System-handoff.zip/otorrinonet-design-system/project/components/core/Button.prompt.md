Primary action button — sky-600 fill, tinted hover glow, 0.98 press scale; use for the main CTA on any screen ("Agendar Cita", "Confirmar", "Nuevo paciente").

```jsx
<Button icon={<Calendar size={16} />} onClick={book}>Agendar Cita</Button>
<Button variant="secondary">Ver perfil</Button>
<Button variant="danger" size="sm">Cancelar</Button>
```

Variants: `primary` (default), `secondary` (white + slate border), `ghost` (transparent), `danger` (rose). Sizes: `sm` / `md` / `lg`. Pass `href` to render an anchor, `block` for full width, `icon` / `iconRight` for lucide icons.
