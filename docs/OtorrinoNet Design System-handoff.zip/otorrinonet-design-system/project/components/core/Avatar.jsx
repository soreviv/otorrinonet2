import React from 'react'

const CSS = `
.dsf-avatar{
  display:inline-flex;align-items:center;justify-content:center;flex:none;
  font-family:var(--font-heading);font-weight:var(--font-weight-bold);
  border-radius:var(--radius-full);overflow:hidden;line-height:1;
  text-transform:uppercase;letter-spacing:.02em;
}
.dsf-avatar img{width:100%;height:100%;object-fit:cover;}
.dsf-avatar--xs{width:28px;height:28px;font-size:10px;}
.dsf-avatar--sm{width:36px;height:36px;font-size:12px;}
.dsf-avatar--md{width:40px;height:40px;font-size:13px;}
.dsf-avatar--lg{width:48px;height:48px;font-size:15px;}
.dsf-avatar--xl{width:56px;height:56px;border-radius:var(--radius-2xl);font-size:18px;}
.dsf-avatar--solid{background:var(--brand-primary);color:#fff;}
.dsf-avatar--soft{background:var(--color-sky-100);color:var(--color-sky-700);}
.dsf-avatar--neutral{background:var(--surface-sunken);color:var(--text-muted);}
.dsf-avatar--onPrimary{background:rgba(255,255,255,.2);color:#fff;}
`
function useStyles() {
  React.useEffect(() => {
    if (document.getElementById('dsf-avatar-css')) return
    const s = document.createElement('style')
    s.id = 'dsf-avatar-css'; s.textContent = CSS; document.head.appendChild(s)
  }, [])
}

function initials(name = '') {
  return name.trim().split(/\s+/).slice(0, 2).map((n) => n[0] || '').join('').toUpperCase()
}

/**
 * Circular initials/photo avatar. Used for patients, staff and reviewers.
 * `xl` switches to a rounded-square (used in the appointment detail hero).
 */
export function Avatar({
  name = '',
  src,
  size = 'md',
  variant = 'soft',
  className = '',
  ...rest
}) {
  useStyles()
  const cls = [
    'dsf-avatar',
    `dsf-avatar--${size}`,
    `dsf-avatar--${variant}`,
    className,
  ].filter(Boolean).join(' ')
  return (
    <span className={cls} {...rest}>
      {src ? <img src={src} alt={name} /> : initials(name)}
    </span>
  )
}
