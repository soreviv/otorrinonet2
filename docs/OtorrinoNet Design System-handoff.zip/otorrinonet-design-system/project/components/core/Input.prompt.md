Labelled text input with an optional leading icon and sky focus ring; used in booking forms, search bars and the EHR.

```jsx
<Input label="Nombre completo" placeholder="Nombre del paciente" required />
<Input icon={<Search size={16} />} placeholder="Buscar paciente o teléfono…" sunken />
<Input label="Correo" error="Correo no válido" />
```

`sunken` gives the slate-50 in-app search style. Pass `hint` for helper text or `error` for the rose error state. Any native input prop (`type`, `value`, `onChange`…) is forwarded.
