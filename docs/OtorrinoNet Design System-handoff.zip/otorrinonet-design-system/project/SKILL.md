---
name: otorrinonet-design
description: Use this skill to generate well-branded interfaces and assets for OtorrinoNet — the platform of Dr. Alejandro Viveros Domínguez, otorrinolaringólogo (ENT) in CDMX — either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping. Spanish (es-MX) brand.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files.

This is the design system for **OtorrinoNet**, an ENT private-practice platform
(public site + online booking + medical store + clinical EHR). The brand is
**Spanish (es-MX)**, sky-blue + slate, DM Sans / Inter / IBM Plex Mono, Lucide
icons, soft clinical cards. Keep all copy in Mexican Spanish.

Key files:
- `readme.md` — full design guide: content voice, visual foundations, iconography, manifest.
- `styles.css` — the single CSS entry point; link it to inherit every token.
- `tokens/` — colors, typography, spacing, elevation, motion, fonts.
- `assets/` — logo, doctor portraits, product photos.
- `components/` — React primitives (Button, Badge, Avatar, Input, Card, ServiceCard, ReviewCard, AppointmentRow).
- `ui_kits/` — full self-contained screen recreations (public site + booking, staff panel).
- `guidelines/` — foundation specimen cards.

If creating visual artifacts (slides, mocks, throwaway prototypes), copy assets
out and create static HTML files for the user to view — link `styles.css` for
tokens and follow the foundations in `readme.md`. If working on production code,
copy assets and read the rules here to become an expert in designing with this
brand (the live product is Next.js + React + Tailwind v4; see GitHub
`soreviv/otorrinonet2`).

If the user invokes this skill without other guidance, ask them what they want
to build or design, ask a few clarifying questions, and act as an expert
designer who outputs HTML artifacts _or_ production code, depending on the need.
